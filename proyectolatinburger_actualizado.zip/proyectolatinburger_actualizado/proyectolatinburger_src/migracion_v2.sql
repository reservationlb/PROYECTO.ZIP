-- =====================================================================
-- MIGRACIÓN v2 - Reservation L.B. (Latin Burger)
-- Ejecutar UNA vez, DESPUÉS de migracion_v1.sql. Aditivo, no borra nada.
--
-- QUÉ AGREGA Y POR QUÉ:
-- 1. tipo_evento.imagen / tipo_evento.activo   -> permitir imagen por tipo
--    de evento y poder ocultarlo desde el admin sin borrarlo (mismo patrón
--    que Producto.activo).
-- 2. tipo_decoracion.imagen / tipo_decoracion.activo -> igual, para decoraciones.
-- 3. color_evento (tabla nueva) -> antes el color del evento era una lista
--    fija escrita en Color.jsp; ahora es un catálogo real administrable,
--    con imagen opcional. Se pre-cargan los 6 colores que ya existían para
--    no romper nada visualmente.
-- =====================================================================

USE `reservation_lb`;

ALTER TABLE `tipo_evento`
    ADD COLUMN `imagen` VARCHAR(255) NULL AFTER `valor_evento`,
    ADD COLUMN `activo` TINYINT(1) NOT NULL DEFAULT 1 AFTER `imagen`;

ALTER TABLE `tipo_decoracion`
    ADD COLUMN `imagen` VARCHAR(255) NULL AFTER `valor_decoracion`,
    ADD COLUMN `activo` TINYINT(1) NOT NULL DEFAULT 1 AFTER `imagen`;

CREATE TABLE IF NOT EXISTS `reservation_lb`.`color_evento` (
  `id_color` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `codigo_hex` VARCHAR(7) NOT NULL,
  `imagen` VARCHAR(255) NULL,
  `activo` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_color`)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8;

INSERT INTO `color_evento` (`nombre`, `codigo_hex`) VALUES
('Rojo', '#C0392B'),
('Azul', '#2E5C99'),
('Amarillo', '#E8C547'),
('Verde', '#3F7D45'),
('Negro', '#222222'),
('Blanco', '#FFFFFF');

package Pruebas;

import Controlador.RolDAO;
import java.util.Scanner;

public class PruebaActivarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolDAO rolDAO = new RolDAO();

        System.out.println("=== PRUEBA: ACTIVAR ROL ===");
        System.out.print("Ingrese el ID del rol a activar: ");
        int idRol = Integer.parseInt(scanner.nextLine());

        boolean exito = rolDAO.activarRol(idRol);

        if (exito) {
            System.out.println("\n[ÉXITO] El estado del rol cambió a 'Activo'.");
        } else {
            System.out.println("\n[ERROR] No se pudo activar el rol.");
        }

        scanner.close();
    }
}
package Pruebas;

import Controlador.TipoEventoDAO;
import Modelo.TipoEvento;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaInsertarTipoEvento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoEventoDAO tipoEventoDAO = new TipoEventoDAO();
        TipoEvento nuevoEvento = new TipoEvento();

        System.out.println("=== PRUEBA: INSERTAR TIPO EVENTO ===");

        System.out.print("Nombre del Evento: ");
        nuevoEvento.setNombreEvento(scanner.nextLine());

        System.out.print("Descripción del Evento: ");
        nuevoEvento.setDescripcion(scanner.nextLine());

        System.out.print("Valor/Precio del Evento: ");
        nuevoEvento.setValorEvento(new BigDecimal(scanner.nextLine()));

        boolean exito = tipoEventoDAO.insertarTipoEvento(nuevoEvento);

        if (exito) {
            System.out.println("\n[ÉXITO] El tipo de evento fue registrado correctamente.");
        } else {
            System.out.println("\n[ERROR] No se pudo guardar el tipo de evento en la base de datos.");
        }

        scanner.close();
    }
}
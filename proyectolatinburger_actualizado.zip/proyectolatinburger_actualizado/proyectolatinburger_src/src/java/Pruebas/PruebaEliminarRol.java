package Pruebas;

import Controlador.RolDAO;
import java.util.Scanner;

public class PruebaEliminarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolDAO rolDAO = new RolDAO();

        System.out.println("=== PRUEBA: ELIMINAR ROL (FÍSICO) ===");
        System.out.print("Ingrese el ID del rol que desea eliminar permanentemente: ");
        int idRol = Integer.parseInt(scanner.nextLine());

        System.out.print("¿Confirma la eliminación permanente? (s/n): ");
        String confirmacion = scanner.nextLine();

        if (confirmacion.equalsIgnoreCase("s")) {
            boolean exito = rolDAO.eliminarRol(idRol);

            if (exito) {
                System.out.println("\n[ÉXITO] Rol eliminado físicamente de la base de datos.");
            } else {
                System.out.println("\n[ERROR] No se pudo eliminar el rol.");
            }
        } else {
            System.out.println("\n[CANCELADO] La operación de eliminación fue cancelada.");
        }

        scanner.close();
    }
}
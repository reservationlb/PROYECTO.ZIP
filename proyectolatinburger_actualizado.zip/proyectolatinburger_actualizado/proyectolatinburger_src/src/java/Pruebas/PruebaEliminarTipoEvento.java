package Pruebas;

import Controlador.TipoEventoDAO;
import java.util.Scanner;

public class PruebaEliminarTipoEvento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoEventoDAO tipoEventoDAO = new TipoEventoDAO();

        System.out.println("=== PRUEBA: ELIMINAR TIPO EVENTO ===");
        System.out.print("Ingrese el ID del tipo de evento que desea eliminar: ");
        int idTipoEvento = Integer.parseInt(scanner.nextLine());

        System.out.print("¿Confirma la eliminación permanente? (s/n): ");
        String confirmacion = scanner.nextLine();

        if (confirmacion.equalsIgnoreCase("s")) {
            boolean exito = tipoEventoDAO.eliminarTipoEvento(idTipoEvento);

            if (exito) {
                System.out.println("\n[ÉXITO] Tipo de evento eliminado de la base de datos.");
            } else {
                System.out.println("\n[ERROR] No se pudo eliminar el tipo de evento.");
            }
        } else {
            System.out.println("\n[CANCELADO] La operación de eliminación fue cancelada.");
        }

        scanner.close();
    }
}
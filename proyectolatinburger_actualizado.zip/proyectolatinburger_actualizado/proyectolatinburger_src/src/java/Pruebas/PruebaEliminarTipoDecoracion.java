package Pruebas;

import Controlador.TipoDecoracionDAO;
import java.util.Scanner;

public class PruebaEliminarTipoDecoracion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDecoracionDAO tipoDecoDAO = new TipoDecoracionDAO();

        System.out.println("=== PRUEBA: ELIMINAR TIPO DECORACION ===");
        System.out.print("Ingrese el ID del tipo de decoración que desea eliminar: ");
        int idTipoDecoracion = Integer.parseInt(scanner.nextLine());

        System.out.print("¿Confirma la eliminación permanente? (s/n): ");
        String confirmacion = scanner.nextLine();

        if (confirmacion.equalsIgnoreCase("s")) {
            boolean exito = tipoDecoDAO.eliminarTipoDecoracion(idTipoDecoracion);

            if (exito) {
                System.out.println("\n[ÉXITO] Tipo de decoración eliminado de la base de datos.");
            } else {
                System.out.println("\n[ERROR] No se pudo eliminar el tipo de decoración.");
            }
        } else {
            System.out.println("\n[CANCELADO] La operación de eliminación fue cancelada.");
        }

        scanner.close();
    }
}
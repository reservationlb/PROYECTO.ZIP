package Pruebas;

import Controlador.TipoEventoDAO;
import Modelo.TipoEvento;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaActualizarTipoEvento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoEventoDAO tipoEventoDAO = new TipoEventoDAO();
        TipoEvento eventoUpdate = new TipoEvento();

        System.out.println("=== PRUEBA: ACTUALIZAR TIPO EVENTO ===");

        System.out.print("Ingrese el ID del tipo de evento a modificar: ");
        eventoUpdate.setIdTipoEvento(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nuevo Nombre del Evento: ");
        eventoUpdate.setNombreEvento(scanner.nextLine());

        System.out.print("Nueva Descripción: ");
        eventoUpdate.setDescripcion(scanner.nextLine());

        System.out.print("Nuevo Valor/Precio: ");
        eventoUpdate.setValorEvento(new BigDecimal(scanner.nextLine()));

        boolean exito = tipoEventoDAO.actualizarTipoEvento(eventoUpdate);

        if (exito) {
            System.out.println("\n[ÉXITO] Datos del tipo de evento actualizados en la base de datos.");
        } else {
            System.out.println("\n[ERROR] No se pudo actualizar (Verifica si el ID introducido existe).");
        }

        scanner.close();
    }
}
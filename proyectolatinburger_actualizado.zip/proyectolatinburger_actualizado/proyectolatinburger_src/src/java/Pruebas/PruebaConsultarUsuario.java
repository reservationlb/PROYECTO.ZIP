package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.Scanner;

public class PruebaConsultarUsuario {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO usuarioDAO = new UsuarioDAO();

        System.out.println("=== PRUEBA: CONSULTAR USUARIO ===");
        System.out.print("Ingrese el número de documento a buscar: ");
        String documento = scanner.nextLine();

        Usuario u = usuarioDAO.consultarUsuario(documento);

        if (u != null) {
            System.out.println("\n[RESULTADO] Usuario encontrado:");
            System.out.println("ID: " + u.getIdUsuario());
            System.out.println("Nombre: " + u.getNombre() + " " + u.getApellido());
            System.out.println("Documento: " + u.getNumeroDocumento());
            System.out.println("Teléfono: " + u.getTelefono());
            System.out.println("Correo: " + u.getCorreo());
            System.out.println("ID Rol: " + u.getRolIdRol());
            System.out.println("ID Tipo Documento: " + u.getTipoDocumentoIdTipoDocumento());
        } else {
            System.out.println("\n[RESULTADO] No existe ningún usuario con el documento: " + documento);
        }

        scanner.close();
    }
}
package Pruebas;

import Controlador.DisponibilidadDAO;
import Modelo.Disponibilidad;
import java.sql.Date;
import java.sql.Time;
import java.util.Scanner;

public class PruebaInsertarDisponibilidad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DisponibilidadDAO disponibilidadDAO = new DisponibilidadDAO();
        Disponibilidad nuevaDisp = new Disponibilidad();

        System.out.println("=== PRUEBA: INSERTAR DISPONIBILIDAD ===");

        try {
            System.out.print("Fecha (Formato AAAA-MM-DD, ej. 2026-08-20): ");
            nuevaDisp.setFecha(Date.valueOf(scanner.nextLine()));

            System.out.print("Hora (Formato HH:MM:SS, ej. 14:30:00): ");
            nuevaDisp.setHora(Time.valueOf(scanner.nextLine()));

            System.out.print("Estado (ej. Activo, Disponible, Reservado): ");
            nuevaDisp.setEstado(scanner.nextLine());

            boolean exito = disponibilidadDAO.insertarDisponibilidad(nuevaDisp);

            if (exito) {
                System.out.println("\n[ÉXITO] La disponibilidad fue registrada correctamente.");
            } else {
                System.out.println("\n[ERROR] No se pudo guardar la disponibilidad.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("\n[ERROR] Formato de fecha u hora inválido. Asegúrate de usar YYYY-MM-DD y HH:MM:SS.");
        }

        scanner.close();
    }
}
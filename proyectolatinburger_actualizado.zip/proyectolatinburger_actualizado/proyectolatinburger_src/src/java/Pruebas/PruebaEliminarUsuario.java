package Pruebas;

import Controlador.UsuarioDAO;
import java.util.Scanner;

public class PruebaEliminarUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO usuarioDAO = new UsuarioDAO();

        System.out.println("=== PRUEBA: ELIMINAR USUARIO (FÍSICO) ===");
        System.out.print("Ingrese el ID del usuario que desea eliminar definitivamente: ");
        int idUsuario = Integer.parseInt(scanner.nextLine());

        System.out.print("¿Confirma la eliminación permanente? (s/n): ");
        String confirmacion = scanner.nextLine();

        if (confirmacion.equalsIgnoreCase("s")) {
            boolean exito = usuarioDAO.eliminarUsuario(idUsuario);

            if (exito) {
                System.out.println("\n[ÉXITO] Usuario eliminado de la base de datos.");
            } else {
                System.out.println("\n[ERROR] No se pudo eliminar el usuario.");
            }
        } else {
            System.out.println("\n[CANCELADO] La operación de eliminación fue cancelada.");
        }

        scanner.close();
    }
}
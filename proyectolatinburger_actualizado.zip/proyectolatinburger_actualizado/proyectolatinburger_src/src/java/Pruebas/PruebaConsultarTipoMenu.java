package Pruebas;

import Controlador.TipoMenuDAO;
import Modelo.TipoMenu;
import java.util.Scanner;

public class PruebaConsultarTipoMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoMenuDAO tipoMenuDAO = new TipoMenuDAO();

        System.out.println("=== PRUEBA: CONSULTAR TIPO MENU ===");
        System.out.print("Ingrese el ID del tipo de menú a buscar: ");
        int idTipoMenu = Integer.parseInt(scanner.nextLine());

        TipoMenu menu = tipoMenuDAO.consultarTipoMenu(idTipoMenu);

        if (menu != null) {
            System.out.println("\n[RESULTADO] Menú encontrado:");
            System.out.println("ID: " + menu.getIdTipoMenu());
            System.out.println("Nombre: " + menu.getNombreMenu());
            System.out.println("Descripción: " + menu.getDescripcionMenu());
            System.out.println("Valor: $" + menu.getValorMenu());
        } else {
            System.out.println("\n[RESULTADO] No se encontró ningún tipo de menú con el ID: " + idTipoMenu);
        }

        scanner.close();
    }
}
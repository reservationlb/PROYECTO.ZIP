package Pruebas;

import Controlador.UsuarioDAO;
import java.util.Scanner;

public class PruebaActivarUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO usuarioDAO = new UsuarioDAO();

        System.out.println("=== PRUEBA: ACTIVAR USUARIO ===");
        System.out.print("Ingrese el ID del usuario a activar: ");
        int idUsuario = Integer.parseInt(scanner.nextLine());

        boolean exito = usuarioDAO.activarUsuario(idUsuario);

        if (exito) {
            System.out.println("\n[ÉXITO] El usuario pasó a estado 'Activo'.");
        } else {
            System.out.println("\n[ERROR] No se pudo activar el usuario.");
        }

        scanner.close();
    }
}
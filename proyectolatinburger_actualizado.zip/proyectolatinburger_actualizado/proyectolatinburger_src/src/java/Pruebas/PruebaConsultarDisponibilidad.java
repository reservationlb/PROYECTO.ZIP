package Pruebas;

import Controlador.DisponibilidadDAO;
import Modelo.Disponibilidad;
import java.util.Scanner;

public class PruebaConsultarDisponibilidad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DisponibilidadDAO disponibilidadDAO = new DisponibilidadDAO();

        System.out.println("=== PRUEBA: CONSULTAR DISPONIBILIDAD ===");
        System.out.print("Ingrese el ID de la disponibilidad a buscar: ");
        int idDisponibilidad = Integer.parseInt(scanner.nextLine());

        Disponibilidad disp = disponibilidadDAO.consultarDisponibilidad(idDisponibilidad);

        if (disp != null) {
            System.out.println("\n[RESULTADO] Disponibilidad encontrada:");
            System.out.println("ID: " + disp.getIdDisponibilidad());
            System.out.println("Fecha: " + disp.getFecha());
            System.out.println("Hora: " + disp.getHora());
            System.out.println("Estado: " + disp.getEstado());
        } else {
            System.out.println("\n[RESULTADO] No se encontró ninguna disponibilidad con el ID: " + idDisponibilidad);
        }

        scanner.close();
    }
}
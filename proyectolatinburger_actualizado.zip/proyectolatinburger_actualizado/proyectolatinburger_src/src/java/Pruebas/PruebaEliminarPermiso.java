package Pruebas;

import Controlador.PermisoDAO;
import java.util.Scanner;

public class PruebaEliminarPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisoDAO permisoDAO = new PermisoDAO();

        System.out.println("=== PRUEBA: ELIMINAR PERMISO ===");
        System.out.print("Ingrese el ID del permiso que desea eliminar: ");
        int idPermiso = Integer.parseInt(scanner.nextLine());

        System.out.print("¿Confirma la eliminación permanente? (s/n): ");
        String confirmacion = scanner.nextLine();

        if (confirmacion.equalsIgnoreCase("s")) {
            boolean exito = permisoDAO.eliminarPermiso(idPermiso);

            if (exito) {
                System.out.println("\n[ÉXITO] Permiso eliminado de la base de datos.");
            } else {
                System.out.println("\n[ERROR] No se pudo eliminar el permiso (Verifica que no esté en uso en 'permiso_has_rol').");
            }
        } else {
            System.out.println("\n[CANCELADO] La operación de eliminación fue cancelada.");
        }

        scanner.close();
    }
}

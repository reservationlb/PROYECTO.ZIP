package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner;

public class PruebaInsertarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolDAO rolDAO = new RolDAO();
        Rol nuevoRol = new Rol();

        System.out.println("=== PRUEBA: INSERTAR ROL ===");

        System.out.print("Descripción del Rol (ej. Administrador, Cliente): ");
        nuevoRol.setDescripcion(scanner.nextLine());

        System.out.print("Estado del Rol (Activo/Inactivo): ");
        nuevoRol.setEstado(scanner.nextLine());

        boolean exito = rolDAO.insertarRol(nuevoRol);

        if (exito) {
            System.out.println("\n[ÉXITO] El rol fue registrado correctamente.");
        } else {
            System.out.println("\n[ERROR] No se pudo guardar el rol en la base de datos.");
        }

        scanner.close();
    }
}
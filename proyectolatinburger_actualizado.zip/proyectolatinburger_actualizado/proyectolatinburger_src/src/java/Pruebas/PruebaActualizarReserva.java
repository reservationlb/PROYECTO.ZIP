package Pruebas;

import Controlador.ReservaDAO;
import Modelo.Reserva;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.util.Scanner;

public class PruebaActualizarReserva {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ReservaDAO reservaDAO = new ReservaDAO();
        Reserva reservaUpdate = new Reserva();

        System.out.println("=== PRUEBA: ACTUALIZAR RESERVA ===");

        System.out.print("Ingrese el ID de la reserva a modificar: ");
        reservaUpdate.setIdReserva(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nueva Fecha (AAAA-MM-DD): ");
        reservaUpdate.setFecha(Date.valueOf(scanner.nextLine()));

        System.out.print("Nueva Hora (HH:MM:SS): ");
        reservaUpdate.setHora(Time.valueOf(scanner.nextLine()));

        System.out.print("Nuevo Número de Personas: ");
        reservaUpdate.setNumeroPersona(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nuevo Valor de la Reserva: ");
        reservaUpdate.setValorReserva(new BigDecimal(scanner.nextLine()));

        System.out.print("Nuevo ID Disponibilidad: ");
        reservaUpdate.setDisponibilidadIdDisponibilidad(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nuevo ID Tipo Menú: ");
        reservaUpdate.setTipoMenuIdTipoMenu(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nuevo ID Tipo Decoración: ");
        reservaUpdate.setTipoDecoracionIdTipoDecoracion(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nuevo ID Tipo Evento: ");
        reservaUpdate.setTipoEventoIdTipoEvento(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nuevo ID Usuario: ");
        reservaUpdate.setUsuarioIdUsuario(Integer.parseInt(scanner.nextLine()));

        boolean exito = reservaDAO.actualizarReserva(reservaUpdate);

        if (exito) {
            System.out.println("\n[ÉXITO] La reserva fue actualizada correctamente.");
        } else {
            System.out.println("\n[ERROR] No se pudo actualizar (Verifica si el ID de la reserva existe).");
        }

        scanner.close();
    }
}
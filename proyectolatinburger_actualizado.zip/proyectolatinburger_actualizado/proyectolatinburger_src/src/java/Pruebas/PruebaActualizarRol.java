package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner;

public class PruebaActualizarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolDAO rolDAO = new RolDAO();
        Rol rolUpdate = new Rol();

        System.out.println("=== PRUEBA: ACTUALIZAR ROL ===");

        System.out.print("Ingrese el ID del rol a modificar: ");
        rolUpdate.setIdRol(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nueva Descripción: ");
        rolUpdate.setDescripcion(scanner.nextLine());

        System.out.print("Nuevo Estado (Activo/Inactivo): ");
        rolUpdate.setEstado(scanner.nextLine());

        boolean exito = rolDAO.actualizarRol(rolUpdate);

        if (exito) {
            System.out.println("\n[ÉXITO] Datos del rol actualizados en la base de datos.");
        } else {
            System.out.println("\n[ERROR] No se pudo actualizar (Verifica si el ID introducido existe).");
        }

        scanner.close();
    }
}
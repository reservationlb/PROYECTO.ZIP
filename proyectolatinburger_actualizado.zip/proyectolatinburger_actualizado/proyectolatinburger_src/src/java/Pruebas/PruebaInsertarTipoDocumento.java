package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebaInsertarTipoDocumento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDocumentoDAO tipoDocDAO = new TipoDocumentoDAO();
        TipoDocumento nuevoTipoDoc = new TipoDocumento();

        System.out.println("=== PRUEBA: INSERTAR TIPO DOCUMENTO ===");

        System.out.print("ID del Tipo de Documento: ");
        nuevoTipoDoc.setIdTipoDocumento(Integer.parseInt(scanner.nextLine()));

        System.out.print("Descripción (ej. Cédula de Ciudadanía, Pasaporte): ");
        nuevoTipoDoc.setDescripcion(scanner.nextLine());

        boolean exito = tipoDocDAO.insertarTipoDocumento(nuevoTipoDoc);

        if (exito) {
            System.out.println("\n[ÉXITO] El tipo de documento fue registrado correctamente.");
        } else {
            System.out.println("\n[ERROR] No se pudo guardar el tipo de documento en la base de datos.");
        }

        scanner.close();
    }
}
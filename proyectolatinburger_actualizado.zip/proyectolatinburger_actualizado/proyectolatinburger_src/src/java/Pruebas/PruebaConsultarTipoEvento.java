package Pruebas;

import Controlador.TipoEventoDAO;
import Modelo.TipoEvento;
import java.util.Scanner;

public class PruebaConsultarTipoEvento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoEventoDAO tipoEventoDAO = new TipoEventoDAO();

        System.out.println("=== PRUEBA: CONSULTAR TIPO EVENTO ===");
        System.out.print("Ingrese el ID del tipo de evento a buscar: ");
        int idTipoEvento = Integer.parseInt(scanner.nextLine());

        TipoEvento evento = tipoEventoDAO.consultarTipoEvento(idTipoEvento);

        if (evento != null) {
            System.out.println("\n[RESULTADO] Tipo de evento encontrado:");
            System.out.println("ID: " + evento.getIdTipoEvento());
            System.out.println("Nombre: " + evento.getNombreEvento());
            System.out.println("Descripción: " + evento.getDescripcion());
            System.out.println("Valor: $" + evento.getValorEvento());
        } else {
            System.out.println("\n[RESULTADO] No se encontró ningún tipo de evento con el ID: " + idTipoEvento);
        }

        scanner.close();
    }
}
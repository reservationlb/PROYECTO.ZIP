package Pruebas;

import Controlador.PermisoDAO;
import Modelo.Permiso;
import java.util.Scanner;

public class PruebaConsultarPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisoDAO permisoDAO = new PermisoDAO();

        System.out.println("=== PRUEBA: CONSULTAR PERMISO ===");
        System.out.print("Ingrese el ID del permiso a buscar: ");
        int idPermiso = Integer.parseInt(scanner.nextLine());

        Permiso permiso = permisoDAO.consultarPermiso(idPermiso);

        if (permiso != null) {
            System.out.println("\n[RESULTADO] Permiso encontrado:");
            System.out.println("ID: " + permiso.getIdPermiso());
            System.out.println("Descripción: " + permiso.getDescripcion());
        } else {
            System.out.println("\n[RESULTADO] No se encontró ningún permiso con el ID: " + idPermiso);
        }

        scanner.close();
    }
}
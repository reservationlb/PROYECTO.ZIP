package Pruebas;

import Controlador.ReservaDAO;
import Modelo.Reserva;
import java.util.Scanner;

public class PruebaConsultarReserva {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ReservaDAO reservaDAO = new ReservaDAO();

        System.out.println("=== PRUEBA: CONSULTAR RESERVA ===");
        System.out.print("Ingrese el ID de la reserva a buscar: ");
        int idReserva = Integer.parseInt(scanner.nextLine());

        Reserva reserva = reservaDAO.consultarReserva(idReserva);

        if (reserva != null) {
            System.out.println("\n[RESULTADO] Reserva encontrada:");
            System.out.println("ID Reserva: " + reserva.getIdReserva());
            System.out.println("Fecha: " + reserva.getFecha());
            System.out.println("Hora: " + reserva.getHora());
            System.out.println("Personas: " + reserva.getNumeroPersona());
            System.out.println("Valor: $" + reserva.getValorReserva());
            System.out.println("ID Disponibilidad: " + reserva.getDisponibilidadIdDisponibilidad());
            System.out.println("ID Tipo Menú: " + reserva.getTipoMenuIdTipoMenu());
            System.out.println("ID Tipo Decoración: " + reserva.getTipoDecoracionIdTipoDecoracion());
            System.out.println("ID Tipo Evento: " + reserva.getTipoEventoIdTipoEvento());
            System.out.println("ID Usuario: " + reserva.getUsuarioIdUsuario());
        } else {
            System.out.println("\n[RESULTADO] No se encontró ninguna reserva con el ID: " + idReserva);
        }

        scanner.close();
    }
}
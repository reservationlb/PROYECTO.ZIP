package Pruebas;

import Controlador.PermisoDAO;
import Modelo.Permiso;
import java.util.Scanner;

public class PruebaInsertarPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisoDAO permisoDAO = new PermisoDAO();
        Permiso nuevoPermiso = new Permiso();

        System.out.println("=== PRUEBA: INSERTAR PERMISO ===");

        System.out.print("Descripción del Permiso (ej. Crear Reserva, Ver Reportes): ");
        nuevoPermiso.setDescripcion(scanner.nextLine());

        boolean exito = permisoDAO.insertarPermiso(nuevoPermiso);

        if (exito) {
            System.out.println("\n[ÉXITO] El permiso fue registrado correctamente.");
        } else {
            System.out.println("\n[ERROR] No se pudo guardar el permiso en la base de datos.");
        }

        scanner.close();
    }
}
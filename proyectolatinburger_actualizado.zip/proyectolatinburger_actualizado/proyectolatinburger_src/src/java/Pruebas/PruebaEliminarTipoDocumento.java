package Pruebas;

import Controlador.TipoDocumentoDAO;
import java.util.Scanner;

public class PruebaEliminarTipoDocumento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDocumentoDAO tipoDocDAO = new TipoDocumentoDAO();

        System.out.println("=== PRUEBA: ELIMINAR TIPO DOCUMENTO ===");
        System.out.print("Ingrese el ID del tipo de documento que desea eliminar: ");
        int idTipoDoc = Integer.parseInt(scanner.nextLine());

        System.out.print("¿Confirma la eliminación permanente? (s/n): ");
        String confirmacion = scanner.nextLine();

        if (confirmacion.equalsIgnoreCase("s")) {
            boolean exito = tipoDocDAO.eliminarTipoDocumento(idTipoDoc);

            if (exito) {
                System.out.println("\n[ÉXITO] Tipo de documento eliminado de la base de datos.");
            } else {
                System.out.println("\n[ERROR] No se pudo eliminar el tipo de documento.");
            }
        } else {
            System.out.println("\n[CANCELADO] La operación de eliminación fue cancelada.");
        }

        scanner.close();
    }
}
package Pruebas;

import Controlador.ReservaDAO;
import java.util.Scanner;

public class PruebaEliminarReserva {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ReservaDAO reservaDAO = new ReservaDAO();

        System.out.println("=== PRUEBA: ELIMINAR RESERVA ===");
        System.out.print("Ingrese el ID de la reserva que desea eliminar: ");
        int idReserva = Integer.parseInt(scanner.nextLine());

        System.out.print("¿Confirma la eliminación permanente? (s/n): ");
        String confirmacion = scanner.nextLine();

        if (confirmacion.equalsIgnoreCase("s")) {
            boolean exito = reservaDAO.eliminarReserva(idReserva);

            if (exito) {
                System.out.println("\n[ÉXITO] Reserva eliminada de la base de datos.");
            } else {
                System.out.println("\n[ERROR] No se pudo eliminar la reserva.");
            }
        } else {
            System.out.println("\n[CANCELADO] La operación de eliminación fue cancelada.");
        }

        scanner.close();
    }
}
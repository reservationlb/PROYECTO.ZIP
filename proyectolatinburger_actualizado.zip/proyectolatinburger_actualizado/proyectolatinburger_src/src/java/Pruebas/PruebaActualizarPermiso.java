package Pruebas;

import Controlador.PermisoDAO;
import Modelo.Permiso;
import java.util.Scanner;

public class PruebaActualizarPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisoDAO permisoDAO = new PermisoDAO();
        Permiso permisoUpdate = new Permiso();

        System.out.println("=== PRUEBA: ACTUALIZAR PERMISO ===");

        System.out.print("Ingrese el ID del permiso a modificar: ");
        permisoUpdate.setIdPermiso(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nueva Descripción: ");
        permisoUpdate.setDescripcion(scanner.nextLine());

        boolean exito = permisoDAO.actualizarPermiso(permisoUpdate);

        if (exito) {
            System.out.println("\n[ÉXITO] Datos del permiso actualizados en la base de datos.");
        } else {
            System.out.println("\n[ERROR] No se pudo actualizar (Verifica si el ID introducido existe).");
        }

        scanner.close();
    }
}
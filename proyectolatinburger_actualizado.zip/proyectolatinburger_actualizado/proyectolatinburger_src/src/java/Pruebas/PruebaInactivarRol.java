package Pruebas;

import Controlador.RolDAO;
import java.util.Scanner;

public class PruebaInactivarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolDAO rolDAO = new RolDAO();

        System.out.println("=== PRUEBA: INACTIVAR ROL ===");
        System.out.print("Ingrese el ID del rol a inactivar: ");
        int idRol = Integer.parseInt(scanner.nextLine());

        boolean exito = rolDAO.inactivarRol(idRol);

        if (exito) {
            System.out.println("\n[ÉXITO] El estado del rol cambió a 'Inactivo'.");
        } else {
            System.out.println("\n[ERROR] No se pudo inactivar el rol.");
        }

        scanner.close();
    }
}
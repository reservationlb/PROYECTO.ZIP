package Pruebas;

import Controlador.DisponibilidadDAO;
import Modelo.Disponibilidad;
import java.sql.Date;
import java.sql.Time;
import java.util.Scanner;

public class PruebaActualizarDisponibilidad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DisponibilidadDAO disponibilidadDAO = new DisponibilidadDAO();
        Disponibilidad dispUpdate = new Disponibilidad();

        System.out.println("=== PRUEBA: ACTUALIZAR DISPONIBILIDAD ===");

        try {
            System.out.print("ID de la disponibilidad a modificar: ");
            dispUpdate.setIdDisponibilidad(Integer.parseInt(scanner.nextLine()));

            System.out.print("Nueva Fecha (AAAA-MM-DD): ");
            dispUpdate.setFecha(Date.valueOf(scanner.nextLine()));

            System.out.print("Nueva Hora (HH:MM:SS): ");
            dispUpdate.setHora(Time.valueOf(scanner.nextLine()));

            System.out.print("Nuevo Estado: ");
            dispUpdate.setEstado(scanner.nextLine());

            boolean exito = disponibilidadDAO.actualizarDisponibilidad(dispUpdate);

            if (exito) {
                System.out.println("\n[ÉXITO] Disponibilidad actualizada correctamente.");
            } else {
                System.out.println("\n[ERROR] No se pudo actualizar (Verifica si el ID introducido existe).");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("\n[ERROR] Formato de fecha u hora inválido.");
        }

        scanner.close();
    }
}
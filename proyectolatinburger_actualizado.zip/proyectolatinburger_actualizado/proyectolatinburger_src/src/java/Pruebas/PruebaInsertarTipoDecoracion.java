package Pruebas;

import Controlador.TipoDecoracionDAO;
import Modelo.TipoDecoracion;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaInsertarTipoDecoracion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDecoracionDAO tipoDecoDAO = new TipoDecoracionDAO();
        TipoDecoracion nuevaDeco = new TipoDecoracion();

        System.out.println("=== PRUEBA: INSERTAR TIPO DECORACION ===");

        System.out.print("Nombre de la Decoración: ");
        nuevaDeco.setNombreDecoracion(scanner.nextLine());

        System.out.print("Descripción: ");
        nuevaDeco.setDescripcion(scanner.nextLine());

        System.out.print("Valor/Precio de la Decoración: ");
        nuevaDeco.setValorDecoracion(new BigDecimal(scanner.nextLine()));

        boolean exito = tipoDecoDAO.insertarTipoDecoracion(nuevaDeco);

        if (exito) {
            System.out.println("\n[ÉXITO] El tipo de decoración fue registrado correctamente.");
        } else {
            System.out.println("\n[ERROR] No se pudo guardar el tipo de decoración en la base de datos.");
        }

        scanner.close();
    }
}
package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner;

public class PruebaConsultarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolDAO rolDAO = new RolDAO();

        System.out.println("=== PRUEBA: CONSULTAR ROL ===");
        System.out.print("Ingrese el ID del rol a buscar: ");
        int idRol = Integer.parseInt(scanner.nextLine());

        Rol rol = rolDAO.consultarRol(idRol);

        if (rol != null) {
            System.out.println("\n[RESULTADO] Rol encontrado:");
            System.out.println("ID: " + rol.getIdRol());
            System.out.println("Descripción: " + rol.getDescripcion());
            System.out.println("Estado: " + rol.getEstado());
        } else {
            System.out.println("\n[RESULTADO] No se encontró ningún rol con el ID: " + idRol);
        }

        scanner.close();
    }
}
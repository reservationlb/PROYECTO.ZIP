package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.sql.Date;
import java.util.Scanner;

public class PruebaInsertarUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario nuevoUsuario = new Usuario();

        System.out.println("=== PRUEBA: INSERTAR USUARIO ===");
        
        System.out.print("Nombre: ");
        nuevoUsuario.setNombre(scanner.nextLine());

        System.out.print("Apellido: ");
        nuevoUsuario.setApellido(scanner.nextLine());

        System.out.print("Dirección: ");
        nuevoUsuario.setDireccion(scanner.nextLine());

        System.out.print("Documento: ");
        nuevoUsuario.setDocumento(scanner.nextLine());

        System.out.print("Teléfono: ");
        nuevoUsuario.setTelefono(scanner.nextLine());

        System.out.print("Fecha Nacimiento (YYYY-MM-DD): ");
        nuevoUsuario.setFechaNacimiento(Date.valueOf(scanner.nextLine()));

        System.out.print("Fecha Vencimiento Clave (YYYY-MM-DD): ");
        nuevoUsuario.setFechaDeVencimientoClave(Date.valueOf(scanner.nextLine()));

        System.out.print("Fecha Autorización Datos (YYYY-MM-DD): ");
        nuevoUsuario.setAutorizacionDato(Date.valueOf(scanner.nextLine()));

        System.out.print("Username: ");
        nuevoUsuario.setUserName(scanner.nextLine());

        System.out.print("Password: ");
        nuevoUsuario.setPassword(scanner.nextLine());

        System.out.print("Estado (Ej: Activo): ");
        nuevoUsuario.setEstado(scanner.nextLine());

        System.out.print("ID Rol (Número): ");
        nuevoUsuario.setRolIdRol(Integer.parseInt(scanner.nextLine()));

        System.out.print("ID Tipo Documento (Número): ");
        nuevoUsuario.setTipoDocumentoIdTipoDocumento(Integer.parseInt(scanner.nextLine()));

        boolean exito = usuarioDAO.insertarUsuario(nuevoUsuario);

        if (exito) {
            System.out.println("\n[ÉXITO] El usuario fue registrado correctamente.");
        } else {
            System.out.println("\n[ERROR] No se pudo guardar el usuario en la base de datos.");
        }

        scanner.close();
    }
}
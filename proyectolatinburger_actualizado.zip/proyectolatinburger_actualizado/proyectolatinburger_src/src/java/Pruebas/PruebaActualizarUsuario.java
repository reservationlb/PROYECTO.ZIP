package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.sql.Date;
import java.util.Scanner;

public class PruebaActualizarUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario usuarioUpdate = new Usuario();

        System.out.println("=== PRUEBA: ACTUALIZAR USUARIO ===");
        
        System.out.print("Ingrese el ID del usuario a modificar: ");
        usuarioUpdate.setIdUsuario(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nuevo Nombre: ");
        usuarioUpdate.setNombre(scanner.nextLine());

        System.out.print("Nuevo Apellido: ");
        usuarioUpdate.setApellido(scanner.nextLine());

        System.out.print("Nueva Dirección: ");
        usuarioUpdate.setDireccion(scanner.nextLine());

        System.out.print("Nuevo Documento: ");
        usuarioUpdate.setDocumento(scanner.nextLine());

        System.out.print("Nuevo Teléfono: ");
        usuarioUpdate.setTelefono(scanner.nextLine());

        System.out.print("Nueva Fecha Nacimiento (YYYY-MM-DD): ");
        usuarioUpdate.setFechaNacimiento(Date.valueOf(scanner.nextLine()));

        System.out.print("Nueva Fecha Vencimiento Clave (YYYY-MM-DD): ");
        usuarioUpdate.setFechaDeVencimientoClave(Date.valueOf(scanner.nextLine()));

        System.out.print("Nueva Fecha Autorización Datos (YYYY-MM-DD): ");
        usuarioUpdate.setAutorizacionDato(Date.valueOf(scanner.nextLine()));

        System.out.print("Nuevo Username: ");
        usuarioUpdate.setUserName(scanner.nextLine());

        System.out.print("Nueva Password: ");
        usuarioUpdate.setPassword(scanner.nextLine());

        System.out.print("Nuevo Estado: ");
        usuarioUpdate.setEstado(scanner.nextLine());

        System.out.print("Nuevo ID Rol (Número): ");
        usuarioUpdate.setRolIdRol(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nuevo ID Tipo Documento (Número): ");
        usuarioUpdate.setTipoDocumentoIdTipoDocumento(Integer.parseInt(scanner.nextLine()));

        boolean exito = usuarioDAO.actualizarUsuario(usuarioUpdate);

        if (exito) {
            System.out.println("\n[ÉXITO] Datos del usuario actualizados en la base de datos.");
        } else {
            System.out.println("\n[ERROR] No se pudo actualizar (Verifica si el ID introducido existe).");
        }

        scanner.close();
    }
}
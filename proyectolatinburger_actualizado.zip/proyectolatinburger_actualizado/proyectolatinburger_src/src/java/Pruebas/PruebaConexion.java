/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.Conexion;
import java.sql.Connection;

/**
 *
 * @author Aprendiz
 */
public class PruebaConexion {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Todo code application logic here
        
 Conexion reservation_lb = new Conexion();
 Connection con = reservation_lb.getConn();
 
    }
}

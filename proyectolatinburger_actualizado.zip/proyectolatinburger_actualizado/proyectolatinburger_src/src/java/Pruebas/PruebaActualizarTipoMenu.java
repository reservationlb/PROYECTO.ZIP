package Pruebas;

import Controlador.TipoMenuDAO;
import Modelo.TipoMenu;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaActualizarTipoMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoMenuDAO tipoMenuDAO = new TipoMenuDAO();
        TipoMenu menuUpdate = new TipoMenu();

        System.out.println("=== PRUEBA: ACTUALIZAR TIPO MENU ===");

        System.out.print("Ingrese el ID del tipo de menú a modificar: ");
        menuUpdate.setIdTipoMenu(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nuevo Nombre del Menú: ");
        menuUpdate.setNombreMenu(scanner.nextLine());

        System.out.print("Nueva Descripción del Menú: ");
        menuUpdate.setDescripcionMenu(scanner.nextLine());

        System.out.print("Nuevo Valor/Precio: ");
        menuUpdate.setValorMenu(new BigDecimal(scanner.nextLine()));

        boolean exito = tipoMenuDAO.actualizarTipoMenu(menuUpdate);

        if (exito) {
            System.out.println("\n[ÉXITO] Datos del tipo de menú actualizados en la base de datos.");
        } else {
            System.out.println("\n[ERROR] No se pudo actualizar (Verifica si el ID introducido existe).");
        }

        scanner.close();
    }
}
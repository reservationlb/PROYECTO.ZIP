package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebaActualizarTipoDocumento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDocumentoDAO tipoDocDAO = new TipoDocumentoDAO();
        TipoDocumento tipoDocUpdate = new TipoDocumento();

        System.out.println("=== PRUEBA: ACTUALIZAR TIPO DOCUMENTO ===");

        System.out.print("Ingrese el ID del tipo de documento a modificar: ");
        tipoDocUpdate.setIdTipoDocumento(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nueva Descripción: ");
        tipoDocUpdate.setDescripcion(scanner.nextLine());

        boolean exito = tipoDocDAO.actualizarTipoDocumento(tipoDocUpdate);

        if (exito) {
            System.out.println("\n[ÉXITO] Tipo de documento actualizado en la base de datos.");
        } else {
            System.out.println("\n[ERROR] No se pudo actualizar (Verifica si el ID introducido existe).");
        }

        scanner.close();
    }
}
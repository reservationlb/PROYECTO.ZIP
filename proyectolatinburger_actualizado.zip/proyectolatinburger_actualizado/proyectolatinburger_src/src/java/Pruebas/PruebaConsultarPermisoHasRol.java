package Pruebas;

import Controlador.PermisoHasRolDAO;
import Modelo.PermisoHasRol;
import java.util.Scanner;

public class PruebaConsultarPermisoHasRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisoHasRolDAO permisoHasRolDAO = new PermisoHasRolDAO();

        System.out.println("=== PRUEBA: CONSULTAR PERMISO HAS ROL ===");
        System.out.print("Ingrese el ID del Permiso: ");
        int permisoId = Integer.parseInt(scanner.nextLine());

        System.out.print("Ingrese el ID del Rol: ");
        int rolId = Integer.parseInt(scanner.nextLine());

        PermisoHasRol relacion = permisoHasRolDAO.consultarPermisoHasRol(permisoId, rolId);

        if (relacion != null) {
            System.out.println("\n[RESULTADO] Asignación encontrada:");
            System.out.println("ID Permiso: " + relacion.getPermisoIdPermiso());
            System.out.println("ID Rol: " + relacion.getRolIdRol());
        } else {
            System.out.println("\n[RESULTADO] No existe la asignación entre el Permiso " + permisoId + " y el Rol " + rolId);
        }

        scanner.close();
    }
}
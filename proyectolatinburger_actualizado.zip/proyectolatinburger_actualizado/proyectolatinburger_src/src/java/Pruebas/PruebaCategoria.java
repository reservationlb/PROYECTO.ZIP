package Pruebas;

import Controlador.CategoriaDAO;
import Modelo.Categoria;
import java.util.List;

public class PruebaCategoria {
    public static void main(String[] args) {
        CategoriaDAO categoriaDAO = new CategoriaDAO();

        System.out.println("LISTAR CATEGORÍAS");

        List<Categoria> listaCategorias = categoriaDAO.listar();

        if (listaCategorias != null && !listaCategorias.isEmpty()) {
            System.out.println("\n[ÉXITO] Categorías encontradas en la base de datos:");
            System.out.println("--------------------------------------------------");
            for (Categoria cat : listaCategorias) {
                System.out.println("ID Categoria: " + cat.getIdCategoria() + " | Nombre: " + cat.getNombre());
            }
            System.out.println("--------------------------------------------------");
            System.out.println("Total de categorías: " + listaCategorias.size());
        } else {
            System.out.println("\n[ERROR] No se encontraron categorías o la lista está vacía.");
        }
    }
}
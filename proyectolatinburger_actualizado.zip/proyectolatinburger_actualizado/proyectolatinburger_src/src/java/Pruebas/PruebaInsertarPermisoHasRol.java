package Pruebas;

import Controlador.PermisoHasRolDAO;
import Modelo.PermisoHasRol;
import java.util.Scanner;

public class PruebaInsertarPermisoHasRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisoHasRolDAO permisoHasRolDAO = new PermisoHasRolDAO();
        PermisoHasRol nuevaRelacion = new PermisoHasRol();

        System.out.println("=== PRUEBA: INSERTAR PERMISO HAS ROL ===");

        System.out.print("ID del Permiso a asignar: ");
        nuevaRelacion.setPermisoIdPermiso(Integer.parseInt(scanner.nextLine()));

        System.out.print("ID del Rol al que se asigna: ");
        nuevaRelacion.setRolIdRol(Integer.parseInt(scanner.nextLine()));

        boolean exito = permisoHasRolDAO.insertarPermisoHasRol(nuevaRelacion);

        if (exito) {
            System.out.println("\n[ÉXITO] El permiso fue asignado correctamente al rol.");
        } else {
            System.out.println("\n[ERROR] No se pudo realizar la asignación. Revisa que existan los IDs de Permiso y Rol.");
        }

        scanner.close();
    }
}
package Pruebas;

import Controlador.DisponibilidadDAO;
import java.util.Scanner;

public class PruebaActivarDisponibilidad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DisponibilidadDAO disponibilidadDAO = new DisponibilidadDAO();

        System.out.println("=== PRUEBA: ACTIVAR DISPONIBILIDAD ===");
        System.out.print("Ingrese el ID de la disponibilidad a activar: ");
        int idDisponibilidad = Integer.parseInt(scanner.nextLine());

        boolean exito = disponibilidadDAO.activarDisponibilidad(idDisponibilidad);

        if (exito) {
            System.out.println("\n[ÉXITO] La disponibilidad fue marcada como 'Activo'.");
        } else {
            System.out.println("\n[ERROR] No se pudo activar (Verifica si el ID existe).");
        }

        scanner.close();
    }
}
package Pruebas;

import Controlador.PermisoHasRolDAO;
import java.util.Scanner;

public class PruebaEliminarPermisoHasRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisoHasRolDAO permisoHasRolDAO = new PermisoHasRolDAO();

        System.out.println("=== PRUEBA: ELIMINAR PERMISO HAS ROL ===");
        System.out.print("Ingrese el ID del Permiso a desasignar: ");
        int permisoId = Integer.parseInt(scanner.nextLine());

        System.out.print("Ingrese el ID del Rol correspondiente: ");
        int rolId = Integer.parseInt(scanner.nextLine());

        System.out.print("¿Confirma la desasignación de este permiso? (s/n): ");
        String confirmacion = scanner.nextLine();

        if (confirmacion.equalsIgnoreCase("s")) {
            boolean exito = permisoHasRolDAO.eliminarPermisoHasRol(permisoId, rolId);

            if (exito) {
                System.out.println("\n[ÉXITO] Permiso desasignado del rol correctamente.");
            } else {
                System.out.println("\n[ERROR] No se pudo eliminar la asignación.");
            }
        } else {
            System.out.println("\n[CANCELADO] La operación fue cancelada.");
        }

        scanner.close();
    }
}
package Pruebas;

import Controlador.UsuarioDAO;
import java.util.Scanner;

public class PruebaInactivarUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO usuarioDAO = new UsuarioDAO();

        System.out.println("=== PRUEBA: INACTIVAR USUARIO ===");
        System.out.print("Ingrese el ID del usuario a inactivar: ");
        int idUsuario = Integer.parseInt(scanner.nextLine());

        boolean exito = usuarioDAO.inactivarUsuario(idUsuario);

        if (exito) {
            System.out.println("\n[ÉXITO] El usuario pasó a estado 'Inactivo'.");
        } else {
            System.out.println("\n[ERROR] No se pudo inactivar el usuario.");
        }

        scanner.close();
    }
}
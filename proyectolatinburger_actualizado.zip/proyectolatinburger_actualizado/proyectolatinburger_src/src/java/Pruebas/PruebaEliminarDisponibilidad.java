package Pruebas;

import Controlador.DisponibilidadDAO;
import java.util.Scanner;

public class PruebaEliminarDisponibilidad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DisponibilidadDAO disponibilidadDAO = new DisponibilidadDAO();

        System.out.println("=== PRUEBA: ELIMINAR DISPONIBILIDAD ===");
        System.out.print("Ingrese el ID de la disponibilidad a eliminar: ");
        int idDisponibilidad = Integer.parseInt(scanner.nextLine());

        System.out.print("¿Confirma la eliminación física? (s/n): ");
        String confirmacion = scanner.nextLine();

        if (confirmacion.equalsIgnoreCase("s")) {
            boolean exito = disponibilidadDAO.eliminarDisponibilidad(idDisponibilidad);

            if (exito) {
                System.out.println("\n[ÉXITO] Disponibilidad eliminada de la base de datos.");
            } else {
                System.out.println("\n[ERROR] No se pudo eliminar la disponibilidad.");
            }
        } else {
            System.out.println("\n[CANCELADO] Operación cancelada.");
        }

        scanner.close();
    }
}
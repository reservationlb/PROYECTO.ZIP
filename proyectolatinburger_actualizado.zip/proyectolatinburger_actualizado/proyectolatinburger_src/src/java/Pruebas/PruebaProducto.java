package Pruebas;

import Controlador.ProductoDAO;
import Modelo.Producto;
import java.util.List;
import java.util.Scanner;

public class PruebaProducto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductoDAO productoDAO = new ProductoDAO();

        System.out.println("PRODUCTOS");
        System.out.println("1. Listar todos los productos");
        System.out.println("2. Consultar productos por ID de categoría");
        System.out.print("Seleccione una opción: ");

        int opcion = Integer.parseInt(scanner.nextLine());

        switch (opcion) {
            case 1:
                System.out.println("\nLISTANDO TODOS LOS PRODUCTOS");
                List<Producto> todosLosProductos = productoDAO.listar();
                if (todosLosProductos != null && !todosLosProductos.isEmpty()) {
                    System.out.println("[ÉXITO] Productos registrados:");
                    for (Producto p : todosLosProductos) {
                        System.out.println("ID: " + p.getIdProducto() + 
                                           " | Nombre: " + p.getNombre() + 
                                           " | Precio: $" + p.getPrecio() + 
                                           " | ID Categoría: " + p.getIdCategoria());
                    }
                    System.out.println("Total de productos: " + todosLosProductos.size());
                } else {
                    System.out.println("[ERROR] No se encontraron productos registrados.");
                }
                break;

            case 2:
                System.out.print("\nIngrese el ID de la Categoría a consultar: ");
                int idCat = Integer.parseInt(scanner.nextLine());

                List<Producto> productosCategoria = productoDAO.listarPorCategoria(idCat);
                if (productosCategoria != null && !productosCategoria.isEmpty()) {
                    System.out.println("\n[ÉXITO] Productos encontrados para la categoría " + idCat + ":");
                    for (Producto p : productosCategoria) {
                        System.out.println("ID: " + p.getIdProducto() + 
                                           " | Nombre: " + p.getNombre() + 
                                           " | Precio: $" + p.getPrecio() + 
                                           " | Descripción: " + p.getDescripcion());
                    }
                } else {
                    System.out.println("[ERROR] No hay productos registrados para esa categoría o el ID introducido no existe.");
                }
                break;

            default:
                System.out.println("Opción no válida.");
                break;
        }

        scanner.close();
    }
}
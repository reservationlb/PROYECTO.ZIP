package Pruebas;

import Controlador.ReservaDAO;
import Modelo.Reserva;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.util.Scanner;

public class PruebaInsertarReserva {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ReservaDAO reservaDAO = new ReservaDAO();
        Reserva nuevaReserva = new Reserva();

        System.out.println("=== PRUEBA: INSERTAR RESERVA ===");

        System.out.print("Fecha (AAAA-MM-DD): ");
        nuevaReserva.setFecha(Date.valueOf(scanner.nextLine()));

        System.out.print("Hora (HH:MM:SS): ");
        nuevaReserva.setHora(Time.valueOf(scanner.nextLine()));

        System.out.print("Número de Personas: ");
        nuevaReserva.setNumeroPersona(Integer.parseInt(scanner.nextLine()));

        System.out.print("Valor de la Reserva: ");
        nuevaReserva.setValorReserva(new BigDecimal(scanner.nextLine()));

        System.out.print("ID Disponibilidad: ");
        nuevaReserva.setDisponibilidadIdDisponibilidad(Integer.parseInt(scanner.nextLine()));

        System.out.print("ID Tipo Menú: ");
        nuevaReserva.setTipoMenuIdTipoMenu(Integer.parseInt(scanner.nextLine()));

        System.out.print("ID Tipo Decoración: ");
        nuevaReserva.setTipoDecoracionIdTipoDecoracion(Integer.parseInt(scanner.nextLine()));

        System.out.print("ID Tipo Evento: ");
        nuevaReserva.setTipoEventoIdTipoEvento(Integer.parseInt(scanner.nextLine()));

        System.out.print("ID Usuario: ");
        nuevaReserva.setUsuarioIdUsuario(Integer.parseInt(scanner.nextLine()));

        boolean exito = reservaDAO.insertarReserva(nuevaReserva);

        if (exito) {
            System.out.println("\n[ÉXITO] La reserva fue registrada correctamente.");
        } else {
            System.out.println("\n[ERROR] No se pudo registrar la reserva. Revisa las llaves foráneas.");
        }

        scanner.close();
    }
}
package Pruebas;

import Controlador.DisponibilidadDAO;
import java.util.Scanner;

public class PruebaInactivarDisponibilidad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DisponibilidadDAO disponibilidadDAO = new DisponibilidadDAO();

        System.out.println("=== PRUEBA: INACTIVAR DISPONIBILIDAD ===");
        System.out.print("Ingrese el ID de la disponibilidad a inactivar: ");
        int idDisponibilidad = Integer.parseInt(scanner.nextLine());

        boolean exito = disponibilidadDAO.inactivarDisponibilidad(idDisponibilidad);

        if (exito) {
            System.out.println("\n[ÉXITO] La disponibilidad fue marcada como 'Inactivo'.");
        } else {
            System.out.println("\n[ERROR] No se pudo inactivar (Verifica si el ID existe).");
        }

        scanner.close();
    }
}
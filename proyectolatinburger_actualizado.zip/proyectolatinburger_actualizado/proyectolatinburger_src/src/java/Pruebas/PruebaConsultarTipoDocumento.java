package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebaConsultarTipoDocumento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDocumentoDAO tipoDocDAO = new TipoDocumentoDAO();

        System.out.println("=== PRUEBA: CONSULTAR TIPO DOCUMENTO ===");
        System.out.print("Ingrese el ID del tipo de documento a buscar: ");
        int idTipoDoc = Integer.parseInt(scanner.nextLine());

        TipoDocumento tipoDoc = tipoDocDAO.consultarTipoDocumento(idTipoDoc);

        if (tipoDoc != null) {
            System.out.println("\n[RESULTADO] Tipo de documento encontrado:");
            System.out.println("ID: " + tipoDoc.getIdTipoDocumento());
            System.out.println("Descripción: " + tipoDoc.getDescripcion());
        } else {
            System.out.println("\n[RESULTADO] No se encontró ningún tipo de documento con el ID: " + idTipoDoc);
        }

        scanner.close();
    }
}
package Pruebas;

import Controlador.TipoDecoracionDAO;
import Modelo.TipoDecoracion;
import java.util.Scanner;

public class PruebaConsultarTipoDecoracion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDecoracionDAO tipoDecoDAO = new TipoDecoracionDAO();

        System.out.println("=== PRUEBA: CONSULTAR TIPO DECORACION ===");
        System.out.print("Ingrese el ID del tipo de decoración a buscar: ");
        int idTipoDecoracion = Integer.parseInt(scanner.nextLine());

        TipoDecoracion deco = tipoDecoDAO.consultarTipoDecoracion(idTipoDecoracion);

        if (deco != null) {
            System.out.println("\n[RESULTADO] Tipo de decoración encontrado:");
            System.out.println("ID: " + deco.getIdTipoDecoracion());
            System.out.println("Nombre: " + deco.getNombreDecoracion());
            System.out.println("Descripción: " + deco.getDescripcion());
            System.out.println("Valor: $" + deco.getValorDecoracion());
        } else {
            System.out.println("\n[RESULTADO] No se encontró ningún tipo de decoración con el ID: " + idTipoDecoracion);
        }

        scanner.close();
    }
}
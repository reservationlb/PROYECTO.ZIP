package Pruebas;

import Controlador.TipoDecoracionDAO;
import Modelo.TipoDecoracion;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaActualizarTipoDecoracion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDecoracionDAO tipoDecoDAO = new TipoDecoracionDAO();
        TipoDecoracion decoUpdate = new TipoDecoracion();

        System.out.println("=== PRUEBA: ACTUALIZAR TIPO DECORACION ===");

        System.out.print("Ingrese el ID del tipo de decoración a modificar: ");
        decoUpdate.setIdTipoDecoracion(Integer.parseInt(scanner.nextLine()));

        System.out.print("Nuevo Nombre: ");
        decoUpdate.setNombreDecoracion(scanner.nextLine());

        System.out.print("Nueva Descripción: ");
        decoUpdate.setDescripcion(scanner.nextLine());

        System.out.print("Nuevo Valor/Precio: ");
        decoUpdate.setValorDecoracion(new BigDecimal(scanner.nextLine()));

        boolean exito = tipoDecoDAO.actualizarTipoDecoracion(decoUpdate);

        if (exito) {
            System.out.println("\n[ÉXITO] Datos del tipo de decoración actualizados en la base de datos.");
        } else {
            System.out.println("\n[ERROR] No se pudo actualizar (Verifica si el ID introducido existe).");
        }

        scanner.close();
    }
}
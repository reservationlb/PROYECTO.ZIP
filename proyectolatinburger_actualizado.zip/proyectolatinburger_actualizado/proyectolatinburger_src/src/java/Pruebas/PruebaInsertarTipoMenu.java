package Pruebas;

import Controlador.TipoMenuDAO;
import Modelo.TipoMenu;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaInsertarTipoMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoMenuDAO tipoMenuDAO = new TipoMenuDAO();
        TipoMenu nuevoMenu = new TipoMenu();

        System.out.println("=== PRUEBA: INSERTAR TIPO MENU ===");

        System.out.print("Nombre del Menú: ");
        nuevoMenu.setNombreMenu(scanner.nextLine());

        System.out.print("Descripción del Menú: ");
        nuevoMenu.setDescripcionMenu(scanner.nextLine());

        System.out.print("Valor/Precio del Menú: ");
        nuevoMenu.setValorMenu(new BigDecimal(scanner.nextLine()));

        boolean exito = tipoMenuDAO.insertarTipoMenu(nuevoMenu);

        if (exito) {
            System.out.println("\n[ÉXITO] El tipo de menú fue registrado correctamente.");
        } else {
            System.out.println("\n[ERROR] No se pudo guardar el tipo de menú en la base de datos.");
        }

        scanner.close();
    }
}
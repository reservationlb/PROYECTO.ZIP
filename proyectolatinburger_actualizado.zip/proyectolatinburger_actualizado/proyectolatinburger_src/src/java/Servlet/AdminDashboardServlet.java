package Servlet;

import Controlador.ReservaDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet(name = "AdminDashboardServlet", urlPatterns = {"/AdminDashboardServlet"})
public class AdminDashboardServlet extends HttpServlet {

    private final ReservaDAO reservaDAO = new ReservaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        int pedidosHoy = reservaDAO.contarReservasHoy();
        double ventasHoy = reservaDAO.sumarValorHoy();
        int pendientes = reservaDAO.contarReservasPendientes();

        List<Map<String, String>> todas = reservaDAO.listarTodasConDetalle();
        List<Map<String, String>> ultimos = todas.size() > 6 ? todas.subList(0, 6) : todas;

        request.setAttribute("pedidosHoy", pedidosHoy);
        request.setAttribute("ventasHoy", ventasHoy);
        request.setAttribute("pendientes", pendientes);
        request.setAttribute("ultimosPedidos", ultimos);
        request.setAttribute("seccionActiva", "dashboard");

        request.getRequestDispatcher("/View/Administrador/Dashboard.jsp").forward(request, response);
    }

    static boolean esAdmin(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session != null && session.getAttribute("usuarioLogueado") != null
                && Integer.valueOf(1).equals(session.getAttribute("rolId"));
    }
}

package Servlet;

import Controlador.CategoriaDAO;
import Controlador.ColorDAO;
import Controlador.DisponibilidadDAO;
import Controlador.ProductoDAO;
import Controlador.ReservaDAO;
import Controlador.TipoDecoracionDAO;
import Controlador.TipoDocumentoDAO;
import Controlador.TipoEventoDAO;
import Controlador.TipoMenuDAO;
import Controlador.UsuarioDAO;
import Modelo.Categoria;
import Modelo.Color;
import Modelo.Disponibilidad;
import Modelo.Producto;
import Modelo.Reserva;
import Modelo.ReservaProducto;
import Modelo.TipoDecoracion;
import Modelo.TipoDocumento;
import Modelo.TipoEvento;
import Modelo.TipoMenu;
import Modelo.Usuario;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Formulario de un único paso para que el administrador registre una
 * reserva a nombre de un cliente (boceto "+ nuevo pedido"). Reutiliza el
 * mismo camino transaccional que el asistente del cliente
 * (ReservaDAO.insertarReservaCompleta), así que la disponibilidad se valida
 * exactamente igual.
 */
@WebServlet(name = "AdminReservaFormServlet", urlPatterns = {"/AdminReservaFormServlet"})
public class AdminReservaFormServlet extends HttpServlet {

    private final DisponibilidadDAO disponibilidadDAO = new DisponibilidadDAO();
    private final TipoEventoDAO tipoEventoDAO = new TipoEventoDAO();
    private final TipoDecoracionDAO tipoDecoracionDAO = new TipoDecoracionDAO();
    private final TipoDocumentoDAO tipoDocumentoDAO = new TipoDocumentoDAO();
    private final TipoMenuDAO tipoMenuDAO = new TipoMenuDAO();
    private final CategoriaDAO categoriaDAO = new CategoriaDAO();
    private final ColorDAO colorDAO = new ColorDAO();
    private final ProductoDAO productoDAO = new ProductoDAO();
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private final ReservaDAO reservaDAO = new ReservaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        cargarCatalogos(request);
        request.setAttribute("seccionActiva", "reservas");
        request.getRequestDispatcher("/View/Administrador/ReservaForm.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        try {
            // 1) Cliente: reutiliza uno existente por documento, o crea uno nuevo
            String numeroDocumento = request.getParameter("numeroDocumento");
            Usuario cliente = usuarioDAO.consultarUsuario(numeroDocumento);

            if (cliente == null) {
                cliente = new Usuario();
                cliente.setNombre(request.getParameter("nombre"));
                cliente.setApellido(request.getParameter("apellido"));
                cliente.setTipoDocumentoIdTipoDocumento(Integer.parseInt(request.getParameter("tipoDocumentoId")));
                cliente.setNumeroDocumento(numeroDocumento);
                cliente.setDireccion(request.getParameter("direccion"));
                cliente.setTelefono(request.getParameter("telefono"));
                // El boceto de "nuevo pedido" del admin no pide fecha de nacimiento ni
                // contraseña; se usan valores por defecto razonables (el cliente puede
                // luego registrarse/actualizar sus datos por su cuenta).
                cliente.setFechaNacimiento(Date.valueOf("2000-01-01"));
                cliente.setContrasena(numeroDocumento);
                cliente.setRolIdRol(2); // Cliente
                cliente.setEstado("Activo");
                usuarioDAO.insertarUsuario(cliente);
                cliente = usuarioDAO.consultarUsuario(numeroDocumento);
            }

            // 2) Disponibilidad, evento, decoración
            int idDisponibilidad = Integer.parseInt(request.getParameter("idDisponibilidad"));
            int idTipoEvento = Integer.parseInt(request.getParameter("idTipoEvento"));
            int idTipoDecoracion = Integer.parseInt(request.getParameter("idTipoDecoracion"));
            int numeroPersonas = Integer.parseInt(request.getParameter("numeroPersonas"));
            String color = request.getParameter("color");
            String comentarios = request.getParameter("comentarios");

            // La fecha/hora reales de la reserva se resuelven más abajo según el
            // id_disponibilidad elegido en el formulario; la validación de que ese
            // slot siga libre ocurre con bloqueo de fila dentro de insertarReservaCompleta.

            TipoEvento evento = tipoEventoDAO.consultarTipoEvento(idTipoEvento);
            TipoDecoracion decoracion = tipoDecoracionDAO.consultarTipoDecoracion(idTipoDecoracion);
            TipoMenu tipoMenuPersonalizado = tipoMenuDAO.buscarPersonalizado();

            // 3) Platos seleccionados (mismo formato "id:cantidad,id:cantidad" del cliente)
            String carritoData = request.getParameter("carritoData");
            List<ReservaProducto> items = new ArrayList<>();
            BigDecimal totalPlatos = BigDecimal.ZERO;

            if (carritoData != null && !carritoData.trim().isEmpty()) {
                for (String par : carritoData.split(",")) {
                    String[] partes = par.split(":");
                    if (partes.length != 2) {
                        continue;
                    }
                    int idProducto = Integer.parseInt(partes[0].trim());
                    int cantidad = Integer.parseInt(partes[1].trim());
                    if (cantidad <= 0) {
                        continue;
                    }
                    Producto p = productoDAO.consultar(idProducto);
                    if (p == null) {
                        continue;
                    }
                    ReservaProducto rp = new ReservaProducto();
                    rp.setProductoIdProducto(idProducto);
                    rp.setCantidad(cantidad);
                    rp.setPrecioUnitario(BigDecimal.valueOf(p.getPrecio()));
                    items.add(rp);
                    totalPlatos = totalPlatos.add(BigDecimal.valueOf(p.getPrecio() * cantidad));
                }
            }

            BigDecimal valorEvento = evento != null ? evento.getValorEvento() : BigDecimal.ZERO;
            BigDecimal valorDecoracion = decoracion != null ? decoracion.getValorDecoracion() : BigDecimal.ZERO;
            BigDecimal totalGeneral = valorEvento.add(valorDecoracion).add(totalPlatos);

            Reserva reserva = new Reserva();
            reserva.setFecha(obtenerFechaDeId(idDisponibilidad));
            reserva.setHora(obtenerHoraDeId(idDisponibilidad));
            reserva.setNumeroPersona(numeroPersonas);
            reserva.setValorReserva(totalGeneral);
            reserva.setDisponibilidadIdDisponibilidad(idDisponibilidad);
            reserva.setTipoMenuIdTipoMenu(tipoMenuPersonalizado != null ? tipoMenuPersonalizado.getIdTipoMenu() : 10);
            reserva.setTipoDecoracionIdTipoDecoracion(idTipoDecoracion);
            reserva.setTipoEventoIdTipoEvento(idTipoEvento);
            reserva.setUsuarioIdUsuario(cliente.getIdUsuario());
            reserva.setColorEvento(color);
            reserva.setComentarios(comentarios);

            int idGenerado = reservaDAO.insertarReservaCompleta(reserva, items, null);

            if (idGenerado == -1) {
                request.setAttribute("error", "Ese horario ya fue tomado. Elige otra disponibilidad.");
                cargarCatalogos(request);
                request.setAttribute("seccionActiva", "reservas");
                request.getRequestDispatcher("/View/Administrador/ReservaForm.jsp").forward(request, response);
                return;
            } else if (idGenerado < 0) {
                request.setAttribute("error", "Ocurrió un error al registrar el pedido. Intenta nuevamente.");
                cargarCatalogos(request);
                request.setAttribute("seccionActiva", "reservas");
                request.getRequestDispatcher("/View/Administrador/ReservaForm.jsp").forward(request, response);
                return;
            }

            response.sendRedirect(request.getContextPath() + "/FacturaServlet?id=" + idGenerado);

        } catch (NumberFormatException | NullPointerException e) {
            request.setAttribute("error", "Revisa que todos los campos obligatorios estén completos.");
            cargarCatalogos(request);
            request.setAttribute("seccionActiva", "reservas");
            request.getRequestDispatcher("/View/Administrador/ReservaForm.jsp").forward(request, response);
        }
    }

    private void cargarCatalogos(HttpServletRequest request) {
        List<Disponibilidad> disponibles = disponibilidadDAO.listarDisponibles(null);
        List<TipoEvento> eventos = tipoEventoDAO.listar();
        List<TipoDecoracion> decoraciones = tipoDecoracionDAO.listar();
        List<TipoDocumento> tiposDocumento = tipoDocumentoDAO.listar();
        List<Categoria> categorias = categoriaDAO.listar();
        List<Producto> productos = productoDAO.listar();
        List<Color> colores = colorDAO.listar();

        request.setAttribute("disponibles", disponibles);
        request.setAttribute("eventos", eventos);
        request.setAttribute("decoraciones", decoraciones);
        request.setAttribute("tiposDocumento", tiposDocumento);
        request.setAttribute("categorias", categorias);
        request.setAttribute("productos", productos);
        request.setAttribute("colores", colores);
    }

    // Auxiliares para recuperar fecha/hora a partir del id_disponibilidad elegido en el <select>
    private java.sql.Date obtenerFechaDeId(int idDisponibilidad) {
        for (Disponibilidad d : disponibilidadDAO.listarDisponibles(null)) {
            if (d.getIdDisponibilidad() == idDisponibilidad) {
                return d.getFecha();
            }
        }
        return null;
    }

    private java.sql.Time obtenerHoraDeId(int idDisponibilidad) {
        for (Disponibilidad d : disponibilidadDAO.listarDisponibles(null)) {
            if (d.getIdDisponibilidad() == idDisponibilidad) {
                return d.getHora();
            }
        }
        return null;
    }
}

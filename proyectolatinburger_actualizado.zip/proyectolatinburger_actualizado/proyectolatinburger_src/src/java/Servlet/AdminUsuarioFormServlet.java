package Servlet;

import Controlador.RolDAO;
import Controlador.TipoDocumentoDAO;
import Controlador.UsuarioDAO;
import Modelo.Rol;
import Modelo.TipoDocumento;
import Modelo.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

@WebServlet(name = "AdminUsuarioFormServlet", urlPatterns = {"/AdminUsuarioFormServlet"})
public class AdminUsuarioFormServlet extends HttpServlet {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private final RolDAO rolDAO = new RolDAO();
    private final TipoDocumentoDAO tipoDocumentoDAO = new TipoDocumentoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String idStr = request.getParameter("id");
        Usuario usuario = null;
        if (idStr != null) {
            try {
                usuario = usuarioDAO.consultarPorId(Integer.parseInt(idStr));
            } catch (NumberFormatException ignored) {
            }
        }

        List<Rol> roles = rolDAO.listar();
        List<TipoDocumento> tiposDocumento = tipoDocumentoDAO.listar();

        request.setAttribute("usuario", usuario);
        request.setAttribute("roles", roles);
        request.setAttribute("tiposDocumento", tiposDocumento);
        request.setAttribute("seccionActiva", "usuarios");
        request.getRequestDispatcher("/View/Administrador/UsuarioForm.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        try {
            String idStr = request.getParameter("idUsuario");
            boolean esNuevo = (idStr == null || idStr.trim().isEmpty() || "0".equals(idStr));

            if (esNuevo) {
                Usuario nuevo = new Usuario();
                nuevo.setNombre(request.getParameter("nombre"));
                nuevo.setApellido(request.getParameter("apellido"));
                nuevo.setTipoDocumentoIdTipoDocumento(Integer.parseInt(request.getParameter("tipoDocumentoId")));
                nuevo.setNumeroDocumento(request.getParameter("numeroDocumento"));
                nuevo.setDireccion(request.getParameter("direccion"));
                nuevo.setTelefono(request.getParameter("telefono"));
                String fechaNac = request.getParameter("fechaNacimiento");
                nuevo.setFechaNacimiento(fechaNac != null && !fechaNac.trim().isEmpty()
                        ? Date.valueOf(fechaNac) : Date.valueOf("2000-01-01"));
                nuevo.setContrasena(request.getParameter("contrasena"));
                nuevo.setRolIdRol(Integer.parseInt(request.getParameter("rolId")));
                nuevo.setEstado("Activo");
                usuarioDAO.insertarUsuario(nuevo);
            } else {
                Usuario existente = new Usuario();
                existente.setIdUsuario(Integer.parseInt(idStr));
                existente.setNombre(request.getParameter("nombre"));
                existente.setApellido(request.getParameter("apellido"));
                existente.setDireccion(request.getParameter("direccion"));
                existente.setTelefono(request.getParameter("telefono"));
                usuarioDAO.actualizarUsuario(existente);
            }

            response.sendRedirect(request.getContextPath() + "/AdminUsuariosServlet");

        } catch (IllegalArgumentException e) {
            request.setAttribute("error", "Revisa que todos los campos obligatorios estén completos y correctos.");
            request.setAttribute("roles", rolDAO.listar());
            request.setAttribute("tiposDocumento", tipoDocumentoDAO.listar());
            request.setAttribute("seccionActiva", "usuarios");
            request.getRequestDispatcher("/View/Administrador/UsuarioForm.jsp").forward(request, response);
        }
    }
}

package Servlet;

import Controlador.ReservaDAO;
import Controlador.ReservaProductoDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@WebServlet(name = "AdminReportesServlet", urlPatterns = {"/AdminReportesServlet"})
public class AdminReportesServlet extends HttpServlet {

    private final ReservaDAO reservaDAO = new ReservaDAO();
    private final ReservaProductoDAO reservaProductoDAO = new ReservaProductoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        LocalDate hoy = LocalDate.now();

        int pedidosEsteMes = reservaDAO.contarReservasMes(hoy.getYear(), hoy.getMonthValue());
        double ventasEsteMes = reservaDAO.sumarValorMes(hoy.getYear(), hoy.getMonthValue());

        // Últimos 4 meses (incluyendo el actual), de más antiguo a más reciente
        List<Map<String, String>> ventasPorMes = new ArrayList<>();
        for (int i = 3; i >= 0; i--) {
            LocalDate mes = hoy.minusMonths(i);
            double valor = reservaDAO.sumarValorMes(mes.getYear(), mes.getMonthValue());
            Map<String, String> fila = new HashMap<>();
            fila.put("mes", mes.getMonth().getDisplayName(TextStyle.FULL, new Locale("es", "ES")));
            fila.put("valor", String.format("%,.0f", valor));
            ventasPorMes.add(fila);
        }

        List<Map<String, String>> popularidad = reservaProductoDAO.popularidadPlatos(6);

        request.setAttribute("pedidosEsteMes", pedidosEsteMes);
        request.setAttribute("ventasEsteMes", ventasEsteMes);
        request.setAttribute("ventasPorMes", ventasPorMes);
        request.setAttribute("popularidad", popularidad);
        request.setAttribute("seccionActiva", "reportes");

        request.getRequestDispatcher("/View/Administrador/Reportes.jsp").forward(request, response);
    }
}

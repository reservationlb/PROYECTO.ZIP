package Servlet;

import Controlador.CategoriaDAO;
import Controlador.ProductoDAO;
import Modelo.Categoria;
import Modelo.Producto;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "AdminMenuServlet", urlPatterns = {"/AdminMenuServlet"})
public class AdminMenuServlet extends HttpServlet {

    private final ProductoDAO productoDAO = new ProductoDAO();
    private final CategoriaDAO categoriaDAO = new CategoriaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        List<Producto> productos = productoDAO.listarTodos();
        List<Categoria> categorias = categoriaDAO.listar();

        request.setAttribute("productos", productos);
        request.setAttribute("categorias", categorias);
        request.setAttribute("seccionActiva", "menu");
        request.getRequestDispatcher("/View/Administrador/Menu.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String accion = request.getParameter("accion");
        try {
            int idProducto = Integer.parseInt(request.getParameter("idProducto"));
            if ("ocultar".equals(accion)) {
                productoDAO.cambiarActivo(idProducto, false);
            } else if ("mostrar".equals(accion)) {
                productoDAO.cambiarActivo(idProducto, true);
            }
        } catch (NumberFormatException ignored) {
        }

        response.sendRedirect(request.getContextPath() + "/AdminMenuServlet");
    }
}

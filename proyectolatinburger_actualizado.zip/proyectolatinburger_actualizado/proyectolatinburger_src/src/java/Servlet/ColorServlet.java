package Servlet;

import Controlador.ColorDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Paso 4 del asistente de reserva: color del evento, cargado dinámicamente
 * desde el catálogo color_evento (administrable desde el panel de admin),
 * y comentarios/información adicional.
 */
@WebServlet(name = "ColorServlet", urlPatterns = {"/ColorServlet"})
public class ColorServlet extends HttpServlet {

    private final ColorDAO colorDAO = new ColorDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }
        if (session.getAttribute("reservaIdTipoDecoracion") == null) {
            response.sendRedirect(request.getContextPath() + "/DecoracionServlet");
            return;
        }

        request.setAttribute("listaColores", colorDAO.listar());
        request.getRequestDispatcher("/View/Cliente/Color.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String color = request.getParameter("color");
        String comentarios = request.getParameter("comentarios");

        if (color == null || color.trim().isEmpty()) {
            request.setAttribute("error", "Selecciona un color para el evento.");
            request.setAttribute("listaColores", colorDAO.listar());
            request.getRequestDispatcher("/View/Cliente/Color.jsp").forward(request, response);
            return;
        }

        session.setAttribute("reservaColor", color);
        session.setAttribute("reservaComentarios", comentarios != null ? comentarios : "");

        response.sendRedirect(request.getContextPath() + "/MenuServlet");
    }
}

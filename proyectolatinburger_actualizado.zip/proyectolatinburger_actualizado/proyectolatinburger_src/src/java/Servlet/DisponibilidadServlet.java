package Servlet;

import Controlador.DisponibilidadDAO;
import Modelo.Disponibilidad;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet(name = "DisponibilidadServlet", urlPatterns = {"/DisponibilidadServlet"})
public class DisponibilidadServlet extends HttpServlet {

    private final DisponibilidadDAO disponibilidadDAO = new DisponibilidadDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!haySesionCliente(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        List<Disponibilidad> lista = disponibilidadDAO.listarDisponibles(null);
        request.setAttribute("proximasFechas", convertirAMapa(lista));
        request.getRequestDispatcher("/View/Cliente/Disponibilidad.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (!haySesionCliente(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String accion = request.getParameter("accion");
        String fechaStr = request.getParameter("fecha");
        String horaStr = request.getParameter("hora");
        HttpSession session = request.getSession();

        if ("consultar".equals(accion)) {
            Date fechaFiltro = null;
            if (fechaStr != null && !fechaStr.trim().isEmpty()) {
                try {
                    fechaFiltro = Date.valueOf(fechaStr);
                } catch (IllegalArgumentException e) {
                    request.setAttribute("mensajeErrorBD", "Fecha inválida.");
                }
            }
            List<Disponibilidad> lista = disponibilidadDAO.listarDisponibles(fechaFiltro);
            request.setAttribute("proximasFechas", convertirAMapa(lista));
            request.getRequestDispatcher("/View/Cliente/Disponibilidad.jsp").forward(request, response);
            return;
        }

        // Acción "Siguiente": valida que ese horario exista y siga Disponible
        try {
            Date fecha = Date.valueOf(fechaStr);
            String horaCompleta = horaStr.length() == 5 ? horaStr + ":00" : horaStr; // HH:mm -> HH:mm:ss
            Time hora = Time.valueOf(horaCompleta);

            Disponibilidad disp = disponibilidadDAO.consultarPorFechaYHora(fecha, hora);
            if (disp == null) {
                request.setAttribute("mensajeErrorBD",
                        "Ese horario ya no está disponible. Por favor selecciona otro de la lista.");
                List<Disponibilidad> lista = disponibilidadDAO.listarDisponibles(null);
                request.setAttribute("proximasFechas", convertirAMapa(lista));
                request.getRequestDispatcher("/View/Cliente/Disponibilidad.jsp").forward(request, response);
                return;
            }

            session.setAttribute("reservaFecha", fechaStr);
            session.setAttribute("reservaHora", horaStr);
            session.setAttribute("reservaIdDisponibilidad", disp.getIdDisponibilidad());

            response.sendRedirect(request.getContextPath() + "/EventoServlet");

        } catch (IllegalArgumentException e) {
            request.setAttribute("mensajeErrorBD", "Fecha u hora inválida.");
            List<Disponibilidad> lista = disponibilidadDAO.listarDisponibles(null);
            request.setAttribute("proximasFechas", convertirAMapa(lista));
            request.getRequestDispatcher("/View/Cliente/Disponibilidad.jsp").forward(request, response);
        }
    }

    private boolean haySesionCliente(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session != null && session.getAttribute("usuarioLogueado") != null;
    }

    // Disponibilidad.jsp espera List<Map<String,String>> con claves fecha/hora/estado
    // (contrato ya existente de la vista original), por eso se convierte aquí.
    private List<Map<String, String>> convertirAMapa(List<Disponibilidad> lista) {
        List<Map<String, String>> resultado = new ArrayList<>();
        for (Disponibilidad d : lista) {
            Map<String, String> item = new HashMap<>();
            item.put("fecha", String.valueOf(d.getFecha()));
            item.put("hora", String.valueOf(d.getHora()));
            item.put("estado", d.getEstado());
            resultado.add(item);
        }
        return resultado;
    }
}

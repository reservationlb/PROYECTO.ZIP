package Servlet;

import Controlador.TipoDecoracionDAO;
import Modelo.TipoDecoracion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

/**
 * Paso 3 del asistente de reserva: selección de decoración
 * (cargada desde tipo_decoracion).
 */
@WebServlet(name = "DecoracionServlet", urlPatterns = {"/DecoracionServlet"})
public class DecoracionServlet extends HttpServlet {

    private final TipoDecoracionDAO tipoDecoracionDAO = new TipoDecoracionDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }
        if (session.getAttribute("reservaIdTipoEvento") == null) {
            response.sendRedirect(request.getContextPath() + "/EventoServlet");
            return;
        }

        List<TipoDecoracion> listaDecoraciones = tipoDecoracionDAO.listar();
        request.setAttribute("listaDecoraciones", listaDecoraciones);
        request.getRequestDispatcher("/View/Cliente/Decoracion.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String idTipoDecoracionStr = request.getParameter("idTipoDecoracion");
        try {
            int idTipoDecoracion = Integer.parseInt(idTipoDecoracionStr);
            session.setAttribute("reservaIdTipoDecoracion", idTipoDecoracion);
            response.sendRedirect(request.getContextPath() + "/ColorServlet");
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Selecciona una decoración para continuar.");
            request.setAttribute("listaDecoraciones", tipoDecoracionDAO.listar());
            request.getRequestDispatcher("/View/Cliente/Decoracion.jsp").forward(request, response);
        }
    }
}

package Servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Punto de entrada del botón "RESERVAR / PEDIR" y de los botones "+" del
 * menú en Inicio.jsp. Si el visitante ya inició sesión lo manda directo a
 * Disponibilidad; si no, lo manda a Login (que a su vez enlaza a Registro),
 * tal como lo pide el documento de requisitos.
 */
@WebServlet(name = "ReservarServlet", urlPatterns = {"/Reservar"})
public class ReservarServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("usuarioLogueado") != null) {
            response.sendRedirect(request.getContextPath() + "/DisponibilidadServlet");
        } else {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
        }
    }
}

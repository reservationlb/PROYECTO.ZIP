package Servlet;

import Controlador.ReservaDAO;
import Controlador.TipoDecoracionDAO;
import Controlador.TipoEventoDAO;
import Controlador.TipoMenuDAO;
import Modelo.Abono;
import Modelo.Reserva;
import Modelo.ReservaProducto;
import Modelo.TipoDecoracion;
import Modelo.TipoEvento;
import Modelo.TipoMenu;
import Modelo.Usuario;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.util.List;

/**
 * Paso 6 del asistente de reserva: muestra el valor total (evento +
 * decoración + platos elegidos) y, al confirmar, guarda TODO de forma
 * transaccional mediante ReservaDAO.insertarReservaCompleta (valida de
 * nuevo la disponibilidad para evitar dobles reservas concurrentes).
 */
@WebServlet(name = "ResumenServlet", urlPatterns = {"/ResumenServlet"})
public class ResumenServlet extends HttpServlet {

    private final TipoEventoDAO tipoEventoDAO = new TipoEventoDAO();
    private final TipoDecoracionDAO tipoDecoracionDAO = new TipoDecoracionDAO();
    private final TipoMenuDAO tipoMenuDAO = new TipoMenuDAO();
    private final ReservaDAO reservaDAO = new ReservaDAO();

    @Override
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }
        List<java.util.Map<String, Object>> carrito =
                (List<java.util.Map<String, Object>>) session.getAttribute("carritoProductos");
        if (carrito == null || carrito.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/MenuServlet");
            return;
        }

        int idTipoEvento = (int) session.getAttribute("reservaIdTipoEvento");
        int idTipoDecoracion = (int) session.getAttribute("reservaIdTipoDecoracion");

        TipoEvento evento = tipoEventoDAO.consultarTipoEvento(idTipoEvento);
        TipoDecoracion decoracion = tipoDecoracionDAO.consultarTipoDecoracion(idTipoDecoracion);

        BigDecimal totalPlatos = BigDecimal.ZERO;
        for (java.util.Map<String, Object> item : carrito) {
            BigDecimal precio = (BigDecimal) item.get("precioUnitario");
            int cantidad = (int) item.get("cantidad");
            totalPlatos = totalPlatos.add(precio.multiply(BigDecimal.valueOf(cantidad)));
        }

        BigDecimal valorEvento = evento != null ? evento.getValorEvento() : BigDecimal.ZERO;
        BigDecimal valorDecoracion = decoracion != null ? decoracion.getValorDecoracion() : BigDecimal.ZERO;
        BigDecimal totalGeneral = valorEvento.add(valorDecoracion).add(totalPlatos);

        request.setAttribute("carrito", carrito);
        request.setAttribute("evento", evento);
        request.setAttribute("decoracion", decoracion);
        request.setAttribute("totalPlatos", totalPlatos);
        request.setAttribute("totalGeneral", totalGeneral);
        request.setAttribute("reservaFecha", session.getAttribute("reservaFecha"));
        request.setAttribute("reservaHora", session.getAttribute("reservaHora"));
        request.setAttribute("reservaNumeroPersonas", session.getAttribute("reservaNumeroPersonas"));
        request.setAttribute("reservaColor", session.getAttribute("reservaColor"));
        request.setAttribute("reservaComentarios", session.getAttribute("reservaComentarios"));

        request.getRequestDispatcher("/View/Cliente/Resumen.jsp").forward(request, response);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        List<java.util.Map<String, Object>> carrito =
                (List<java.util.Map<String, Object>>) session.getAttribute("carritoProductos");
        Integer idDisponibilidad = (Integer) session.getAttribute("reservaIdDisponibilidad");
        Integer idTipoEvento = (Integer) session.getAttribute("reservaIdTipoEvento");
        Integer idTipoDecoracion = (Integer) session.getAttribute("reservaIdTipoDecoracion");
        String fechaStr = (String) session.getAttribute("reservaFecha");
        String horaStr = (String) session.getAttribute("reservaHora");
        Integer numeroPersonas = (Integer) session.getAttribute("reservaNumeroPersonas");
        String color = (String) session.getAttribute("reservaColor");
        String comentarios = (String) session.getAttribute("reservaComentarios");
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");

        if (carrito == null || carrito.isEmpty() || idDisponibilidad == null || idTipoEvento == null
                || idTipoDecoracion == null || fechaStr == null || horaStr == null) {
            response.sendRedirect(request.getContextPath() + "/DisponibilidadServlet");
            return;
        }

        String metodoPago = request.getParameter("metodoPago");
        String montoAbonoStr = request.getParameter("montoAbono");

        TipoEvento evento = tipoEventoDAO.consultarTipoEvento(idTipoEvento);
        TipoDecoracion decoracion = tipoDecoracionDAO.consultarTipoDecoracion(idTipoDecoracion);
        TipoMenu tipoMenuPersonalizado = tipoMenuDAO.buscarPersonalizado();

        BigDecimal totalPlatos = BigDecimal.ZERO;
        List<ReservaProducto> items = new java.util.ArrayList<>();
        for (java.util.Map<String, Object> item : carrito) {
            BigDecimal precio = (BigDecimal) item.get("precioUnitario");
            int cantidad = (int) item.get("cantidad");
            totalPlatos = totalPlatos.add(precio.multiply(BigDecimal.valueOf(cantidad)));

            ReservaProducto rp = new ReservaProducto();
            rp.setProductoIdProducto((int) item.get("idProducto"));
            rp.setCantidad(cantidad);
            rp.setPrecioUnitario(precio);
            items.add(rp);
        }

        BigDecimal valorEvento = evento != null ? evento.getValorEvento() : BigDecimal.ZERO;
        BigDecimal valorDecoracion = decoracion != null ? decoracion.getValorDecoracion() : BigDecimal.ZERO;
        BigDecimal totalGeneral = valorEvento.add(valorDecoracion).add(totalPlatos);

        Reserva reserva = new Reserva();
        reserva.setFecha(Date.valueOf(fechaStr));
        String horaCompleta = horaStr.length() == 5 ? horaStr + ":00" : horaStr;
        reserva.setHora(Time.valueOf(horaCompleta));
        reserva.setNumeroPersona(numeroPersonas != null ? numeroPersonas : 1);
        reserva.setValorReserva(totalGeneral);
        reserva.setDisponibilidadIdDisponibilidad(idDisponibilidad);
        reserva.setTipoMenuIdTipoMenu(tipoMenuPersonalizado != null ? tipoMenuPersonalizado.getIdTipoMenu() : 10);
        reserva.setTipoDecoracionIdTipoDecoracion(idTipoDecoracion);
        reserva.setTipoEventoIdTipoEvento(idTipoEvento);
        reserva.setUsuarioIdUsuario(usuario.getIdUsuario());
        reserva.setColorEvento(color);
        reserva.setComentarios(comentarios);

        Abono abono = null;
        if (metodoPago != null && !metodoPago.trim().isEmpty()) {
            BigDecimal montoAbono;
            try {
                montoAbono = (montoAbonoStr != null && !montoAbonoStr.trim().isEmpty())
                        ? new BigDecimal(montoAbonoStr) : totalGeneral;
            } catch (NumberFormatException e) {
                montoAbono = totalGeneral;
            }
            abono = new Abono();
            abono.setMedioPago(metodoPago);
            abono.setValorAbono(montoAbono);
            abono.setEstado("Registrado");
        }

        int idReservaGenerado = reservaDAO.insertarReservaCompleta(reserva, items, abono);

        if (idReservaGenerado == -1) {
            request.setAttribute("error",
                    "Justo acaban de reservar ese horario. Por favor elige otra fecha u hora disponible.");
            response.sendRedirect(request.getContextPath() + "/DisponibilidadServlet");
            return;
        } else if (idReservaGenerado < 0) {
            request.setAttribute("error", "Ocurrió un error al confirmar tu reserva. Intenta nuevamente.");
            doGet(request, response);
            return;
        }

        // Limpia el estado del asistente, ya quedó guardado en la BD
        session.removeAttribute("reservaFecha");
        session.removeAttribute("reservaHora");
        session.removeAttribute("reservaIdDisponibilidad");
        session.removeAttribute("reservaIdTipoEvento");
        session.removeAttribute("reservaNumeroPersonas");
        session.removeAttribute("reservaIdTipoDecoracion");
        session.removeAttribute("reservaColor");
        session.removeAttribute("reservaComentarios");
        session.removeAttribute("carritoProductos");
        session.setAttribute("ultimaReservaId", idReservaGenerado);

        response.sendRedirect(request.getContextPath() + "/FacturaServlet?id=" + idReservaGenerado);
    }
}

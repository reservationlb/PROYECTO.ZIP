package Servlet;

import Controlador.ReservaDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet(name = "AdminReservasServlet", urlPatterns = {"/AdminReservasServlet"})
public class AdminReservasServlet extends HttpServlet {

    private final ReservaDAO reservaDAO = new ReservaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        List<Map<String, String>> reservas = reservaDAO.listarTodasConDetalle();
        request.setAttribute("reservas", reservas);
        request.setAttribute("seccionActiva", "reservas");
        request.getRequestDispatcher("/View/Administrador/Reservas.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String accion = request.getParameter("accion");
        String idStr = request.getParameter("idReserva");

        try {
            int idReserva = Integer.parseInt(idStr);

            if ("cambiarEstado".equals(accion)) {
                String nuevoEstado = request.getParameter("nuevoEstado");
                reservaDAO.actualizarEstado(idReserva, nuevoEstado);
            } else if ("cancelar".equals(accion)) {
                reservaDAO.cancelarReserva(idReserva);
            }
        } catch (NumberFormatException ignored) {
            // Parámetro inválido: simplemente vuelve a listar sin aplicar cambios
        }

        response.sendRedirect(request.getContextPath() + "/AdminReservasServlet");
    }
}

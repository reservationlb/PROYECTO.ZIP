package Servlet;

import Controlador.ColorDAO;
import Controlador.TipoDecoracionDAO;
import Controlador.TipoEventoDAO;
import Modelo.Color;
import Modelo.TipoDecoracion;
import Modelo.TipoEvento;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;

/**
 * Un solo servlet para los tres catálogos pequeños del asistente de reserva
 * (Tipo de Evento, Decoración, Color), seleccionados con ?tipo=evento|
 * decoracion|color. Cada uno usa "ocultar/mostrar" en vez de borrar, igual
 * que el menú, para no romper reservas ya existentes.
 */
@WebServlet(name = "AdminCatalogosServlet", urlPatterns = {"/AdminCatalogosServlet"})
public class AdminCatalogosServlet extends HttpServlet {

    private final TipoEventoDAO tipoEventoDAO = new TipoEventoDAO();
    private final TipoDecoracionDAO tipoDecoracionDAO = new TipoDecoracionDAO();
    private final ColorDAO colorDAO = new ColorDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String tipo = request.getParameter("tipo");
        if (tipo == null || tipo.trim().isEmpty()) {
            tipo = "evento";
        }

        cargarDatos(request, tipo);

        String editarStr = request.getParameter("editar");
        if (editarStr != null) {
            try {
                int id = Integer.parseInt(editarStr);
                switch (tipo) {
                    case "evento":
                        request.setAttribute("eventoEditar", tipoEventoDAO.consultarTipoEvento(id));
                        break;
                    case "decoracion":
                        request.setAttribute("decoracionEditar", tipoDecoracionDAO.consultarTipoDecoracion(id));
                        break;
                    case "color":
                        request.setAttribute("colorEditar", colorDAO.consultar(id));
                        break;
                    default:
                        break;
                }
            } catch (NumberFormatException ignored) {
            }
        }

        request.setAttribute("seccionActiva", "catalogos");
        request.getRequestDispatcher("/View/Administrador/Catalogos.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String tipo = request.getParameter("tipo");
        String accion = request.getParameter("accion");

        try {
            if ("guardar".equals(accion)) {
                guardar(request, tipo);
            } else if ("cambiarActivo".equals(accion)) {
                int id = Integer.parseInt(request.getParameter("id"));
                boolean activo = "1".equals(request.getParameter("activo"));
                switch (tipo) {
                    case "evento":
                        tipoEventoDAO.cambiarActivo(id, activo);
                        break;
                    case "decoracion":
                        tipoDecoracionDAO.cambiarActivo(id, activo);
                        break;
                    case "color":
                        colorDAO.cambiarActivo(id, activo);
                        break;
                    default:
                        break;
                }
            }
            response.sendRedirect(request.getContextPath() + "/AdminCatalogosServlet?tipo=" + tipo);

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Revisa que los valores numéricos sean correctos.");
            cargarDatos(request, tipo);
            request.setAttribute("seccionActiva", "catalogos");
            request.getRequestDispatcher("/View/Administrador/Catalogos.jsp").forward(request, response);
        }
    }

    private void guardar(HttpServletRequest request, String tipo) {
        String idStr = request.getParameter("id");
        boolean esNuevo = (idStr == null || idStr.trim().isEmpty() || "0".equals(idStr));
        String nombre = request.getParameter("nombre");
        String imagen = request.getParameter("imagen");

        switch (tipo) {
            case "evento": {
                TipoEvento te = new TipoEvento();
                te.setNombreEvento(nombre);
                te.setDescripcion(request.getParameter("descripcion"));
                te.setValorEvento(new BigDecimal(request.getParameter("valor")));
                te.setImagen(imagen);
                if (esNuevo) {
                    tipoEventoDAO.insertarTipoEvento(te);
                } else {
                    te.setIdTipoEvento(Integer.parseInt(idStr));
                    tipoEventoDAO.actualizarTipoEvento(te);
                }
                break;
            }
            case "decoracion": {
                TipoDecoracion td = new TipoDecoracion();
                td.setNombreDecoracion(nombre);
                td.setDescripcion(request.getParameter("descripcion"));
                td.setValorDecoracion(new BigDecimal(request.getParameter("valor")));
                td.setImagen(imagen);
                if (esNuevo) {
                    tipoDecoracionDAO.insertarTipoDecoracion(td);
                } else {
                    td.setIdTipoDecoracion(Integer.parseInt(idStr));
                    tipoDecoracionDAO.actualizarTipoDecoracion(td);
                }
                break;
            }
            case "color": {
                Color c = new Color();
                c.setNombre(nombre);
                c.setCodigoHex(request.getParameter("codigoHex"));
                c.setImagen(imagen);
                if (esNuevo) {
                    colorDAO.insertar(c);
                } else {
                    c.setIdColor(Integer.parseInt(idStr));
                    colorDAO.actualizar(c);
                }
                break;
            }
            default:
                break;
        }
    }

    private void cargarDatos(HttpServletRequest request, String tipo) {
        request.setAttribute("tipoActivo", tipo);
        switch (tipo) {
            case "decoracion":
                request.setAttribute("decoraciones", tipoDecoracionDAO.listarTodos());
                break;
            case "color":
                request.setAttribute("colores", colorDAO.listarTodos());
                break;
            case "evento":
            default:
                request.setAttribute("eventos", tipoEventoDAO.listarTodos());
                break;
        }
    }
}

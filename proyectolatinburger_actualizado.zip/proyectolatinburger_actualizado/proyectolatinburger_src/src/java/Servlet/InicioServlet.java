package Servlet;

import Controlador.ProductoDAO;
import Controlador.CategoriaDAO;
import Modelo.Producto;
import Modelo.Categoria;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "InicioServlet", urlPatterns = {"/InicioServlet", "/Inicio", ""})
public class InicioServlet extends HttpServlet {

    private final ProductoDAO productoDAO = new ProductoDAO();
    private final CategoriaDAO categoriaDAO = new CategoriaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            // 1. Obtener la lista de productos desde la base de datos
            List<Producto> listaProductos = productoDAO.listar();
            request.setAttribute("listaProductos", listaProductos);

            // 2. Obtener la lista de categorías
            List<Categoria> listaCategorias = categoriaDAO.listar();
            request.setAttribute("listaCategorias", listaCategorias);

        } catch (Exception e) {
            System.err.println("Error al cargar los datos en InicioServlet: " + e.getMessage());
            e.printStackTrace();
        }

        // 3. Apunta a la ubicación exacta de la vista dentro de Web Content / webapp
        // (corregido: el archivo real es "Inicio.jsp" con mayúscula inicial; en
        // Windows funcionaba por el filesystem insensible a mayúsculas, pero
        // fallaría con 404 en un despliegue Linux/GlassFish case-sensitive).
        request.getRequestDispatcher("/View/Cliente/Inicio.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
package Servlet;

import Controlador.TipoEventoDAO;
import Modelo.TipoEvento;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

/**
 * Paso 2 del asistente de reserva: selección de tipo de evento
 * (Cumpleaños, Graduación, Bautismo, etc. cargados desde tipo_evento)
 * y cantidad de personas.
 */
@WebServlet(name = "EventoServlet", urlPatterns = {"/EventoServlet"})
public class EventoServlet extends HttpServlet {

    private final TipoEventoDAO tipoEventoDAO = new TipoEventoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }
        if (session.getAttribute("reservaIdDisponibilidad") == null) {
            // No ha pasado por el paso de Disponibilidad todavía
            response.sendRedirect(request.getContextPath() + "/DisponibilidadServlet");
            return;
        }

        List<TipoEvento> listaEventos = tipoEventoDAO.listar();
        request.setAttribute("listaEventos", listaEventos);
        request.getRequestDispatcher("/View/Cliente/Evento.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String idTipoEventoStr = request.getParameter("idTipoEvento");
        String numeroPersonasStr = request.getParameter("numeroPersonas");

        try {
            int idTipoEvento = Integer.parseInt(idTipoEventoStr);
            int numeroPersonas = Integer.parseInt(numeroPersonasStr);

            if (numeroPersonas <= 0) {
                throw new IllegalArgumentException("El número de personas debe ser mayor a cero.");
            }

            session.setAttribute("reservaIdTipoEvento", idTipoEvento);
            session.setAttribute("reservaNumeroPersonas", numeroPersonas);

            response.sendRedirect(request.getContextPath() + "/DecoracionServlet");

        } catch (IllegalArgumentException e) {
            request.setAttribute("error", "Selecciona un tipo de evento e indica un número de personas válido.");
            request.setAttribute("listaEventos", tipoEventoDAO.listar());
            request.getRequestDispatcher("/View/Cliente/Evento.jsp").forward(request, response);
        }
    }
}

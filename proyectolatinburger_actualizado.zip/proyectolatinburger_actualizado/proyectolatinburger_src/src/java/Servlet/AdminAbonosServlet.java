package Servlet;

import Controlador.AbonoDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet(name = "AdminAbonosServlet", urlPatterns = {"/AdminAbonosServlet"})
public class AdminAbonosServlet extends HttpServlet {

    private final AbonoDAO abonoDAO = new AbonoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        List<Map<String, String>> abonos = abonoDAO.listarTodos();
        request.setAttribute("abonos", abonos);
        request.setAttribute("seccionActiva", "abonos");
        request.getRequestDispatcher("/View/Administrador/Abonos.jsp").forward(request, response);
    }
}

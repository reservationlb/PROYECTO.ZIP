package Servlet;

import Controlador.DisponibilidadDAO;
import Modelo.Disponibilidad;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.util.List;

/**
 * Panel de administrador para agregar nuevos horarios disponibles y
 * eliminar los que se hayan agregado por error. Usa el mismo vocabulario
 * de estados ('Disponible' / 'Ocupado') que el resto del sistema, para no
 * generar horarios "fantasma" que el cliente no pueda ver ni reservar.
 */
@WebServlet(name = "AdminDisponibilidadServlet", urlPatterns = {"/AdminDisponibilidadServlet"})
public class AdminDisponibilidadServlet extends HttpServlet {

    private final DisponibilidadDAO disponibilidadDAO = new DisponibilidadDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        // Se listan todas (disponibles y ocupadas) para que el admin tenga contexto completo
        List<Disponibilidad> todas = disponibilidadDAO.listarTodas();
        request.setAttribute("disponibilidades", todas);
        request.setAttribute("seccionActiva", "disponibilidad");
        request.getRequestDispatcher("/View/Administrador/Disponibilidad.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String accion = request.getParameter("accion");

        if ("agregar".equals(accion)) {
            try {
                Disponibilidad nueva = new Disponibilidad();
                nueva.setFecha(Date.valueOf(request.getParameter("fecha")));
                String horaStr = request.getParameter("hora");
                nueva.setHora(Time.valueOf(horaStr.length() == 5 ? horaStr + ":00" : horaStr));
                nueva.setEstado("Disponible");
                boolean ok = disponibilidadDAO.insertarDisponibilidad(nueva);
                if (!ok) {
                    request.setAttribute("error", "No se pudo agregar el horario. Intenta nuevamente.");
                }
            } catch (IllegalArgumentException e) {
                request.setAttribute("error", "Fecha u hora inválida.");
            }
        } else if ("eliminar".equals(accion)) {
            try {
                int id = Integer.parseInt(request.getParameter("idDisponibilidad"));
                Disponibilidad d = disponibilidadDAO.consultarDisponibilidad(id);
                if (d != null && "Disponible".equals(d.getEstado())) {
                    disponibilidadDAO.eliminarDisponibilidad(id);
                } else {
                    request.setAttribute("error", "Solo se pueden eliminar horarios que sigan 'Disponible' "
                            + "(uno ya ocupado pertenece a una reserva existente).");
                }
            } catch (NumberFormatException ignored) {
            }
        }

        if (request.getAttribute("error") != null) {
            List<Disponibilidad> todas = disponibilidadDAO.listarTodas();
            request.setAttribute("disponibilidades", todas);
            request.setAttribute("seccionActiva", "disponibilidad");
            request.getRequestDispatcher("/View/Administrador/Disponibilidad.jsp").forward(request, response);
            return;
        }

        response.sendRedirect(request.getContextPath() + "/AdminDisponibilidadServlet");
    }
}

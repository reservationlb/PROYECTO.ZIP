package Servlet;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/View/Cliente/Login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String numDocumento = request.getParameter("numDocumento");
        String contrasena = request.getParameter("contrasena");

        Usuario usuario = usuarioDAO.validarUsuario(numDocumento, contrasena);

        if (usuario != null) {
            HttpSession session = request.getSession();
            session.setAttribute("usuarioLogueado", usuario);
            session.setAttribute("nombreCliente", usuario.getNombre());
            session.setAttribute("rolId", usuario.getRolIdRol());

            // rol_id_rol = 1 -> Administrador (según Scrip.sql), el resto son roles de cliente/staff
            if (usuario.getRolIdRol() == 1) {
                response.sendRedirect(request.getContextPath() + "/AdminDashboardServlet");
            } else {
                response.sendRedirect(request.getContextPath() + "/PanelClienteServlet");
            }
        } else {
            request.setAttribute("error", "Número de documento o contraseña incorrectos.");
            request.getRequestDispatcher("/View/Cliente/Login.jsp").forward(request, response);
        }
    }
}
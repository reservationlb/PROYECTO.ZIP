package Servlet;

import Controlador.Conexion;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Paso 5 del asistente de reserva: selección de platos reales del menú
 * (tablas Categoria / Producto) para armar "Mi Pedido" del evento.
 *
 * doGet: muestra el menú navegable por categorías.
 * doPost: recibe el carrito armado en el JSP (acción "confirmar") y lo
 *         guarda en sesión antes de continuar al Resumen.
 */
@WebServlet(name = "MenuServlet", urlPatterns = {"/MenuServlet"})
public class MenuServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }
        if (session.getAttribute("reservaColor") == null) {
            // Todavía no completó los pasos previos del asistente
            response.sendRedirect(request.getContextPath() + "/DisponibilidadServlet");
            return;
        }

        cargarMenu(request);
        request.getRequestDispatcher("/View/Cliente/Menu.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        // El JS de Menu.jsp arma este campo con el formato "id:cantidad,id:cantidad,..."
        String carritoData = request.getParameter("carritoData");

        if (carritoData == null || carritoData.trim().isEmpty()) {
            request.setAttribute("errorMenu", "Tu pedido está vacío. Agrega al menos un plato antes de continuar.");
            cargarMenu(request);
            request.getRequestDispatcher("/View/Cliente/Menu.jsp").forward(request, response);
            return;
        }

        // Se vuelve a consultar el menú real (con precios oficiales de la BD)
        // para no confiar en los precios que pudo manipular el navegador.
        Map<String, Map<String, String>> platosPorId = new HashMap<>();
        for (Map<String, String> plato : obtenerListaMenu()) {
            platosPorId.put(plato.get("id"), plato);
        }

        List<Map<String, Object>> carrito = new ArrayList<>();
        for (String parItem : carritoData.split(",")) {
            String[] partes = parItem.split(":");
            if (partes.length != 2) {
                continue;
            }
            String idProducto = partes[0].trim();
            int cantidad;
            try {
                cantidad = Integer.parseInt(partes[1].trim());
            } catch (NumberFormatException e) {
                continue;
            }
            if (cantidad <= 0 || !platosPorId.containsKey(idProducto)) {
                continue;
            }

            Map<String, String> plato = platosPorId.get(idProducto);
            Map<String, Object> item = new HashMap<>();
            item.put("idProducto", Integer.parseInt(idProducto));
            item.put("nombre", plato.get("nombre"));
            item.put("precioUnitario", new BigDecimal(plato.get("precio")));
            item.put("cantidad", cantidad);
            carrito.add(item);
        }

        if (carrito.isEmpty()) {
            request.setAttribute("errorMenu", "Tu pedido está vacío. Agrega al menos un plato antes de continuar.");
            cargarMenu(request);
            request.getRequestDispatcher("/View/Cliente/Menu.jsp").forward(request, response);
            return;
        }

        session.setAttribute("carritoProductos", carrito);
        response.sendRedirect(request.getContextPath() + "/ResumenServlet");
    }

    private void cargarMenu(HttpServletRequest request) {
        request.setAttribute("listaMenu", obtenerListaMenu());
        request.setAttribute("listaCategorias", obtenerListaCategorias());
    }

    private List<Map<String, String>> obtenerListaCategorias() {
        List<Map<String, String>> listaCategorias = new ArrayList<>();
        Conexion conexion = new Conexion();
        String sqlCategorias = "SELECT id_categoria, nombre FROM Categoria ORDER BY id_categoria";

        try (Connection conn = conexion.getConn();
             PreparedStatement psCategorias = conn.prepareStatement(sqlCategorias);
             ResultSet rsCategorias = psCategorias.executeQuery()) {

            while (rsCategorias.next()) {
                Map<String, String> categoria = new HashMap<>();
                categoria.put("id", String.valueOf(rsCategorias.getInt("id_categoria")));
                categoria.put("nombre", rsCategorias.getString("nombre"));
                listaCategorias.add(categoria);
            }
        } catch (Exception e) {
            log("Error al cargar categorías del menú.", e);
        }
        return listaCategorias;
    }

    private List<Map<String, String>> obtenerListaMenu() {
        List<Map<String, String>> listaMenu = new ArrayList<>();
        Conexion conexion = new Conexion();

        // La tabla Producto de la BD contiene: id_producto, nombre, descripcion,
        // precio, id_categoria, imagen, activo. Solo se listan los platos activos
        // (activo = 1), para que lo que el administrador oculte no aparezca aquí.
        String sqlProductos =
                "SELECT p.id_producto, p.nombre, p.descripcion, "
                + "p.precio, p.id_categoria, p.imagen, c.nombre AS categoria "
                + "FROM Producto p "
                + "INNER JOIN Categoria c ON p.id_categoria = c.id_categoria "
                + "WHERE p.activo = 1 "
                + "ORDER BY p.id_categoria, p.id_producto";

        try (Connection conn = conexion.getConn();
             PreparedStatement psProductos = conn.prepareStatement(sqlProductos);
             ResultSet rsProductos = psProductos.executeQuery()) {

            while (rsProductos.next()) {
                Map<String, String> plato = new HashMap<>();
                plato.put("id", String.valueOf(rsProductos.getInt("id_producto")));
                plato.put("nombre", rsProductos.getString("nombre"));
                plato.put("descripcion", rsProductos.getString("descripcion"));
                plato.put("precio", String.format("%.0f", rsProductos.getDouble("precio")));
                plato.put("idCategoria", String.valueOf(rsProductos.getInt("id_categoria")));
                plato.put("categoria", rsProductos.getString("categoria"));
                plato.put("imagen", rsProductos.getString("imagen"));
                listaMenu.add(plato);
            }
        } catch (Exception e) {
            log("Error al cargar el menú.", e);
        }
        return listaMenu;
    }
}

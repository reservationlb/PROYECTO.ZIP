package Servlet;

import Controlador.TipoDocumentoDAO;
import Controlador.UsuarioDAO;
import Modelo.TipoDocumento;
import Modelo.Usuario;
import java.io.IOException;
import java.sql.Date;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "RegistroServlet", urlPatterns = {"/RegistroServlet"})
public class RegistroServlet extends HttpServlet {

    private final TipoDocumentoDAO tipoDocDAO = new TipoDocumentoDAO();
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<TipoDocumento> listaTipos = tipoDocDAO.listar();
        request.setAttribute("listaTiposDocumento", listaTipos);
        request.getRequestDispatcher("/View/Cliente/Registro.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");

        try {
            // 1. Obtener parámetros del formulario en Registro.jsp
            String nombre = request.getParameter("nombre");
            String apellido = request.getParameter("apellido");
            int tipoDocumentoId = Integer.parseInt(request.getParameter("tipo_documento_idtipo_documento"));
            String numDocumento = request.getParameter("numero_documento");
            String direccion = request.getParameter("direccion");
            String telefono = request.getParameter("telefono");
            String fechaNacStr = request.getParameter("fecha_nacimiento");
            String contrasena = request.getParameter("contrasena");

            // 2. Convertir la fecha ingresada al tipo java.sql.Date
            Date fechaNacimiento = Date.valueOf(fechaNacStr);

            // 3. Crear y popular el objeto Usuario según tu modelo
            Usuario nuevoUsuario = new Usuario();
            nuevoUsuario.setNombre(nombre);
            nuevoUsuario.setApellido(apellido);
            nuevoUsuario.setTipoDocumentoIdTipoDocumento(tipoDocumentoId);
            nuevoUsuario.setNumeroDocumento(numDocumento);
            nuevoUsuario.setDireccion(direccion);
            nuevoUsuario.setTelefono(telefono);
            nuevoUsuario.setFechaNacimiento(fechaNacimiento);
            nuevoUsuario.setContrasena(contrasena);

            // Valores por defecto para nuevos usuarios (Ajusta los IDs si varían en tu BD)
            nuevoUsuario.setRolIdRol(2); // Rol por defecto (ejemplo: 2 = Cliente)
            nuevoUsuario.setEstado("Activo"); // Estado inicial del registro

            // 4. Guardar en BD usando tu DAO
            boolean registrado = usuarioDAO.insertarUsuario(nuevoUsuario);

            if (registrado) {
                // Redirecciona al LoginServlet tras registrar con éxito
                response.sendRedirect(request.getContextPath() + "/LoginServlet?registro=exito");
            } else {
                request.setAttribute("error", "No se pudo registrar el usuario en la base de datos.");
                doGet(request, response);
            }

        } catch (IllegalArgumentException e) {
            request.setAttribute("error", "Formato de fecha inválido. Por favor selecciona una fecha correcta.");
            doGet(request, response);
        } catch (Exception e) {
            System.err.println("Error en RegistroServlet POST: " + e.getMessage());
            request.setAttribute("error", "Error interno al procesar el registro: " + e.getMessage());
            doGet(request, response);
        }
    }
}
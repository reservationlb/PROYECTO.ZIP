package Servlet;

import Controlador.AbonoDAO;
import Controlador.ReservaDAO;
import Controlador.ReservaProductoDAO;
import Controlador.TipoDecoracionDAO;
import Controlador.TipoEventoDAO;
import Controlador.UsuarioDAO;
import Modelo.Abono;
import Modelo.Reserva;
import Modelo.ReservaProducto;
import Modelo.TipoDecoracion;
import Modelo.TipoEvento;
import Modelo.Usuario;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

/**
 * Paso final: factura/comprobante de una reserva ya confirmada.
 * El cliente solo puede ver SUS propias reservas (o un administrador,
 * cualquiera), tal como lo pide el documento de requisitos.
 */
@WebServlet(name = "FacturaServlet", urlPatterns = {"/FacturaServlet"})
public class FacturaServlet extends HttpServlet {

    private final ReservaDAO reservaDAO = new ReservaDAO();
    private final ReservaProductoDAO detalleDAO = new ReservaProductoDAO();
    private final AbonoDAO abonoDAO = new AbonoDAO();
    private final TipoEventoDAO tipoEventoDAO = new TipoEventoDAO();
    private final TipoDecoracionDAO tipoDecoracionDAO = new TipoDecoracionDAO();
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        Usuario usuarioSesion = (Usuario) session.getAttribute("usuarioLogueado");
        int rolId = usuarioSesion.getRolIdRol();

        String idParam = request.getParameter("id");
        Integer idReserva = null;
        if (idParam != null) {
            try {
                idReserva = Integer.parseInt(idParam);
            } catch (NumberFormatException ignored) {
            }
        }
        if (idReserva == null) {
            idReserva = (Integer) session.getAttribute("ultimaReservaId");
        }
        if (idReserva == null) {
            response.sendRedirect(request.getContextPath() + "/PanelClienteServlet");
            return;
        }

        Reserva reserva = reservaDAO.consultarReserva(idReserva);
        if (reserva == null) {
            request.setAttribute("errorFactura", "No se encontró la reserva solicitada.");
            request.getRequestDispatcher("/View/Cliente/Factura.jsp").forward(request, response);
            return;
        }

        // Un cliente solo puede ver su propia factura; el administrador (rol 1) puede ver todas
        if (rolId != 1 && reserva.getUsuarioIdUsuario() != usuarioSesion.getIdUsuario()) {
            response.sendRedirect(request.getContextPath() + "/PanelClienteServlet");
            return;
        }

        TipoEvento evento = tipoEventoDAO.consultarTipoEvento(reserva.getTipoEventoIdTipoEvento());
        TipoDecoracion decoracion = tipoDecoracionDAO.consultarTipoDecoracion(reserva.getTipoDecoracionIdTipoDecoracion());
        Usuario cliente = usuarioDAO.consultarPorId(reserva.getUsuarioIdUsuario());
        List<ReservaProducto> items = detalleDAO.listarPorReserva(idReserva);
        List<Abono> abonos = abonoDAO.listarPorReserva(idReserva);

        request.setAttribute("reserva", reserva);
        request.setAttribute("evento", evento);
        request.setAttribute("decoracion", decoracion);
        request.setAttribute("cliente", cliente);
        request.setAttribute("items", items);
        request.setAttribute("abonos", abonos);

        request.getRequestDispatcher("/View/Cliente/Factura.jsp").forward(request, response);
    }
}

package Servlet;

import Controlador.CategoriaDAO;
import Controlador.ProductoDAO;
import Modelo.Categoria;
import Modelo.Producto;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "AdminMenuFormServlet", urlPatterns = {"/AdminMenuFormServlet"})
public class AdminMenuFormServlet extends HttpServlet {

    private final ProductoDAO productoDAO = new ProductoDAO();
    private final CategoriaDAO categoriaDAO = new CategoriaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String idStr = request.getParameter("id");
        Producto producto = null;
        if (idStr != null) {
            try {
                producto = productoDAO.consultar(Integer.parseInt(idStr));
            } catch (NumberFormatException ignored) {
            }
        }

        List<Categoria> categorias = categoriaDAO.listar();
        request.setAttribute("producto", producto);
        request.setAttribute("categorias", categorias);
        request.setAttribute("seccionActiva", "menu");
        request.getRequestDispatcher("/View/Administrador/MenuForm.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (!AdminDashboardServlet.esAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        try {
            String idStr = request.getParameter("idProducto");
            Producto p = new Producto();
            p.setNombre(request.getParameter("nombre"));
            p.setDescripcion(request.getParameter("descripcion"));
            p.setPrecio(Double.parseDouble(request.getParameter("precio")));
            p.setIdCategoria(Integer.parseInt(request.getParameter("idCategoria")));
            p.setImagen(request.getParameter("imagen"));

            if (idStr != null && !idStr.trim().isEmpty() && !"0".equals(idStr)) {
                p.setIdProducto(Integer.parseInt(idStr));
                productoDAO.actualizar(p);
            } else {
                productoDAO.insertar(p);
            }

            response.sendRedirect(request.getContextPath() + "/AdminMenuServlet");

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Revisa que el precio y la categoría sean válidos.");
            request.setAttribute("categorias", categoriaDAO.listar());
            request.setAttribute("seccionActiva", "menu");
            request.getRequestDispatcher("/View/Administrador/MenuForm.jsp").forward(request, response);
        }
    }
}

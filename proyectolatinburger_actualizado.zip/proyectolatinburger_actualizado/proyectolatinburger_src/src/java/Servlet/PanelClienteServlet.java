package Servlet;

import Controlador.AbonoDAO;
import Controlador.ColorDAO;
import Controlador.ReservaDAO;
import Controlador.ReservaProductoDAO;
import Controlador.TipoDecoracionDAO;
import Controlador.TipoEventoDAO;
import Controlador.TipoMenuDAO;
import Modelo.Abono;
import Modelo.Color;
import Modelo.Reserva;
import Modelo.ReservaProducto;
import Modelo.TipoDecoracion;
import Modelo.TipoEvento;
import Modelo.TipoMenu;
import Modelo.Usuario;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Panel principal del cliente: se muestra justo después de iniciar sesión.
 * Reutiliza por completo los DAO/Modelo ya existentes (Reserva, TipoEvento,
 * TipoDecoracion, TipoMenu, Color, ReservaProducto, Abono) — no se inventa
 * ninguna tabla ni dato nuevo, solo se combina lo que ya estaba armado para
 * el asistente de reserva y la factura.
 *
 * Cada reserva del cliente se enriquece con: el tipo de evento, la
 * decoración, el tipo de menú, el color (buscado por nombre en
 * color_evento), los productos adicionales (reserva_producto) y los abonos
 * registrados, calculando el saldo pendiente = valor_reserva - abonado.
 */
@WebServlet(name = "PanelClienteServlet", urlPatterns = {"/PanelClienteServlet"})
public class PanelClienteServlet extends HttpServlet {

    private final ReservaDAO reservaDAO = new ReservaDAO();
    private final TipoEventoDAO tipoEventoDAO = new TipoEventoDAO();
    private final TipoDecoracionDAO tipoDecoracionDAO = new TipoDecoracionDAO();
    private final TipoMenuDAO tipoMenuDAO = new TipoMenuDAO();
    private final ColorDAO colorDAO = new ColorDAO();
    private final ReservaProductoDAO reservaProductoDAO = new ReservaProductoDAO();
    private final AbonoDAO abonoDAO = new AbonoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");

        // Un cliente solo puede ver SUS propias reservas: la consulta ya
        // filtra por usuario_id_usuario = id del usuario en sesión.
        List<Reserva> reservas = reservaDAO.listarPorUsuarioCompleta(usuario.getIdUsuario());

        List<Map<String, Object>> tarjetas = new ArrayList<>();
        for (Reserva r : reservas) {
            Map<String, Object> tarjeta = new HashMap<>();

            TipoEvento evento = tipoEventoDAO.consultarTipoEvento(r.getTipoEventoIdTipoEvento());
            TipoDecoracion decoracion = tipoDecoracionDAO.consultarTipoDecoracion(r.getTipoDecoracionIdTipoDecoracion());
            TipoMenu tipoMenu = tipoMenuDAO.consultarTipoMenu(r.getTipoMenuIdTipoMenu());
            Color color = colorDAO.consultarPorNombre(r.getColorEvento());
            List<ReservaProducto> productos = reservaProductoDAO.listarPorReserva(r.getIdReserva());
            List<Abono> abonos = abonoDAO.listarPorReserva(r.getIdReserva());

            BigDecimal totalAbonado = BigDecimal.ZERO;
            for (Abono a : abonos) {
                if (a.getValorAbono() != null) {
                    totalAbonado = totalAbonado.add(a.getValorAbono());
                }
            }
            BigDecimal valorReserva = r.getValorReserva() != null ? r.getValorReserva() : BigDecimal.ZERO;
            BigDecimal saldoPendiente = valorReserva.subtract(totalAbonado);
            if (saldoPendiente.compareTo(BigDecimal.ZERO) < 0) {
                saldoPendiente = BigDecimal.ZERO;
            }

            tarjeta.put("reserva", r);
            tarjeta.put("evento", evento);
            tarjeta.put("decoracion", decoracion);
            tarjeta.put("tipoMenu", tipoMenu);
            tarjeta.put("color", color);
            tarjeta.put("productos", productos);
            tarjeta.put("abonos", abonos);
            tarjeta.put("totalAbonado", totalAbonado);
            tarjeta.put("saldoPendiente", saldoPendiente);

            tarjetas.add(tarjeta);
        }

        request.setAttribute("tarjetas", tarjetas);
        request.getRequestDispatcher("/View/Cliente/PanelCliente.jsp").forward(request, response);
    }
}

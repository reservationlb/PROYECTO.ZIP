package Servlet;

import Controlador.ReservaDAO;
import Modelo.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet(name = "MisPedidosServlet", urlPatterns = {"/MisPedidosServlet"})
public class MisPedidosServlet extends HttpServlet {

    private final ReservaDAO reservaDAO = new ReservaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        List<Map<String, String>> listaPedidos = reservaDAO.listarPorUsuario(usuario.getIdUsuario());

        request.setAttribute("listaPedidos", listaPedidos);
        request.getRequestDispatcher("/View/Cliente/MisPedidos.jsp").forward(request, response);
    }
}

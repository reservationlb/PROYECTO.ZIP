package Modelo;

import java.math.BigDecimal;

public class ReservaProducto {

    private int idReservaProducto;
    private int reservaIdReserva;
    private int productoIdProducto;
    private int cantidad;
    private BigDecimal precioUnitario;

    // Solo para mostrar en pantalla (no se persiste en esta tabla)
    private String nombreProducto;

    public ReservaProducto() {
    }

    public int getIdReservaProducto() {
        return idReservaProducto;
    }

    public void setIdReservaProducto(int idReservaProducto) {
        this.idReservaProducto = idReservaProducto;
    }

    public int getReservaIdReserva() {
        return reservaIdReserva;
    }

    public void setReservaIdReserva(int reservaIdReserva) {
        this.reservaIdReserva = reservaIdReserva;
    }

    public int getProductoIdProducto() {
        return productoIdProducto;
    }

    public void setProductoIdProducto(int productoIdProducto) {
        this.productoIdProducto = productoIdProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public BigDecimal getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(BigDecimal precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public BigDecimal getSubtotal() {
        if (precioUnitario == null) {
            return BigDecimal.ZERO;
        }
        return precioUnitario.multiply(BigDecimal.valueOf(cantidad));
    }
}

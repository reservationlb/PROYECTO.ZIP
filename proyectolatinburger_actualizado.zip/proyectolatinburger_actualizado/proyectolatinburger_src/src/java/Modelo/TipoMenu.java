package Modelo;

import java.math.BigDecimal;

public class TipoMenu {

    private int idTipoMenu;
    private String nombreMenu;
    private String descripcionMenu;
    private BigDecimal valorMenu;

    public TipoMenu() {
    }

    public TipoMenu(int idTipoMenu, String nombreMenu, String descripcionMenu, BigDecimal valorMenu) {
        this.idTipoMenu = idTipoMenu;
        this.nombreMenu = nombreMenu;
        this.descripcionMenu = descripcionMenu;
        this.valorMenu = valorMenu;
    }

    public int getIdTipoMenu() {
        return idTipoMenu;
    }

    public void setIdTipoMenu(int idTipoMenu) {
        this.idTipoMenu = idTipoMenu;
    }

    public String getNombreMenu() {
        return nombreMenu;
    }

    public void setNombreMenu(String nombreMenu) {
        this.nombreMenu = nombreMenu;
    }

    public String getDescripcionMenu() {
        return descripcionMenu;
    }

    public void setDescripcionMenu(String descripcionMenu) {
        this.descripcionMenu = descripcionMenu;
    }

    public BigDecimal getValorMenu() {
        return valorMenu;
    }

    public void setValorMenu(BigDecimal valorMenu) {
        this.valorMenu = valorMenu;
    }
}
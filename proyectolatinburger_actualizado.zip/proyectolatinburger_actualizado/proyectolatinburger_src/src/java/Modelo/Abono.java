package Modelo;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Abono {

    private int idAbono;
    private int reservaIdReserva;
    private String medioPago;
    private BigDecimal valorAbono;
    private Timestamp fechaAbono;
    private String estado;

    public Abono() {
    }

    public int getIdAbono() {
        return idAbono;
    }

    public void setIdAbono(int idAbono) {
        this.idAbono = idAbono;
    }

    public int getReservaIdReserva() {
        return reservaIdReserva;
    }

    public void setReservaIdReserva(int reservaIdReserva) {
        this.reservaIdReserva = reservaIdReserva;
    }

    public String getMedioPago() {
        return medioPago;
    }

    public void setMedioPago(String medioPago) {
        this.medioPago = medioPago;
    }

    public BigDecimal getValorAbono() {
        return valorAbono;
    }

    public void setValorAbono(BigDecimal valorAbono) {
        this.valorAbono = valorAbono;
    }

    public Timestamp getFechaAbono() {
        return fechaAbono;
    }

    public void setFechaAbono(Timestamp fechaAbono) {
        this.fechaAbono = fechaAbono;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}

package Modelo;

import java.sql.Date;
import java.sql.Time;

public class Disponibilidad {

    private int idDisponibilidad;
    private Date fecha;
    private Time hora;
    private String estado;

    public Disponibilidad() {
    }

    public Disponibilidad(int idDisponibilidad, Date fecha, Time hora, String estado) {
        this.idDisponibilidad = idDisponibilidad;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
    }

    public int getIdDisponibilidad() {
        return idDisponibilidad;
    }

    public void setIdDisponibilidad(int idDisponibilidad) {
        this.idDisponibilidad = idDisponibilidad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
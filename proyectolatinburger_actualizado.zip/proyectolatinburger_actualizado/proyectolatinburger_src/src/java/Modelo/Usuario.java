package Modelo;

import java.sql.Date;

public class Usuario {

    private int idUsuario;
    private String nombre;
    private String apellido;
    private String direccion;
    private String numeroDocumento;
    private String documento; // Alias / Compatibilidad
    private String telefono;
    private String correo;
    private Date fechaNacimiento;
    private Date fechaDeVencimientoClave;
    private Date autorizacionDato;
    private String userName;
    private String contrasena;
    private String password; // Alias / Compatibilidad
    private String estado;
    private int rolIdRol;
    private int tipoDocumentoIdTipoDocumento;
    private String rolDescripcion; // Solo para mostrar en listados (JOIN con rol), no se persiste desde aquí

    public Usuario() {
    }

    // Getters y Setters
    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getNumeroDocumento() { return numeroDocumento != null ? numeroDocumento : documento; }
    public void setNumeroDocumento(String numeroDocumento) { 
        this.numeroDocumento = numeroDocumento; 
        this.documento = numeroDocumento;
    }

    public String getDocumento() { return getNumeroDocumento(); }
    public void setDocumento(String documento) { setNumeroDocumento(documento); }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public Date getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(Date fechaNacimiento) { this.fechaNacimiento = fechaNacimiento; }

    public Date getFechaDeVencimientoClave() { return fechaDeVencimientoClave; }
    public void setFechaDeVencimientoClave(Date fechaDeVencimientoClave) { this.fechaDeVencimientoClave = fechaDeVencimientoClave; }

    public Date getAutorizacionDato() { return autorizacionDato; }
    public void setAutorizacionDato(Date autorizacionDato) { this.autorizacionDato = autorizacionDato; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getContrasena() { return contrasena != null ? contrasena : password; }
    public void setContrasena(String contrasena) { 
        this.contrasena = contrasena; 
        this.password = contrasena;
    }

    public String getPassword() { return getContrasena(); }
    public void setPassword(String password) { setContrasena(password); }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public int getRolIdRol() { return rolIdRol; }
    public void setRolIdRol(int rolIdRol) { this.rolIdRol = rolIdRol; }

    public int getTipoDocumentoIdTipoDocumento() { return tipoDocumentoIdTipoDocumento; }
    public void setTipoDocumentoIdTipoDocumento(int tipoDocumentoIdTipoDocumento) { this.tipoDocumentoIdTipoDocumento = tipoDocumentoIdTipoDocumento; }

    public String getRolDescripcion() { return rolDescripcion; }
    public void setRolDescripcion(String rolDescripcion) { this.rolDescripcion = rolDescripcion; }
}
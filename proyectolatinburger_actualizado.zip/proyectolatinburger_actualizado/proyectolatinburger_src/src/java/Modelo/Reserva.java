package Modelo;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;

public class Reserva {

    private int idReserva;
    private Time hora;
    private Date fecha;
    private int numeroPersona;
    private BigDecimal valorReserva;
    private int disponibilidadIdDisponibilidad;
    private int tipoMenuIdTipoMenu;
    private int tipoDecoracionIdTipoDecoracion;
    private int tipoEventoIdTipoEvento;
    private int usuarioIdUsuario;
    private String estado; // Columna agregada (migracion_v1.sql)
    private String colorEvento; // Columna agregada (migracion_v1.sql)
    private String comentarios; // Columna agregada (migracion_v1.sql)

    public Reserva() {
    }

    public Reserva(int idReserva, Time hora, Date fecha, int numeroPersona, BigDecimal valorReserva, 
                   int disponibilidadIdDisponibilidad, int tipoMenuIdTipoMenu, 
                   int tipoDecoracionIdTipoDecoracion, int tipoEventoIdTipoEvento, int usuarioIdUsuario) {
        this.idReserva = idReserva;
        this.hora = hora;
        this.fecha = fecha;
        this.numeroPersona = numeroPersona;
        this.valorReserva = valorReserva;
        this.disponibilidadIdDisponibilidad = disponibilidadIdDisponibilidad;
        this.tipoMenuIdTipoMenu = tipoMenuIdTipoMenu;
        this.tipoDecoracionIdTipoDecoracion = tipoDecoracionIdTipoDecoracion;
        this.tipoEventoIdTipoEvento = tipoEventoIdTipoEvento;
        this.usuarioIdUsuario = usuarioIdUsuario;
    }

    public int getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(int idReserva) {
        this.idReserva = idReserva;
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getNumeroPersona() {
        return numeroPersona;
    }

    public void setNumeroPersona(int numeroPersona) {
        this.numeroPersona = numeroPersona;
    }

    public BigDecimal getValorReserva() {
        return valorReserva;
    }

    public void setValorReserva(BigDecimal valorReserva) {
        this.valorReserva = valorReserva;
    }

    public int getDisponibilidadIdDisponibilidad() {
        return disponibilidadIdDisponibilidad;
    }

    public void setDisponibilidadIdDisponibilidad(int disponibilidadIdDisponibilidad) {
        this.disponibilidadIdDisponibilidad = disponibilidadIdDisponibilidad;
    }

    public int getTipoMenuIdTipoMenu() {
        return tipoMenuIdTipoMenu;
    }

    public void setTipoMenuIdTipoMenu(int tipoMenuIdTipoMenu) {
        this.tipoMenuIdTipoMenu = tipoMenuIdTipoMenu;
    }

    public int getTipoDecoracionIdTipoDecoracion() {
        return tipoDecoracionIdTipoDecoracion;
    }

    public void setTipoDecoracionIdTipoDecoracion(int tipoDecoracionIdTipoDecoracion) {
        this.tipoDecoracionIdTipoDecoracion = tipoDecoracionIdTipoDecoracion;
    }

    public int getTipoEventoIdTipoEvento() {
        return tipoEventoIdTipoEvento;
    }

    public void setTipoEventoIdTipoEvento(int tipoEventoIdTipoEvento) {
        this.tipoEventoIdTipoEvento = tipoEventoIdTipoEvento;
    }

    public int getUsuarioIdUsuario() {
        return usuarioIdUsuario;
    }

    public void setUsuarioIdUsuario(int usuarioIdUsuario) {
        this.usuarioIdUsuario = usuarioIdUsuario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getColorEvento() {
        return colorEvento;
    }

    public void setColorEvento(String colorEvento) {
        this.colorEvento = colorEvento;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }
}
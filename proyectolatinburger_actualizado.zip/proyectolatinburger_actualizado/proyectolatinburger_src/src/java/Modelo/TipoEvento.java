package Modelo;

import java.math.BigDecimal;

public class TipoEvento {

    private int idTipoEvento;
    private String nombreEvento;
    private String descripcion;
    private BigDecimal valorEvento;
    private String imagen; // Columna agregada (migracion_v2.sql)
    private boolean activo = true; // Columna agregada (migracion_v2.sql)

    public TipoEvento() {
    }

    public TipoEvento(int idTipoEvento, String nombreEvento, String descripcion, BigDecimal valorEvento) {
        this.idTipoEvento = idTipoEvento;
        this.nombreEvento = nombreEvento;
        this.descripcion = descripcion;
        this.valorEvento = valorEvento;
    }

    public int getIdTipoEvento() {
        return idTipoEvento;
    }

    public void setIdTipoEvento(int idTipoEvento) {
        this.idTipoEvento = idTipoEvento;
    }

    public String getNombreEvento() {
        return nombreEvento;
    }

    public void setNombreEvento(String nombreEvento) {
        this.nombreEvento = nombreEvento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public BigDecimal getValorEvento() {
        return valorEvento;
    }

    public void setValorEvento(BigDecimal valorEvento) {
        this.valorEvento = valorEvento;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}
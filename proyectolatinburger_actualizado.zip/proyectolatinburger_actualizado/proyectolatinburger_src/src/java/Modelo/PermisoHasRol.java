package Modelo;

public class PermisoHasRol {

    private int permisoIdPermiso;
    private int rolIdRol;

    public PermisoHasRol() {
    }

    public PermisoHasRol(int permisoIdPermiso, int rolIdRol) {
        this.permisoIdPermiso = permisoIdPermiso;
        this.rolIdRol = rolIdRol;
    }

    public int getPermisoIdPermiso() {
        return permisoIdPermiso;
    }

    public void setPermisoIdPermiso(int permisoIdPermiso) {
        this.permisoIdPermiso = permisoIdPermiso;
    }

    public int getRolIdRol() {
        return rolIdRol;
    }

    public void setRolIdRol(int rolIdRol) {
        this.rolIdRol = rolIdRol;
    }
}
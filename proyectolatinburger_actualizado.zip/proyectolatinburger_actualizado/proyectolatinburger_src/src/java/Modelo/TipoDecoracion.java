package Modelo;

import java.math.BigDecimal;

public class TipoDecoracion {

    private int idTipoDecoracion;
    private String nombreDecoracion;
    private String descripcion;
    private BigDecimal valorDecoracion;
    private String imagen; // Columna agregada (migracion_v2.sql)
    private boolean activo = true; // Columna agregada (migracion_v2.sql)

    public TipoDecoracion() {
    }

    public TipoDecoracion(int idTipoDecoracion, String nombreDecoracion, String descripcion, BigDecimal valorDecoracion) {
        this.idTipoDecoracion = idTipoDecoracion;
        this.nombreDecoracion = nombreDecoracion;
        this.descripcion = descripcion;
        this.valorDecoracion = valorDecoracion;
    }

    public int getIdTipoDecoracion() {
        return idTipoDecoracion;
    }

    public void setIdTipoDecoracion(int idTipoDecoracion) {
        this.idTipoDecoracion = idTipoDecoracion;
    }

    public String getNombreDecoracion() {
        return nombreDecoracion;
    }

    public void setNombreDecoracion(String nombreDecoracion) {
        this.nombreDecoracion = nombreDecoracion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public BigDecimal getValorDecoracion() {
        return valorDecoracion;
    }

    public void setValorDecoracion(BigDecimal valorDecoracion) {
        this.valorDecoracion = valorDecoracion;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}
package Controlador;

import Modelo.Usuario;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    // Instancia reutilizable de conexión
    private Conexion Sara = new Conexion();

    public UsuarioDAO() {
    }

    public UsuarioDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    // 1. Validar credenciales en el Login mediante Número de Documento
    public Usuario validarUsuario(String numeroDocumento, String contrasena) {
        Usuario usuario = null;
        String sql = "SELECT * FROM usuario WHERE documento = ? AND password = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, numeroDocumento);
            ps.setString(2, contrasena);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    usuario = new Usuario();
                    usuario.setIdUsuario(rs.getInt("id_usuario"));
                    usuario.setNombre(rs.getString("nombre"));
                    usuario.setApellido(rs.getString("apellido"));
                    usuario.setDireccion(rs.getString("direccion"));
                    usuario.setNumeroDocumento(rs.getString("documento"));
                    usuario.setTelefono(rs.getString("telefono"));
                    usuario.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
                    usuario.setFechaDeVencimientoClave(rs.getDate("fecha_de_vencimiento_clave"));
                    usuario.setAutorizacionDato(rs.getDate("autorizacion_dato"));
                    usuario.setContrasena(rs.getString("password"));
                    usuario.setEstado(rs.getString("estado"));
                    usuario.setRolIdRol(rs.getInt("rol_id_rol"));
                    usuario.setTipoDocumentoIdTipoDocumento(rs.getInt("tipo_documento_idtipo_documento"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al validar usuario: " + e.getMessage());
        }
        return usuario;
    }

    // 2. Insertar usuario en el Registro (Adaptado exactamente a los campos NOT NULL de tu BD)
    public boolean insertarUsuario(Usuario usuario) {
        boolean respuesta = false;

        String sql = "INSERT INTO usuario ("
                + "nombre, apellido, direccion, documento, telefono, "
                + "fecha_nacimiento, fecha_de_vencimiento_clave, autorizacion_dato, "
                + "password, estado, rol_id_rol, tipo_documento_idtipo_documento"
                + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // Generación de fechas automáticas requeridas para cumplir restricciones NOT NULL
            Date fechaActual = Date.valueOf(LocalDate.now());
            Date fechaVencimiento = Date.valueOf(LocalDate.now().plusYears(1));

            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getApellido());
            ps.setString(3, usuario.getDireccion());
            ps.setString(4, usuario.getNumeroDocumento());
            ps.setString(5, usuario.getTelefono());
            ps.setDate(6, usuario.getFechaNacimiento());
            ps.setDate(7, fechaVencimiento);                     // fecha_de_vencimiento_clave
            ps.setDate(8, fechaActual);                         // autorizacion_dato
            ps.setString(9, usuario.getContrasena());            // asigna a columna 'password'
            ps.setString(10, usuario.getEstado() != null ? usuario.getEstado() : "Activo");
            ps.setInt(11, usuario.getRolIdRol() > 0 ? usuario.getRolIdRol() : 2); // 2 = Rol Cliente
            ps.setInt(12, usuario.getTipoDocumentoIdTipoDocumento());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }

        } catch (SQLException e) {
            System.err.println("Error al insertar usuario en BD: " + e.getMessage());
            e.printStackTrace();
        }

        return respuesta;
    }

    // 3. Consultar usuario por número de documento
    public Usuario consultarUsuario(String documento) {
        Usuario usuario = null;
        String sql = "SELECT * FROM usuario WHERE documento = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, documento);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    usuario = new Usuario();
                    usuario.setIdUsuario(rs.getInt("id_usuario"));
                    usuario.setNombre(rs.getString("nombre"));
                    usuario.setApellido(rs.getString("apellido"));
                    usuario.setDireccion(rs.getString("direccion"));
                    usuario.setNumeroDocumento(rs.getString("documento"));
                    usuario.setTelefono(rs.getString("telefono"));
                    usuario.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
                    usuario.setFechaDeVencimientoClave(rs.getDate("fecha_de_vencimiento_clave"));
                    usuario.setAutorizacionDato(rs.getDate("autorizacion_dato"));
                    usuario.setContrasena(rs.getString("password"));
                    usuario.setEstado(rs.getString("estado"));
                    usuario.setRolIdRol(rs.getInt("rol_id_rol"));
                    usuario.setTipoDocumentoIdTipoDocumento(rs.getInt("tipo_documento_idtipo_documento"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar usuario: " + e.getMessage());
        }
        return usuario;
    }

    // 3b. Consultar usuario por su id (usado por el panel de administrador)
    public Usuario consultarPorId(int idUsuario) {
        Usuario usuario = null;
        String sql = "SELECT * FROM usuario WHERE id_usuario = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    usuario = new Usuario();
                    usuario.setIdUsuario(rs.getInt("id_usuario"));
                    usuario.setNombre(rs.getString("nombre"));
                    usuario.setApellido(rs.getString("apellido"));
                    usuario.setDireccion(rs.getString("direccion"));
                    usuario.setNumeroDocumento(rs.getString("documento"));
                    usuario.setTelefono(rs.getString("telefono"));
                    usuario.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
                    usuario.setFechaDeVencimientoClave(rs.getDate("fecha_de_vencimiento_clave"));
                    usuario.setAutorizacionDato(rs.getDate("autorizacion_dato"));
                    usuario.setContrasena(rs.getString("password"));
                    usuario.setEstado(rs.getString("estado"));
                    usuario.setRolIdRol(rs.getInt("rol_id_rol"));
                    usuario.setTipoDocumentoIdTipoDocumento(rs.getInt("tipo_documento_idtipo_documento"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar usuario por id: " + e.getMessage());
        }
        return usuario;
    }

    // 3c. Listar todos los usuarios (panel de administrador -> Usuarios)
    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT u.*, r.descripcion AS rol_descripcion FROM usuario u "
                + "INNER JOIN rol r ON u.rol_id_rol = r.id_rol ORDER BY u.id_usuario";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setIdUsuario(rs.getInt("id_usuario"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setApellido(rs.getString("apellido"));
                usuario.setDireccion(rs.getString("direccion"));
                usuario.setNumeroDocumento(rs.getString("documento"));
                usuario.setTelefono(rs.getString("telefono"));
                usuario.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
                usuario.setEstado(rs.getString("estado"));
                usuario.setRolIdRol(rs.getInt("rol_id_rol"));
                usuario.setTipoDocumentoIdTipoDocumento(rs.getInt("tipo_documento_idtipo_documento"));
                usuario.setRolDescripcion(rs.getString("rol_descripcion"));
                lista.add(usuario);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar usuarios: " + e.getMessage());
        }
        return lista;
    }

    // 4. Actualizar usuario
    public boolean actualizarUsuario(Usuario usuario) {
        String sql = "UPDATE usuario SET nombre = ?, apellido = ?, direccion = ?, telefono = ? WHERE id_usuario = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getApellido());
            ps.setString(3, usuario.getDireccion());
            ps.setString(4, usuario.getTelefono());
            ps.setInt(5, usuario.getIdUsuario());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar usuario: " + e.getMessage());
            return false;
        }
    }

    // 5. Eliminar usuario
    public boolean eliminarUsuario(int idUsuario) {
        String sql = "DELETE FROM usuario WHERE id_usuario = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar usuario: " + e.getMessage());
            return false;
        }
    }

    // 6. Activar usuario
    public boolean activarUsuario(int idUsuario) {
        String sql = "UPDATE usuario SET estado = 'Activo' WHERE id_usuario = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al activar usuario: " + e.getMessage());
            return false;
        }
    }

    // 7. Inactivar usuario
    public boolean inactivarUsuario(int idUsuario) {
        String sql = "UPDATE usuario SET estado = 'Inactivo' WHERE id_usuario = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al inactivar usuario: " + e.getMessage());
            return false;
        }
    }
}
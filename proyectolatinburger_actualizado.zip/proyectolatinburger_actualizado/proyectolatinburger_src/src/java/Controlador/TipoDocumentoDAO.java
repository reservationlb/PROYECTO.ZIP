package Controlador;

import Modelo.TipoDocumento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoDocumentoDAO {

    private Conexion Sara = new Conexion();

    public TipoDocumentoDAO() {
    }

    public TipoDocumentoDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    public List<TipoDocumento> listar() {
        List<TipoDocumento> lista = new ArrayList<>();
        String querySql = "SELECT id_tipo_documento, descripcion FROM tipo_documento";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                TipoDocumento td = new TipoDocumento();
                td.setIdTipoDocumento(rs.getInt("id_tipo_documento"));
                td.setDescripcion(rs.getString("descripcion"));
                lista.add(td);
            }

        } catch (SQLException e) {
            System.err.println("Error al listar TipoDocumento: " + e.getMessage());
        }
        return lista;
    }

    public TipoDocumento consultarTipoDocumento(int idTipoDocumento) {
        TipoDocumento miTipoDoc = null;
        String querySql = "SELECT id_tipo_documento, descripcion FROM tipo_documento WHERE id_tipo_documento = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idTipoDocumento);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miTipoDoc = new TipoDocumento();
                    miTipoDoc.setIdTipoDocumento(rs.getInt("id_tipo_documento"));
                    miTipoDoc.setDescripcion(rs.getString("descripcion"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar TipoDocumento: " + e.getMessage());
        }
        return miTipoDoc;
    }

    public boolean insertarTipoDocumento(TipoDocumento miTipoDoc) {
        boolean respuesta = false;
        String querySql = "INSERT INTO tipo_documento (id_tipo_documento, descripcion) VALUES (?, ?)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miTipoDoc.getIdTipoDocumento());
            ps.setString(2, miTipoDoc.getDescripcion());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar TipoDocumento: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean actualizarTipoDocumento(TipoDocumento miTipoDoc) {
        boolean respuesta = false;
        String querySql = "UPDATE tipo_documento SET descripcion = ? WHERE id_tipo_documento = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miTipoDoc.getDescripcion());
            ps.setInt(2, miTipoDoc.getIdTipoDocumento());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar TipoDocumento: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean eliminarTipoDocumento(int idTipoDocumento) {
        boolean respuesta = false;
        String querySql = "DELETE FROM tipo_documento WHERE id_tipo_documento = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idTipoDocumento);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar TipoDocumento: " + e.getMessage());
        }
        return respuesta;
    }
}
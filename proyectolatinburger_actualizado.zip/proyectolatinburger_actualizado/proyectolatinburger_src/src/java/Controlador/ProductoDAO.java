package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import Modelo.Producto;

public class ProductoDAO {

    // Nota: "producto"/"Producto" y "categoria"/"Categoria" son el mismo objeto
    // en MySQL en Windows (case-insensitive por defecto), tal como ya lo usaba
    // el resto del proyecto (MenuServlet usa "Producto"/"Categoria").

    public List<Producto> listar() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT id_producto, nombre, descripcion, precio, id_categoria, imagen, activo "
                + "FROM Producto WHERE activo = 1";

        Conexion cn = new Conexion();

        try (Connection con = cn.getConn();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }

        } catch (Exception e) {
            System.err.println("Error en ProductoDAO.listar: " + e.getMessage());
            e.printStackTrace();
        }

        return lista;
    }

    public List<Producto> listarPorCategoria(int idCategoria) {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT id_producto, nombre, descripcion, precio, id_categoria, imagen, activo "
                + "FROM Producto WHERE id_categoria = ? AND activo = 1";

        Conexion cn = new Conexion();

        try (Connection con = cn.getConn();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCategoria);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }

        } catch (Exception e) {
            System.err.println("Error en ProductoDAO.listarPorCategoria: " + e.getMessage());
            e.printStackTrace();
        }

        return lista;
    }

    // Panel de administrador: necesita ver también los platos ocultos
    public List<Producto> listarTodos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT id_producto, nombre, descripcion, precio, id_categoria, imagen, activo "
                + "FROM Producto ORDER BY id_categoria, nombre";

        Conexion cn = new Conexion();

        try (Connection con = cn.getConn();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }

        } catch (Exception e) {
            System.err.println("Error en ProductoDAO.listarTodos: " + e.getMessage());
            e.printStackTrace();
        }

        return lista;
    }

    public Producto consultar(int idProducto) {
        Producto p = null;
        String sql = "SELECT id_producto, nombre, descripcion, precio, id_categoria, imagen, activo "
                + "FROM Producto WHERE id_producto = ?";

        Conexion cn = new Conexion();

        try (Connection con = cn.getConn();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    p = mapear(rs);
                }
            }
        } catch (Exception e) {
            System.err.println("Error en ProductoDAO.consultar: " + e.getMessage());
            e.printStackTrace();
        }
        return p;
    }

    public boolean insertar(Producto p) {
        boolean respuesta = false;
        String sql = "INSERT INTO Producto (nombre, descripcion, precio, id_categoria, imagen, activo) "
                + "VALUES (?, ?, ?, ?, ?, 1)";

        Conexion cn = new Conexion();

        try (Connection con = cn.getConn();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setDouble(3, p.getPrecio());
            ps.setInt(4, p.getIdCategoria());
            ps.setString(5, p.getImagen());

            respuesta = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error en ProductoDAO.insertar: " + e.getMessage());
            e.printStackTrace();
        }
        return respuesta;
    }

    public boolean actualizar(Producto p) {
        boolean respuesta = false;
        String sql = "UPDATE Producto SET nombre = ?, descripcion = ?, precio = ?, id_categoria = ?, imagen = ? "
                + "WHERE id_producto = ?";

        Conexion cn = new Conexion();

        try (Connection con = cn.getConn();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setDouble(3, p.getPrecio());
            ps.setInt(4, p.getIdCategoria());
            ps.setString(5, p.getImagen());
            ps.setInt(6, p.getIdProducto());

            respuesta = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error en ProductoDAO.actualizar: " + e.getMessage());
            e.printStackTrace();
        }
        return respuesta;
    }

    // "Ocultar" / "Mostrar" plato sin borrarlo físicamente (según lo pedido)
    public boolean cambiarActivo(int idProducto, boolean activo) {
        boolean respuesta = false;
        String sql = "UPDATE Producto SET activo = ? WHERE id_producto = ?";

        Conexion cn = new Conexion();

        try (Connection con = cn.getConn();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, activo ? 1 : 0);
            ps.setInt(2, idProducto);

            respuesta = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error en ProductoDAO.cambiarActivo: " + e.getMessage());
            e.printStackTrace();
        }
        return respuesta;
    }

    private Producto mapear(ResultSet rs) throws Exception {
        Producto p = new Producto();
        p.setIdProducto(rs.getInt("id_producto"));
        p.setNombre(rs.getString("nombre"));
        p.setDescripcion(rs.getString("descripcion"));
        p.setPrecio(rs.getDouble("precio"));
        p.setIdCategoria(rs.getInt("id_categoria"));
        p.setImagen(rs.getString("imagen"));
        p.setActivo(rs.getBoolean("activo"));
        return p;
    }
}
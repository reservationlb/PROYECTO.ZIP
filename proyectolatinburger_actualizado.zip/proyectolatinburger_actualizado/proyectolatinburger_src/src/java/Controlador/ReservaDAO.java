package Controlador;

import Modelo.Abono;
import Modelo.Reserva;
import Modelo.ReservaProducto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReservaDAO {

    private Conexion Sara = new Conexion();

    public ReservaDAO() {
    }

    public ReservaDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    /**
     * Confirma una reserva completa de forma transaccional:
     * 1) valida y ocupa el slot de disponibilidad (con bloqueo de fila),
     * 2) inserta la reserva,
     * 3) inserta cada ítem del pedido (reserva_producto),
     * 4) inserta el abono si se indicó uno.
     * Si el slot ya no está 'Disponible' (otro usuario se adelantó), hace
     * rollback de todo y retorna -1, cumpliendo el requisito de que dos
     * personas no puedan reservar el mismo horario.
     *
     * @return el id_reserva generado, o -1 si el horario ya no estaba disponible,
     *         o -2 si ocurrió un error inesperado.
     */
    public int insertarReservaCompleta(Reserva reserva, List<ReservaProducto> items, Abono abono) {
        DisponibilidadDAO dispDAO = new DisponibilidadDAO();
        ReservaProductoDAO detalleDAO = new ReservaProductoDAO();
        AbonoDAO abonoDAO = new AbonoDAO();

        String insertReserva = "INSERT INTO reserva (hora, fecha, numero_persona, valor_reserva, "
                + "disponibilidad_id_disponibilidad, tipo_menu_id_tipo_menu, tipo_decoracion_id_tipo_decoracion, "
                + "tipo_evento_id_tipo_evento, usuario_id_usuario, estado, color_evento, comentarios) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        Connection conn = null;
        try {
            conn = Sara.getConn();
            if (conn == null) {
                System.err.println("No se pudo abrir conexión con la base de datos.");
                return -2;
            }
            conn.setAutoCommit(false);

            // 1) Bloquea y valida la disponibilidad dentro de la misma transacción
            boolean ocupado = dispDAO.ocuparDisponibilidad(conn, reserva.getDisponibilidadIdDisponibilidad());
            if (!ocupado) {
                conn.rollback();
                return -1; // Ya fue tomado por otro cliente (o ya no existe / no está disponible)
            }

            // 2) Inserta la reserva
            int idReservaGenerado;
            try (PreparedStatement ps = conn.prepareStatement(insertReserva, PreparedStatement.RETURN_GENERATED_KEYS)) {
                // Igual que en DisponibilidadDAO: se guarda como texto para evitar el
                // desplazamiento de huso horario del driver JDBC con setDate()/setTime().
                ps.setString(1, reserva.getHora().toString());
                ps.setString(2, reserva.getFecha().toString());
                ps.setInt(3, reserva.getNumeroPersona());
                ps.setBigDecimal(4, reserva.getValorReserva());
                ps.setInt(5, reserva.getDisponibilidadIdDisponibilidad());
                ps.setInt(6, reserva.getTipoMenuIdTipoMenu());
                ps.setInt(7, reserva.getTipoDecoracionIdTipoDecoracion());
                ps.setInt(8, reserva.getTipoEventoIdTipoEvento());
                ps.setInt(9, reserva.getUsuarioIdUsuario());
                ps.setString(10, "Pendiente");
                ps.setString(11, reserva.getColorEvento());
                ps.setString(12, reserva.getComentarios());

                if (ps.executeUpdate() == 0) {
                    conn.rollback();
                    return -2;
                }
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        idReservaGenerado = keys.getInt(1);
                    } else {
                        conn.rollback();
                        return -2;
                    }
                }
            }

            // 3) Inserta los ítems del pedido
            if (items != null) {
                for (ReservaProducto item : items) {
                    item.setReservaIdReserva(idReservaGenerado);
                    detalleDAO.insertar(conn, item);
                }
            }

            // 4) Inserta el abono (si el cliente registró uno)
            if (abono != null) {
                abono.setReservaIdReserva(idReservaGenerado);
                abonoDAO.insertar(conn, abono);
            }

            conn.commit();
            return idReservaGenerado;

        } catch (SQLException e) {
            System.err.println("Error al confirmar Reserva (transacción revertida): " + e.getMessage());
            e.printStackTrace();
            try {
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException ex) {
                System.err.println("Error adicional al hacer rollback: " + ex.getMessage());
            }
            return -2;
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println("Error al cerrar conexión: " + ex.getMessage());
            }
        }
    }

    // Reservas de un cliente, con la info ya combinada para "Mis Pedidos"
    public List<Map<String, String>> listarPorUsuario(int idUsuario) {
        List<Map<String, String>> lista = new ArrayList<>();
        String sql = "SELECT r.id_reserva, r.fecha, r.hora, r.numero_persona, r.valor_reserva, r.estado, "
                + "te.nombre_evento, td.nombre_decoracion "
                + "FROM reserva r "
                + "INNER JOIN tipo_evento te ON r.tipo_evento_id_tipo_evento = te.id_tipo_evento "
                + "INNER JOIN tipo_decoracion td ON r.tipo_decoracion_id_tipo_decoracion = td.id_tipo_decoracion "
                + "WHERE r.usuario_id_usuario = ? ORDER BY r.fecha DESC, r.hora DESC";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, String> fila = new HashMap<>();
                    fila.put("id_pedido", String.valueOf(rs.getInt("id_reserva")));
                    fila.put("fecha", rs.getString("fecha") + " " + rs.getString("hora"));
                    fila.put("total", String.format("%,.0f", rs.getDouble("valor_reserva")));
                    fila.put("estado", rs.getString("estado"));
                    fila.put("evento", rs.getString("nombre_evento"));
                    fila.put("decoracion", rs.getString("nombre_decoracion"));
                    lista.add(fila);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar reservas por usuario: " + e.getMessage());
        }
        return lista;
    }

    // Listado completo para el panel de administrador (Reservas / Dashboard)
    public List<Map<String, String>> listarTodasConDetalle() {
        List<Map<String, String>> lista = new ArrayList<>();
        String sql = "SELECT r.id_reserva, r.fecha, r.hora, r.numero_persona, r.valor_reserva, r.estado, "
                + "te.nombre_evento, td.nombre_decoracion, u.nombre, u.apellido "
                + "FROM reserva r "
                + "INNER JOIN tipo_evento te ON r.tipo_evento_id_tipo_evento = te.id_tipo_evento "
                + "INNER JOIN tipo_decoracion td ON r.tipo_decoracion_id_tipo_decoracion = td.id_tipo_decoracion "
                + "INNER JOIN usuario u ON r.usuario_id_usuario = u.id_usuario "
                + "ORDER BY r.fecha DESC, r.hora DESC";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, String> fila = new HashMap<>();
                fila.put("id_reserva", String.valueOf(rs.getInt("id_reserva")));
                fila.put("fecha", rs.getString("fecha"));
                fila.put("hora", rs.getString("hora"));
                fila.put("numero_persona", String.valueOf(rs.getInt("numero_persona")));
                fila.put("total", String.format("%,.0f", rs.getDouble("valor_reserva")));
                fila.put("estado", rs.getString("estado"));
                fila.put("evento", rs.getString("nombre_evento"));
                fila.put("decoracion", rs.getString("nombre_decoracion"));
                fila.put("cliente", rs.getString("nombre") + " " + rs.getString("apellido"));
                lista.add(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar todas las reservas: " + e.getMessage());
        }
        return lista;
    }

    // Cambia el estado de una reserva (gestión de reservas del administrador)
    public boolean actualizarEstado(int idReserva, String nuevoEstado) {
        boolean respuesta = false;
        String sql = "UPDATE reserva SET estado = ? WHERE id_reserva = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nuevoEstado);
            ps.setInt(2, idReserva);
            respuesta = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar estado de Reserva: " + e.getMessage());
        }
        return respuesta;
    }

    // Cancela la reserva y libera nuevamente su horario en disponibilidad
    public boolean cancelarReserva(int idReserva) {
        DisponibilidadDAO dispDAO = new DisponibilidadDAO();
        Reserva r = consultarReserva(idReserva);
        if (r == null) {
            return false;
        }
        boolean actualizado = actualizarEstado(idReserva, "Cancelada");
        if (actualizado) {
            dispDAO.liberarDisponibilidad(r.getDisponibilidadIdDisponibilidad());
        }
        return actualizado;
    }

    // ---- Métricas para el Dashboard / Reportes del administrador ----

    public int contarReservasHoy() {
        String sql = "SELECT COUNT(*) AS total FROM reserva WHERE fecha = CURDATE() AND estado <> 'Cancelada'";
        return contarConSql(sql);
    }

    public double sumarValorHoy() {
        double total = 0;
        String sql = "SELECT COALESCE(SUM(valor_reserva), 0) AS total FROM reserva WHERE fecha = CURDATE() AND estado <> 'Cancelada'";
        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                total = rs.getDouble("total");
            }
        } catch (SQLException e) {
            System.err.println("Error al sumar valor de reservas de hoy: " + e.getMessage());
        }
        return total;
    }

    public int contarReservasPendientes() {
        String sql = "SELECT COUNT(*) AS total FROM reserva WHERE estado = 'Pendiente'";
        return contarConSql(sql);
    }

    public int contarReservasMes(int anio, int mes) {
        String sql = "SELECT COUNT(*) AS total FROM reserva WHERE YEAR(fecha) = " + anio
                + " AND MONTH(fecha) = " + mes + " AND estado <> 'Cancelada'";
        return contarConSql(sql);
    }

    public double sumarValorMes(int anio, int mes) {
        double total = 0;
        String sql = "SELECT COALESCE(SUM(valor_reserva), 0) AS total FROM reserva "
                + "WHERE YEAR(fecha) = ? AND MONTH(fecha) = ? AND estado <> 'Cancelada'";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, anio);
            ps.setInt(2, mes);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    total = rs.getDouble("total");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al sumar valor de reservas del mes: " + e.getMessage());
        }
        return total;
    }

    private int contarConSql(String sql) {
        int total = 0;
        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                total = rs.getInt("total");
            }
        } catch (SQLException e) {
            System.err.println("Error al contar reservas: " + e.getMessage());
        }
        return total;
    }

    // Reservas completas de un cliente (objetos Reserva reales), para el Panel de Cliente
    public List<Reserva> listarPorUsuarioCompleta(int idUsuario) {
        List<Reserva> lista = new ArrayList<>();
        String sql = "SELECT id_reserva, hora, fecha, numero_persona, valor_reserva, "
                + "disponibilidad_id_disponibilidad, tipo_menu_id_tipo_menu, tipo_decoracion_id_tipo_decoracion, "
                + "tipo_evento_id_tipo_evento, usuario_id_usuario, estado, color_evento, comentarios "
                + "FROM reserva WHERE usuario_id_usuario = ? ORDER BY fecha DESC, hora DESC";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Reserva r = new Reserva();
                    r.setIdReserva(rs.getInt("id_reserva"));
                    r.setHora(java.sql.Time.valueOf(rs.getString("hora")));
                    r.setFecha(java.sql.Date.valueOf(rs.getString("fecha")));
                    r.setNumeroPersona(rs.getInt("numero_persona"));
                    r.setValorReserva(rs.getBigDecimal("valor_reserva"));
                    r.setDisponibilidadIdDisponibilidad(rs.getInt("disponibilidad_id_disponibilidad"));
                    r.setTipoMenuIdTipoMenu(rs.getInt("tipo_menu_id_tipo_menu"));
                    r.setTipoDecoracionIdTipoDecoracion(rs.getInt("tipo_decoracion_id_tipo_decoracion"));
                    r.setTipoEventoIdTipoEvento(rs.getInt("tipo_evento_id_tipo_evento"));
                    r.setUsuarioIdUsuario(rs.getInt("usuario_id_usuario"));
                    r.setEstado(rs.getString("estado"));
                    r.setColorEvento(rs.getString("color_evento"));
                    r.setComentarios(rs.getString("comentarios"));
                    lista.add(r);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar reservas completas por usuario: " + e.getMessage());
        }
        return lista;
    }

    // Reservas completas para el admin (reutilizable si se necesita el detalle por id de usuario)
    public Reserva consultarReserva(int idReserva) {
        Reserva miReserva = null;
        String querySql = "SELECT id_reserva, hora, fecha, numero_persona, valor_reserva, "
                + "disponibilidad_id_disponibilidad, tipo_menu_id_tipo_menu, tipo_decoracion_id_tipo_decoracion, "
                + "tipo_evento_id_tipo_evento, usuario_id_usuario, estado, color_evento, comentarios "
                + "FROM reserva WHERE id_reserva = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idReserva);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miReserva = new Reserva();
                    miReserva.setIdReserva(rs.getInt("id_reserva"));
                    miReserva.setHora(java.sql.Time.valueOf(rs.getString("hora")));
                    miReserva.setFecha(java.sql.Date.valueOf(rs.getString("fecha")));
                    miReserva.setNumeroPersona(rs.getInt("numero_persona"));
                    miReserva.setValorReserva(rs.getBigDecimal("valor_reserva"));
                    miReserva.setDisponibilidadIdDisponibilidad(rs.getInt("disponibilidad_id_disponibilidad"));
                    miReserva.setTipoMenuIdTipoMenu(rs.getInt("tipo_menu_id_tipo_menu"));
                    miReserva.setTipoDecoracionIdTipoDecoracion(rs.getInt("tipo_decoracion_id_tipo_decoracion"));
                    miReserva.setTipoEventoIdTipoEvento(rs.getInt("tipo_evento_id_tipo_evento"));
                    miReserva.setUsuarioIdUsuario(rs.getInt("usuario_id_usuario"));
                    miReserva.setEstado(rs.getString("estado"));
                    miReserva.setColorEvento(rs.getString("color_evento"));
                    miReserva.setComentarios(rs.getString("comentarios"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar Reserva: " + e.getMessage());
        }
        return miReserva;
    }

    public boolean insertarReserva(Reserva miReserva) {
        boolean respuesta = false;
        String querySql = "INSERT INTO reserva (hora, fecha, numero_persona, valor_reserva, "
                + "disponibilidad_id_disponibilidad, tipo_menu_id_tipo_menu, tipo_decoracion_id_tipo_decoracion, "
                + "tipo_evento_id_tipo_evento, usuario_id_usuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setTime(1, miReserva.getHora());
            ps.setDate(2, miReserva.getFecha());
            ps.setInt(3, miReserva.getNumeroPersona());
            ps.setBigDecimal(4, miReserva.getValorReserva());
            ps.setInt(5, miReserva.getDisponibilidadIdDisponibilidad());
            ps.setInt(6, miReserva.getTipoMenuIdTipoMenu());
            ps.setInt(7, miReserva.getTipoDecoracionIdTipoDecoracion());
            ps.setInt(8, miReserva.getTipoEventoIdTipoEvento());
            ps.setInt(9, miReserva.getUsuarioIdUsuario());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar Reserva: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean actualizarReserva(Reserva miReserva) {
        boolean respuesta = false;
        String querySql = "UPDATE reserva SET hora = ?, fecha = ?, numero_persona = ?, valor_reserva = ?, "
                + "disponibilidad_id_disponibilidad = ?, tipo_menu_id_tipo_menu = ?, "
                + "tipo_decoracion_id_tipo_decoracion = ?, tipo_evento_id_tipo_evento = ?, "
                + "usuario_id_usuario = ? WHERE id_reserva = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setTime(1, miReserva.getHora());
            ps.setDate(2, miReserva.getFecha());
            ps.setInt(3, miReserva.getNumeroPersona());
            ps.setBigDecimal(4, miReserva.getValorReserva());
            ps.setInt(5, miReserva.getDisponibilidadIdDisponibilidad());
            ps.setInt(6, miReserva.getTipoMenuIdTipoMenu());
            ps.setInt(7, miReserva.getTipoDecoracionIdTipoDecoracion());
            ps.setInt(8, miReserva.getTipoEventoIdTipoEvento());
            ps.setInt(9, miReserva.getUsuarioIdUsuario());
            ps.setInt(10, miReserva.getIdReserva());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar Reserva: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean eliminarReserva(int idReserva) {
        boolean respuesta = false;
        String querySql = "DELETE FROM reserva WHERE id_reserva = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idReserva);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar Reserva: " + e.getMessage());
        }
        return respuesta;
    }
}
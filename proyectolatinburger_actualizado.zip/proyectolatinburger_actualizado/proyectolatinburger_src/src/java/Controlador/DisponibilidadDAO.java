package Controlador;

import Modelo.Disponibilidad;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class DisponibilidadDAO {

    private Conexion Sara = new Conexion();

    public DisponibilidadDAO() {
    }

    public DisponibilidadDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    // Usado por DisponibilidadServlet para listar próximas fechas/horas libres
    public List<Disponibilidad> listarDisponibles(Date fechaFiltro) {
        List<Disponibilidad> lista = new ArrayList<>();
        boolean hayFiltro = (fechaFiltro != null);
        String querySql = hayFiltro
                ? "SELECT id_disponibilidad, fecha, hora, estado FROM disponibilidad WHERE fecha = ? AND estado = 'Disponible' AND fecha >= CURDATE() ORDER BY hora ASC"
                : "SELECT id_disponibilidad, fecha, hora, estado FROM disponibilidad WHERE estado = 'Disponible' AND fecha >= CURDATE() ORDER BY fecha ASC, hora ASC";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            if (hayFiltro) {
                // Se envía como texto plano ("yyyy-MM-dd") en vez de setDate(): así MySQL
                // hace el cast directamente del literal, sin que el driver JDBC aplique
                // ninguna conversión de zona horaria (ver nota en consultarPorFechaYHora).
                ps.setString(1, fechaFiltro.toString());
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Disponibilidad d = new Disponibilidad();
                    d.setIdDisponibilidad(rs.getInt("id_disponibilidad"));
                    d.setFecha(Date.valueOf(rs.getString("fecha")));
                    d.setHora(Time.valueOf(rs.getString("hora")));
                    d.setEstado(rs.getString("estado"));
                    lista.add(d);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar Disponibilidad: " + e.getMessage());
        }
        return lista;
    }

    // Usado por el panel de administrador: todas, sin filtrar por estado
    public List<Disponibilidad> listarTodas() {
        List<Disponibilidad> lista = new ArrayList<>();
        String querySql = "SELECT id_disponibilidad, fecha, hora, estado FROM disponibilidad ORDER BY fecha DESC, hora ASC";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Disponibilidad d = new Disponibilidad();
                d.setIdDisponibilidad(rs.getInt("id_disponibilidad"));
                d.setFecha(Date.valueOf(rs.getString("fecha")));
                d.setHora(Time.valueOf(rs.getString("hora")));
                d.setEstado(rs.getString("estado"));
                lista.add(d);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar todas las Disponibilidad: " + e.getMessage());
        }
        return lista;
    }

    // Busca el slot exacto que el cliente seleccionó, y que siga 'Disponible'
    //
    // IMPORTANTE: se comparan fecha/hora como texto ("yyyy-MM-dd" / "HH:mm:ss") y
    // NO con ps.setDate()/ps.setTime(). La URL de conexión trae
    // "useTimezone=true&serverTimezone=UTC" (Conexion.java), y con ese driver,
    // setDate()/setTime() puede aplicar una conversión de huso horario que
    // desplaza el valor guardado respecto al que se compara después —
    // los horarios cargados por Scrip.sql (insertados directo por SQL) nunca
    // pasaban por esa conversión y por eso siempre funcionaban, pero los que se
    // agregan desde el panel de administrador (insertados vía JDBC) sí quedaban
    // desfasados y la comparación exacta fallaba. Comparar como texto evita el
    // problema por completo, porque MySQL castea el literal tal cual se escribió.
    public Disponibilidad consultarPorFechaYHora(Date fecha, Time hora) {
        Disponibilidad miDisp = null;
        String querySql = "SELECT id_disponibilidad, fecha, hora, estado FROM disponibilidad "
                + "WHERE fecha = ? AND hora = ? AND estado = 'Disponible'";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, fecha.toString());
            ps.setString(2, hora.toString());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miDisp = new Disponibilidad();
                    miDisp.setIdDisponibilidad(rs.getInt("id_disponibilidad"));
                    miDisp.setFecha(Date.valueOf(rs.getString("fecha")));
                    miDisp.setHora(Time.valueOf(rs.getString("hora")));
                    miDisp.setEstado(rs.getString("estado"));
                }
            }

            // DIAGNÓSTICO TEMPORAL: si no hubo match, muestra en el log del servidor
            // exactamente qué se buscó y qué hay realmente guardado ese día, para
            // detectar cualquier diferencia (espacios, formato, estado, etc.)
            if (miDisp == null) {
                System.err.println("[DIAGNOSTICO Disponibilidad] Buscando fecha='" + fecha
                        + "' hora='" + hora + "' estado='Disponible' -> SIN COINCIDENCIA.");
                String debugSql = "SELECT id_disponibilidad, fecha, hora, estado FROM disponibilidad WHERE fecha = ?";
                try (PreparedStatement psDebug = conn.prepareStatement(debugSql)) {
                    psDebug.setString(1, fecha.toString());
                    try (ResultSet rsDebug = psDebug.executeQuery()) {
                        boolean huboFilas = false;
                        while (rsDebug.next()) {
                            huboFilas = true;
                            System.err.println("[DIAGNOSTICO Disponibilidad] Fila real en BD -> id="
                                    + rsDebug.getInt("id_disponibilidad")
                                    + " fecha='" + rsDebug.getDate("fecha") + "'"
                                    + " hora='" + rsDebug.getTime("hora") + "'"
                                    + " estado='" + rsDebug.getString("estado") + "'");
                        }
                        if (!huboFilas) {
                            System.err.println("[DIAGNOSTICO Disponibilidad] No existe NINGUNA fila en la tabla "
                                    + "disponibilidad con fecha = '" + fecha + "'.");
                        }
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar Disponibilidad por fecha/hora: " + e.getMessage());
        }
        return miDisp;
    }

    // Marca el slot como ocupado dentro de una transacción ya abierta
    // (usado por ReservaDAO.insertarReservaCompleta para evitar doble reserva)
    public boolean ocuparDisponibilidad(Connection conn, int idDisponibilidad) throws SQLException {
        String querySql = "UPDATE disponibilidad SET estado = 'Ocupado' WHERE id_disponibilidad = ? AND estado = 'Disponible'";
        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, idDisponibilidad);
            return ps.executeUpdate() > 0;
        }
    }

    // Vuelve a liberar el slot (cancelación o reprogramación de una reserva)
    public boolean liberarDisponibilidad(int idDisponibilidad) {
        boolean respuesta = false;
        String querySql = "UPDATE disponibilidad SET estado = 'Disponible' WHERE id_disponibilidad = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idDisponibilidad);
            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al liberar Disponibilidad: " + e.getMessage());
        }
        return respuesta;
    }

    public Disponibilidad consultarDisponibilidad(int idDisponibilidad) {
        Disponibilidad miDisp = null;
        String querySql = "SELECT id_disponibilidad, fecha, hora, estado FROM disponibilidad WHERE id_disponibilidad = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idDisponibilidad);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miDisp = new Disponibilidad();
                    miDisp.setIdDisponibilidad(rs.getInt("id_disponibilidad"));
                    miDisp.setFecha(Date.valueOf(rs.getString("fecha")));
                    miDisp.setHora(Time.valueOf(rs.getString("hora")));
                    miDisp.setEstado(rs.getString("estado"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar Disponibilidad: " + e.getMessage());
        }
        return miDisp;
    }

    public boolean insertarDisponibilidad(Disponibilidad miDisp) {
        boolean respuesta = false;
        String querySql = "INSERT INTO disponibilidad (fecha, hora, estado) VALUES (?, ?, ?)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            // Igual que en consultarPorFechaYHora: se inserta como texto para que
            // quede guardado tal cual se escribió, sin desplazamientos de huso horario.
            ps.setString(1, miDisp.getFecha().toString());
            ps.setString(2, miDisp.getHora().toString());
            ps.setString(3, miDisp.getEstado());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar Disponibilidad: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean actualizarDisponibilidad(Disponibilidad miDisp) {
        boolean respuesta = false;
        String querySql = "UPDATE disponibilidad SET fecha = ?, hora = ?, estado = ? WHERE id_disponibilidad = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miDisp.getFecha().toString());
            ps.setString(2, miDisp.getHora().toString());
            ps.setString(3, miDisp.getEstado());
            ps.setInt(4, miDisp.getIdDisponibilidad());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar Disponibilidad: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean inactivarDisponibilidad(int idDisponibilidad) {
        boolean respuesta = false;
        String querySql = "UPDATE disponibilidad SET estado = 'Inactivo' WHERE id_disponibilidad = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idDisponibilidad);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al inactivar Disponibilidad: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean activarDisponibilidad(int idDisponibilidad) {
        boolean respuesta = false;
        String querySql = "UPDATE disponibilidad SET estado = 'Activo' WHERE id_disponibilidad = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idDisponibilidad);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al activar Disponibilidad: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean eliminarDisponibilidad(int idDisponibilidad) {
        boolean respuesta = false;
        String querySql = "DELETE FROM disponibilidad WHERE id_disponibilidad = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idDisponibilidad);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar Disponibilidad: " + e.getMessage());
        }
        return respuesta;
    }
}

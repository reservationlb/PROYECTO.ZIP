package Controlador;

import Modelo.TipoDecoracion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoDecoracionDAO {

    private Conexion Sara = new Conexion();

    public TipoDecoracionDAO() {
    }

    public TipoDecoracionDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    // Usado por el asistente de reserva del cliente: solo decoraciones activas
    public List<TipoDecoracion> listar() {
        List<TipoDecoracion> lista = new ArrayList<>();
        String querySql = "SELECT id_tipo_decoracion, nombre_decoracion, descripcion, valor_decoracion, imagen, activo "
                + "FROM tipo_decoracion WHERE activo = 1 ORDER BY nombre_decoracion";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar TipoDecoracion: " + e.getMessage());
        }
        return lista;
    }

    // Usado por el panel de administrador: incluye las ocultas también
    public List<TipoDecoracion> listarTodos() {
        List<TipoDecoracion> lista = new ArrayList<>();
        String querySql = "SELECT id_tipo_decoracion, nombre_decoracion, descripcion, valor_decoracion, imagen, activo "
                + "FROM tipo_decoracion ORDER BY nombre_decoracion";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar todas las TipoDecoracion: " + e.getMessage());
        }
        return lista;
    }

    public TipoDecoracion consultarTipoDecoracion(int idTipoDecoracion) {
        TipoDecoracion miDeco = null;
        String querySql = "SELECT id_tipo_decoracion, nombre_decoracion, descripcion, valor_decoracion, imagen, activo "
                + "FROM tipo_decoracion WHERE id_tipo_decoracion = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idTipoDecoracion);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miDeco = mapear(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar TipoDecoracion: " + e.getMessage());
        }
        return miDeco;
    }

    public boolean insertarTipoDecoracion(TipoDecoracion miDeco) {
        boolean respuesta = false;
        String querySql = "INSERT INTO tipo_decoracion (nombre_decoracion, descripcion, valor_decoracion, imagen, activo) "
                + "VALUES (?, ?, ?, ?, 1)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miDeco.getNombreDecoracion());
            ps.setString(2, miDeco.getDescripcion());
            ps.setBigDecimal(3, miDeco.getValorDecoracion());
            ps.setString(4, miDeco.getImagen());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar TipoDecoracion: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean actualizarTipoDecoracion(TipoDecoracion miDeco) {
        boolean respuesta = false;
        String querySql = "UPDATE tipo_decoracion SET nombre_decoracion = ?, descripcion = ?, valor_decoracion = ?, imagen = ? "
                + "WHERE id_tipo_decoracion = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miDeco.getNombreDecoracion());
            ps.setString(2, miDeco.getDescripcion());
            ps.setBigDecimal(3, miDeco.getValorDecoracion());
            ps.setString(4, miDeco.getImagen());
            ps.setInt(5, miDeco.getIdTipoDecoracion());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar TipoDecoracion: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean eliminarTipoDecoracion(int idTipoDecoracion) {
        boolean respuesta = false;
        String querySql = "DELETE FROM tipo_decoracion WHERE id_tipo_decoracion = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idTipoDecoracion);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar TipoDecoracion: " + e.getMessage());
        }
        return respuesta;
    }

    // Ocultar/mostrar sin borrar (usado por el admin)
    public boolean cambiarActivo(int idTipoDecoracion, boolean activo) {
        boolean respuesta = false;
        String querySql = "UPDATE tipo_decoracion SET activo = ? WHERE id_tipo_decoracion = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, activo ? 1 : 0);
            ps.setInt(2, idTipoDecoracion);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al cambiar estado de TipoDecoracion: " + e.getMessage());
        }
        return respuesta;
    }

    private TipoDecoracion mapear(ResultSet rs) throws SQLException {
        TipoDecoracion td = new TipoDecoracion();
        td.setIdTipoDecoracion(rs.getInt("id_tipo_decoracion"));
        td.setNombreDecoracion(rs.getString("nombre_decoracion"));
        td.setDescripcion(rs.getString("descripcion"));
        td.setValorDecoracion(rs.getBigDecimal("valor_decoracion"));
        td.setImagen(rs.getString("imagen"));
        td.setActivo(rs.getBoolean("activo"));
        return td;
    }
}

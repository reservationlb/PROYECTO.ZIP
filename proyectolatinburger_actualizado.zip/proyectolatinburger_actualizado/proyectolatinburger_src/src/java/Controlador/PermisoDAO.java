package Controlador;

import Modelo.Permiso;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PermisoDAO {

    private Conexion Sara = new Conexion();

    public PermisoDAO() {
    }

    public PermisoDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    public Permiso consultarPermiso(int idPermiso) {
        Permiso miPermiso = null;
        String querySql = "SELECT id_permiso, descripcion FROM permiso WHERE id_permiso = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idPermiso);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miPermiso = new Permiso();
                    miPermiso.setIdPermiso(rs.getInt("id_permiso"));
                    miPermiso.setDescripcion(rs.getString("descripcion"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar Permiso: " + e.getMessage());
        }
        return miPermiso;
    }

    public boolean insertarPermiso(Permiso miPermiso) {
        boolean respuesta = false;
        String querySql = "INSERT INTO permiso (descripcion) VALUES (?)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miPermiso.getDescripcion());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar Permiso: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean actualizarPermiso(Permiso miPermiso) {
        boolean respuesta = false;
        String querySql = "UPDATE permiso SET descripcion = ? WHERE id_permiso = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miPermiso.getDescripcion());
            ps.setInt(2, miPermiso.getIdPermiso());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar Permiso: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean eliminarPermiso(int idPermiso) {
        boolean respuesta = false;
        String querySql = "DELETE FROM permiso WHERE id_permiso = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idPermiso);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar Permiso: " + e.getMessage());
        }
        return respuesta;
    }
}
package Controlador;

import Modelo.TipoEvento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoEventoDAO {

    private Conexion Sara = new Conexion();

    public TipoEventoDAO() {
    }

    public TipoEventoDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    // Usado por el asistente de reserva del cliente: solo tipos de evento activos
    public List<TipoEvento> listar() {
        List<TipoEvento> lista = new ArrayList<>();
        String querySql = "SELECT id_tipo_evento, nombre_evento, descripcion, valor_evento, imagen, activo "
                + "FROM tipo_evento WHERE activo = 1 ORDER BY nombre_evento";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar TipoEvento: " + e.getMessage());
        }
        return lista;
    }

    // Usado por el panel de administrador: incluye los ocultos también
    public List<TipoEvento> listarTodos() {
        List<TipoEvento> lista = new ArrayList<>();
        String querySql = "SELECT id_tipo_evento, nombre_evento, descripcion, valor_evento, imagen, activo "
                + "FROM tipo_evento ORDER BY nombre_evento";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar todos los TipoEvento: " + e.getMessage());
        }
        return lista;
    }

    public TipoEvento consultarTipoEvento(int idTipoEvento) {
        TipoEvento miEvento = null;
        String querySql = "SELECT id_tipo_evento, nombre_evento, descripcion, valor_evento, imagen, activo "
                + "FROM tipo_evento WHERE id_tipo_evento = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idTipoEvento);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miEvento = mapear(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar TipoEvento: " + e.getMessage());
        }
        return miEvento;
    }

    public boolean insertarTipoEvento(TipoEvento miEvento) {
        boolean respuesta = false;
        String querySql = "INSERT INTO tipo_evento (nombre_evento, descripcion, valor_evento, imagen, activo) "
                + "VALUES (?, ?, ?, ?, 1)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miEvento.getNombreEvento());
            ps.setString(2, miEvento.getDescripcion());
            ps.setBigDecimal(3, miEvento.getValorEvento());
            ps.setString(4, miEvento.getImagen());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar TipoEvento: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean actualizarTipoEvento(TipoEvento miEvento) {
        boolean respuesta = false;
        String querySql = "UPDATE tipo_evento SET nombre_evento = ?, descripcion = ?, valor_evento = ?, imagen = ? "
                + "WHERE id_tipo_evento = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miEvento.getNombreEvento());
            ps.setString(2, miEvento.getDescripcion());
            ps.setBigDecimal(3, miEvento.getValorEvento());
            ps.setString(4, miEvento.getImagen());
            ps.setInt(5, miEvento.getIdTipoEvento());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar TipoEvento: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean eliminarTipoEvento(int idTipoEvento) {
        boolean respuesta = false;
        String querySql = "DELETE FROM tipo_evento WHERE id_tipo_evento = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idTipoEvento);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar TipoEvento: " + e.getMessage());
        }
        return respuesta;
    }

    // Ocultar/mostrar sin borrar (usado por el admin en vez de eliminarTipoEvento,
    // para no romper reservas ya existentes que apunten a este tipo de evento)
    public boolean cambiarActivo(int idTipoEvento, boolean activo) {
        boolean respuesta = false;
        String querySql = "UPDATE tipo_evento SET activo = ? WHERE id_tipo_evento = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, activo ? 1 : 0);
            ps.setInt(2, idTipoEvento);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al cambiar estado de TipoEvento: " + e.getMessage());
        }
        return respuesta;
    }

    private TipoEvento mapear(ResultSet rs) throws SQLException {
        TipoEvento te = new TipoEvento();
        te.setIdTipoEvento(rs.getInt("id_tipo_evento"));
        te.setNombreEvento(rs.getString("nombre_evento"));
        te.setDescripcion(rs.getString("descripcion"));
        te.setValorEvento(rs.getBigDecimal("valor_evento"));
        te.setImagen(rs.getString("imagen"));
        te.setActivo(rs.getBoolean("activo"));
        return te;
    }
}

package Controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private String driver = "com.mysql.cj.jdbc.Driver";
    private String user = "root";
    private String password = "";
    private String basedatos = "reservation_lb";
    private String url = "jdbc:mysql://localhost:3306/" + basedatos + "?useTimezone=true&serverTimezone=UTC";

    public Conexion() {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            System.err.println("Error al cargar el driver JDBC: " + e.getMessage());
        }
    }

    public Connection getConn() {
        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            // Antes esto devolvía null en silencio y cada DAO explotaba más
            // adelante con NullPointerException (sin decir por qué). Ahora se
            // relanza como una excepción clara, con el motivo real de MySQL.
            String motivo = "No se pudo conectar a la base de datos '" + basedatos + "' en " + url
                    + " (usuario: " + user + "). Causa: " + e.getMessage();
            System.err.println("Error de conexion con la BD: " + motivo);
            throw new RuntimeException(motivo, e);
        }
    }
}
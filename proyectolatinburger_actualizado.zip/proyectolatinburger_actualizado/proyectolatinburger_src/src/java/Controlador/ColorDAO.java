package Controlador;

import Modelo.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ColorDAO {

    private Conexion Sara = new Conexion();

    public ColorDAO() {
    }

    public ColorDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    // Usado por el asistente de reserva del cliente: solo colores activos
    public List<Color> listar() {
        List<Color> lista = new ArrayList<>();
        String sql = "SELECT id_color, nombre, codigo_hex, imagen, activo FROM color_evento "
                + "WHERE activo = 1 ORDER BY nombre";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar Color: " + e.getMessage());
        }
        return lista;
    }

    // Usado por el panel de administrador: incluye los ocultos también
    public List<Color> listarTodos() {
        List<Color> lista = new ArrayList<>();
        String sql = "SELECT id_color, nombre, codigo_hex, imagen, activo FROM color_evento ORDER BY nombre";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar todos los Color: " + e.getMessage());
        }
        return lista;
    }

    public Color consultar(int idColor) {
        Color c = null;
        String sql = "SELECT id_color, nombre, codigo_hex, imagen, activo FROM color_evento WHERE id_color = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idColor);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    c = mapear(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar Color: " + e.getMessage());
        }
        return c;
    }

    // reserva.color_evento guarda el NOMBRE del color (no un id), así que se
    // busca por nombre para poder mostrar su código hex/imagen en el Panel de Cliente
    public Color consultarPorNombre(String nombre) {
        Color c = null;
        if (nombre == null || nombre.trim().isEmpty()) {
            return null;
        }
        String sql = "SELECT id_color, nombre, codigo_hex, imagen, activo FROM color_evento WHERE nombre = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nombre);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    c = mapear(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar Color por nombre: " + e.getMessage());
        }
        return c;
    }

    public boolean insertar(Color c) {
        boolean respuesta = false;
        String sql = "INSERT INTO color_evento (nombre, codigo_hex, imagen, activo) VALUES (?, ?, ?, 1)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getNombre());
            ps.setString(2, c.getCodigoHex());
            ps.setString(3, c.getImagen());

            respuesta = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar Color: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean actualizar(Color c) {
        boolean respuesta = false;
        String sql = "UPDATE color_evento SET nombre = ?, codigo_hex = ?, imagen = ? WHERE id_color = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getNombre());
            ps.setString(2, c.getCodigoHex());
            ps.setString(3, c.getImagen());
            ps.setInt(4, c.getIdColor());

            respuesta = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar Color: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean cambiarActivo(int idColor, boolean activo) {
        boolean respuesta = false;
        String sql = "UPDATE color_evento SET activo = ? WHERE id_color = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, activo ? 1 : 0);
            ps.setInt(2, idColor);

            respuesta = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al cambiar estado de Color: " + e.getMessage());
        }
        return respuesta;
    }

    private Color mapear(ResultSet rs) throws SQLException {
        Color c = new Color();
        c.setIdColor(rs.getInt("id_color"));
        c.setNombre(rs.getString("nombre"));
        c.setCodigoHex(rs.getString("codigo_hex"));
        c.setImagen(rs.getString("imagen"));
        c.setActivo(rs.getBoolean("activo"));
        return c;
    }
}

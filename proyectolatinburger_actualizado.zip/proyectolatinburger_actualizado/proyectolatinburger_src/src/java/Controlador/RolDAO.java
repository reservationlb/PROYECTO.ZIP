package Controlador;

import Modelo.Rol;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RolDAO {

    private Conexion Sara = new Conexion();

    public RolDAO() {
    }

    public RolDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    public List<Rol> listar() {
        List<Rol> lista = new ArrayList<>();
        String querySql = "SELECT id_rol, descripcion, estado FROM rol WHERE estado = 'Activo' ORDER BY descripcion";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Rol r = new Rol();
                r.setIdRol(rs.getInt("id_rol"));
                r.setDescripcion(rs.getString("descripcion"));
                r.setEstado(rs.getString("estado"));
                lista.add(r);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar Rol: " + e.getMessage());
        }
        return lista;
    }

    public Rol consultarRol(int idRol) {
        Rol miRol = null;
        String querySql = "SELECT id_rol, descripcion, estado FROM rol WHERE id_rol = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idRol);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miRol = new Rol();
                    miRol.setIdRol(rs.getInt("id_rol"));
                    miRol.setDescripcion(rs.getString("descripcion"));
                    miRol.setEstado(rs.getString("estado"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar Rol: " + e.getMessage());
        }
        return miRol;
    }

    public boolean insertarRol(Rol miRol) {
        boolean respuesta = false;
        String querySql = "INSERT INTO rol (descripcion, estado) VALUES (?, ?)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miRol.getDescripcion());
            ps.setString(2, miRol.getEstado());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar Rol: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean actualizarRol(Rol miRol) {
        boolean respuesta = false;
        String querySql = "UPDATE rol SET descripcion = ?, estado = ? WHERE id_rol = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miRol.getDescripcion());
            ps.setString(2, miRol.getEstado());
            ps.setInt(3, miRol.getIdRol());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar Rol: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean inactivarRol(int idRol) {
        boolean respuesta = false;
        String querySql = "UPDATE rol SET estado = 'Inactivo' WHERE id_rol = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idRol);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al inactivar Rol: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean activarRol(int idRol) {
        boolean respuesta = false;
        String querySql = "UPDATE rol SET estado = 'Activo' WHERE id_rol = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idRol);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al activar Rol: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean eliminarRol(int idRol) {
        boolean respuesta = false;
        String querySql = "DELETE FROM rol WHERE id_rol = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idRol);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar Rol: " + e.getMessage());
        }
        return respuesta;
    }
}
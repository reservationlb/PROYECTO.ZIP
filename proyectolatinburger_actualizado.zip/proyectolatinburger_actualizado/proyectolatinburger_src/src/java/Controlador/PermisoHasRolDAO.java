package Controlador;

import Modelo.PermisoHasRol;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PermisoHasRolDAO {

    private Conexion Sara = new Conexion();

    public PermisoHasRolDAO() {
    }

    public PermisoHasRolDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    public PermisoHasRol consultarPermisoHasRol(int permisoId, int rolId) {
        PermisoHasRol miRelacion = null;
        String querySql = "SELECT permiso_id_permiso, rol_id_rol FROM permiso_has_rol WHERE permiso_id_permiso = ? AND rol_id_rol = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, permisoId);
            ps.setInt(2, rolId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miRelacion = new PermisoHasRol();
                    miRelacion.setPermisoIdPermiso(rs.getInt("permiso_id_permiso"));
                    miRelacion.setRolIdRol(rs.getInt("rol_id_rol"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar PermisoHasRol: " + e.getMessage());
        }
        return miRelacion;
    }

    public boolean insertarPermisoHasRol(PermisoHasRol miRelacion) {
        boolean respuesta = false;
        String querySql = "INSERT INTO permiso_has_rol (permiso_id_permiso, rol_id_rol) VALUES (?, ?)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miRelacion.getPermisoIdPermiso());
            ps.setInt(2, miRelacion.getRolIdRol());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar PermisoHasRol: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean eliminarPermisoHasRol(int permisoId, int rolId) {
        boolean respuesta = false;
        String querySql = "DELETE FROM permiso_has_rol WHERE permiso_id_permiso = ? AND rol_id_rol = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, permisoId);
            ps.setInt(2, rolId);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar PermisoHasRol: " + e.getMessage());
        }
        return respuesta;
    }
}
package Controlador;

import Modelo.ReservaProducto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ReservaProductoDAO {

    private Conexion Sara = new Conexion();

    public ReservaProductoDAO() {
    }

    public ReservaProductoDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    // Inserta un ítem del pedido dentro de una transacción ya abierta
    // (ver ReservaDAO.insertarReservaCompleta)
    public boolean insertar(Connection conn, ReservaProducto item) throws SQLException {
        String sql = "INSERT INTO reserva_producto (reserva_id_reserva, producto_id_producto, cantidad, precio_unitario) "
                + "VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, item.getReservaIdReserva());
            ps.setInt(2, item.getProductoIdProducto());
            ps.setInt(3, item.getCantidad());
            ps.setBigDecimal(4, item.getPrecioUnitario());
            return ps.executeUpdate() > 0;
        }
    }

    public List<ReservaProducto> listarPorReserva(int idReserva) {
        List<ReservaProducto> lista = new ArrayList<>();
        String sql = "SELECT rp.id_reserva_producto, rp.reserva_id_reserva, rp.producto_id_producto, "
                + "rp.cantidad, rp.precio_unitario, p.nombre AS nombre_producto "
                + "FROM reserva_producto rp INNER JOIN Producto p ON rp.producto_id_producto = p.id_producto "
                + "WHERE rp.reserva_id_reserva = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idReserva);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ReservaProducto item = new ReservaProducto();
                    item.setIdReservaProducto(rs.getInt("id_reserva_producto"));
                    item.setReservaIdReserva(rs.getInt("reserva_id_reserva"));
                    item.setProductoIdProducto(rs.getInt("producto_id_producto"));
                    item.setCantidad(rs.getInt("cantidad"));
                    item.setPrecioUnitario(rs.getBigDecimal("precio_unitario"));
                    item.setNombreProducto(rs.getString("nombre_producto"));
                    lista.add(item);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar ReservaProducto: " + e.getMessage());
        }
        return lista;
    }

    // Platos más pedidos (usado en Reportes del administrador)
    public List<java.util.Map<String, String>> popularidadPlatos(int limite) {
        List<java.util.Map<String, String>> lista = new ArrayList<>();
        String sql = "SELECT p.nombre, SUM(rp.cantidad) AS unidades, SUM(rp.cantidad * rp.precio_unitario) AS ingresos "
                + "FROM reserva_producto rp INNER JOIN Producto p ON rp.producto_id_producto = p.id_producto "
                + "GROUP BY p.id_producto, p.nombre ORDER BY unidades DESC LIMIT ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, limite);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    java.util.Map<String, String> fila = new java.util.HashMap<>();
                    fila.put("nombre", rs.getString("nombre"));
                    fila.put("unidades", String.valueOf(rs.getInt("unidades")));
                    fila.put("ingresos", String.format("%,.0f", rs.getDouble("ingresos")));
                    lista.add(fila);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al calcular popularidad de platos: " + e.getMessage());
        }
        return lista;
    }
}

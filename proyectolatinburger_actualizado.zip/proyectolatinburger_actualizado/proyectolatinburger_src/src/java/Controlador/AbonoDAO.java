package Controlador;

import Modelo.Abono;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AbonoDAO {

    private Conexion Sara = new Conexion();

    public AbonoDAO() {
    }

    public AbonoDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    // Inserta el abono dentro de una transacción ya abierta
    // (ver ReservaDAO.insertarReservaCompleta)
    public boolean insertar(Connection conn, Abono abono) throws SQLException {
        String sql = "INSERT INTO abono (reserva_id_reserva, medio_pago, valor_abono, estado) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, abono.getReservaIdReserva());
            ps.setString(2, abono.getMedioPago());
            ps.setBigDecimal(3, abono.getValorAbono());
            ps.setString(4, abono.getEstado() != null ? abono.getEstado() : "Registrado");
            return ps.executeUpdate() > 0;
        }
    }

    public List<Abono> listarPorReserva(int idReserva) {
        List<Abono> lista = new ArrayList<>();
        String sql = "SELECT id_abono, reserva_id_reserva, medio_pago, valor_abono, fecha_abono, estado "
                + "FROM abono WHERE reserva_id_reserva = ? ORDER BY fecha_abono DESC";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idReserva);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Abono a = new Abono();
                    a.setIdAbono(rs.getInt("id_abono"));
                    a.setReservaIdReserva(rs.getInt("reserva_id_reserva"));
                    a.setMedioPago(rs.getString("medio_pago"));
                    a.setValorAbono(rs.getBigDecimal("valor_abono"));
                    a.setFechaAbono(rs.getTimestamp("fecha_abono"));
                    a.setEstado(rs.getString("estado"));
                    lista.add(a);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar Abono: " + e.getMessage());
        }
        return lista;
    }

    // Listado completo para el panel de administrador (ver todos los abonos hechos)
    public List<java.util.Map<String, String>> listarTodos() {
        List<java.util.Map<String, String>> lista = new ArrayList<>();
        String sql = "SELECT a.id_abono, a.medio_pago, a.valor_abono, a.fecha_abono, a.estado, "
                + "r.id_reserva, r.fecha AS fecha_evento, u.nombre, u.apellido "
                + "FROM abono a "
                + "INNER JOIN reserva r ON a.reserva_id_reserva = r.id_reserva "
                + "INNER JOIN usuario u ON r.usuario_id_usuario = u.id_usuario "
                + "ORDER BY a.fecha_abono DESC";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                java.util.Map<String, String> fila = new java.util.HashMap<>();
                fila.put("id_abono", String.valueOf(rs.getInt("id_abono")));
                fila.put("medio_pago", rs.getString("medio_pago"));
                fila.put("valor_abono", String.format("%,.0f", rs.getDouble("valor_abono")));
                fila.put("fecha_abono", String.valueOf(rs.getTimestamp("fecha_abono")));
                fila.put("estado", rs.getString("estado"));
                fila.put("id_reserva", String.valueOf(rs.getInt("id_reserva")));
                fila.put("fecha_evento", String.valueOf(rs.getDate("fecha_evento")));
                fila.put("cliente", rs.getString("nombre") + " " + rs.getString("apellido"));
                lista.add(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar todos los abonos: " + e.getMessage());
        }
        return lista;
    }

    // Suma de abonos registrados en el mes actual (Dashboard / Reportes admin)
    public double sumarAbonosMes(int anio, int mes) {
        double total = 0;
        String sql = "SELECT COALESCE(SUM(valor_abono), 0) AS total FROM abono "
                + "WHERE YEAR(fecha_abono) = ? AND MONTH(fecha_abono) = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, anio);
            ps.setInt(2, mes);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    total = rs.getDouble("total");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al sumar abonos del mes: " + e.getMessage());
        }
        return total;
    }
}

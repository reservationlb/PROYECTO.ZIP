package Controlador;

import Modelo.TipoMenu;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TipoMenuDAO {

    private Conexion Sara = new Conexion();

    public TipoMenuDAO() {
    }

    public TipoMenuDAO(Conexion conexion) {
        this.Sara = conexion;
    }

    // La reserva exige un tipo_menu_id_tipo_menu (NOT NULL) aunque el cliente
    // arme su pedido a la carta (tabla reserva_producto). Se usa el catálogo
    // "Menú personalizado" ya existente como valor por defecto para ese caso,
    // sin duplicar información ni tocar la estructura de la tabla reserva.
    public TipoMenu buscarPersonalizado() {
        TipoMenu miMenu = null;
        String querySql = "SELECT id_tipo_menu, nombre_menu, descripcion_menu, valor_menu FROM tipo_menu "
                + "WHERE nombre_menu = 'Menú personalizado' LIMIT 1";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                miMenu = new TipoMenu();
                miMenu.setIdTipoMenu(rs.getInt("id_tipo_menu"));
                miMenu.setNombreMenu(rs.getString("nombre_menu"));
                miMenu.setDescripcionMenu(rs.getString("descripcion_menu"));
                miMenu.setValorMenu(rs.getBigDecimal("valor_menu"));
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar TipoMenu personalizado: " + e.getMessage());
        }
        if (miMenu == null) {
            // Reserva de seguridad: si no existe ese registro, usa el primero del catálogo.
            miMenu = consultarTipoMenu(1);
        }
        return miMenu;
    }

    public TipoMenu consultarTipoMenu(int idTipoMenu) {
        TipoMenu miMenu = null;
        String querySql = "SELECT id_tipo_menu, nombre_menu, descripcion_menu, valor_menu FROM tipo_menu WHERE id_tipo_menu = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idTipoMenu);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miMenu = new TipoMenu();
                    miMenu.setIdTipoMenu(rs.getInt("id_tipo_menu"));
                    miMenu.setNombreMenu(rs.getString("nombre_menu"));
                    miMenu.setDescripcionMenu(rs.getString("descripcion_menu"));
                    miMenu.setValorMenu(rs.getBigDecimal("valor_menu"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar TipoMenu: " + e.getMessage());
        }
        return miMenu;
    }

    public boolean insertarTipoMenu(TipoMenu miMenu) {
        boolean respuesta = false;
        String querySql = "INSERT INTO tipo_menu (nombre_menu, descripcion_menu, valor_menu) VALUES (?, ?, ?)";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miMenu.getNombreMenu());
            ps.setString(2, miMenu.getDescripcionMenu());
            ps.setBigDecimal(3, miMenu.getValorMenu());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar TipoMenu: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean actualizarTipoMenu(TipoMenu miMenu) {
        boolean respuesta = false;
        String querySql = "UPDATE tipo_menu SET nombre_menu = ?, descripcion_menu = ?, valor_menu = ? WHERE id_tipo_menu = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miMenu.getNombreMenu());
            ps.setString(2, miMenu.getDescripcionMenu());
            ps.setBigDecimal(3, miMenu.getValorMenu());
            ps.setInt(4, miMenu.getIdTipoMenu());

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar TipoMenu: " + e.getMessage());
        }
        return respuesta;
    }

    public boolean eliminarTipoMenu(int idTipoMenu) {
        boolean respuesta = false;
        String querySql = "DELETE FROM tipo_menu WHERE id_tipo_menu = ?";

        try (Connection conn = Sara.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idTipoMenu);

            if (ps.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar TipoMenu: " + e.getMessage());
        }
        return respuesta;
    }
}
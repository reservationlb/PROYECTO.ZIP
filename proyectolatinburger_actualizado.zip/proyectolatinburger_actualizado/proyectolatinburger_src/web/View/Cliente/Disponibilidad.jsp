<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%
    String nombreUsuario = (String) session.getAttribute("nombreUsuario");
    if (nombreUsuario == null) {
        nombreUsuario = (String) session.getAttribute("nombreCliente");
    }
    List<Map<String, String>> listaProximas = (List<Map<String, String>>) request.getAttribute("proximasFechas");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Disponibilidad</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/Disponibilidad.css">
</head>
<body>

    <header class="nav-cliente">
        <a href="${pageContext.request.contextPath}/View/Cliente/Inicio.jsp" class="logo">Reservation <span>L.B</span></a>
        <div class="nav-actions">
            <span class="btn-nav-user">
                Cliente (<%= nombreUsuario != null ? nombreUsuario : "Usuario" %>)
            </span>
            <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-primary btn-nav-salir">Salir</a>
        </div>
    </header>

    <main class="dispo-container">
        <h2 class="dispo-title">Disponibilidad</h2>

        <form id="formDisponibilidad" action="${pageContext.request.contextPath}/DisponibilidadServlet" method="POST">
            <!-- Campo oculto para diferenciar si se consulta o se avanza al menú -->
            <input type="hidden" name="accion" id="accionInput" value="consultar">

            <div class="form-group">
                <label for="fecha">Fecha</label>
                <div class="input-icon-wrapper">
                    <span>📅</span>
                    <input type="date" id="fecha" name="fecha" class="input-control" required>
                </div>
            </div>

            <div class="form-group">
                <label for="hora">Hora</label>
                <div class="input-icon-wrapper">
                    <span>🕒</span>
                    <input type="time" id="hora" name="hora" class="input-control" required>
                </div>
            </div>

            <button type="submit" class="btn-consultar" onclick="document.getElementById('accionInput').value='consultar';">Consultar disponibilidad</button>
        </form>

        <!-- Bloque de resultados dinámicos -->
        <div class="proximas-box">
            <h4>Próximas Fechas Disponibles (Haz clic en una para seleccionar)</h4>
            <%
                String mensajeErrorBD = (String) request.getAttribute("mensajeErrorBD");
                if (mensajeErrorBD != null) {
            %>
                <p style="color: #b30000; font-weight: bold;"><%= mensajeErrorBD %></p>
            <%
                }
                if (listaProximas != null && !listaProximas.isEmpty()) {
                    for (Map<String, String> item : listaProximas) {
                        String f = item.get("fecha");
                        String h = item.get("hora");
            %>
                <div class="item-disponibilidad item-selectable" onclick="seleccionarFechaHora('<%= f %>', '<%= h %>')">
                    <span>📅</span>
                    <div class="item-text">
                        <strong>Fecha: <%= f %></strong><br>
                        <small class="item-info">Hora: <%= h %> hrs | Estado: <%= item.get("estado") %></small>
                    </div>
                    <button type="button" class="btn-select-action">Elegir</button>
                </div>
            <%
                    }
                } else if (mensajeErrorBD == null) {
            %>
                <p class="item-info">No se encontraron horarios disponibles para la fecha seleccionada.</p>
            <%
                }
            %>
        </div>

        <div class="dispo-actions">
            <a href="${pageContext.request.contextPath}/View/Cliente/Inicio.jsp" class="btn-primary btn-nav-volver">← Volver al Inicio</a>
            <a href="javascript:void(0);" onclick="continuarASiguiente()" class="btn-gold">Siguiente →</a>
        </div>
    </main>

    <script>
        function seleccionarFechaHora(fecha, hora) {
            var horaLimpia = hora.substring(0, 5);

            document.getElementById('fecha').value = fecha;
            document.getElementById('hora').value = horaLimpia;

            var items = document.querySelectorAll('.item-selectable');
            items.forEach(function(el) {
                el.classList.remove('selected');
            });
            event.currentTarget.classList.add('selected');
        }

        function continuarASiguiente() {
            var fecha = document.getElementById('fecha').value;
            var hora = document.getElementById('hora').value;

            if (!fecha || !hora) {
                alert('Por favor selecciona o ingresa una fecha y hora antes de continuar.');
                return;
            }

            // Cambiar la acción a 'siguiente' para que el Servlet guarde y redirija al menú
            document.getElementById('accionInput').value = 'siguiente';
            document.getElementById('formDisponibilidad').submit();
        }
    </script>

</body>
</html>
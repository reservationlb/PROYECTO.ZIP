<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ page import="Modelo.Producto" %>
<%@ page import="Modelo.Categoria" %>
<%@ page import="Controlador.ProductoDAO" %>
<%@ page import="Controlador.CategoriaDAO" %>
<%
    // Instanciar los DAO directamente en el JSP para asegurar la carga de la BD
    ProductoDAO prodDAO = new ProductoDAO();
    CategoriaDAO catDAO = new CategoriaDAO();

    List<Producto> listaProductos = (List<Producto>) request.getAttribute("listaProductos");
    if (listaProductos == null || listaProductos.isEmpty()) {
        listaProductos = prodDAO.listar();
    }

    List<Categoria> listaCategorias = (List<Categoria>) request.getAttribute("listaCategorias");
    if (listaCategorias == null || listaCategorias.isEmpty()) {
        listaCategorias = catDAO.listar();
    }

    String ratingReal = (String) request.getAttribute("ratingReal");
    String totalResenas = (String) request.getAttribute("totalResenas");
    List<Map<String, String>> listaResenas = (List<Map<String, String>>) request.getAttribute("listaResenas");

    if (ratingReal == null || ratingReal.trim().isEmpty()) {
        ratingReal = "4.8";
    }
    if (totalResenas == null || totalResenas.trim().isEmpty()) {
        totalResenas = "150";
    }
%>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reservation L.B. | Latin Burger</title>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,400&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

        <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/Inicio.css?v=5.0">
    </head>
    <body>

        <!-- Navegación -->
        <nav class="nav-cliente">
            <a href="#" class="logo">Reservation <span>L.B.</span></a>
            <ul class="nav-links">
                <li><a href="#historia">NOSOTROS</a></li>
                <li><a href="#menu">MENÚ</a></li>
                <li><a href="#ubicacion">UBICACIÓN</a></li>
                <li><a href="#reseñas">RESEÑAS</a></li>
                <li><a href="#pagos">PAGOS</a></li>
            </ul>
            <div class="nav-actions">
                <a href="${pageContext.request.contextPath}/Reservar" class="btn-primary">RESERVAR</a>
            </div>
        </nav>

        <!-- Hero Section -->
        <header class="hero-section">
            <div class="hero-text">
                <p class="sub-tag">✦ LATIN BURGER & RESERVATION L.B.</p>
                <h1>El sabor <br><em>de nuestra familia</em></h1>
                <p class="hero-desc">Sabor artesanal, ingredientes seleccionados y la mejor experiencia gastronómica. Realiza tu reserva de eventos en segundos.</p>

                <div class="hero-buttons">
                    <a href="#menu" class="btn-gold">VER MENÚ COMPLETO</a>
                    <a href="https://maps.app.goo.gl/P9gW9PcMWRAU5SfP8" target="_blank" rel="noopener noreferrer" class="btn-outline-light">📍 CÓMO LLEGAR</a>
                </div>
            </div>

            <div class="hero-image-container">
                <div class="image-placeholder">
                    <span class="burger-icon">🍔</span>
                </div>
            </div>
        </header>

        <!-- Historia & Horarios -->
        <section id="historia" class="info-section">
            <div class="info-text">
                <p class="sub-tag-dark">— SOBRE NOSOTROS</p>
                <h2>Tradición, pasión y herencia <br>en cada plato</h2>
                <p>En Latin Burger nos apasiona ofrecer preparaciones llenas de sabor y frescura. Reservation L.B. es nuestro sistema oficial para que gestiones tus reservas de tus eventos mas importantes de forma rápida.</p>

                <div class="horarios-card">
                    <h3>🕒 HORARIOS DE ATENCIÓN</h3>
                    <ul>
                        <li><span>Lunes a Domingo</span> <strong>11:00 am - 10:00 pm</strong></li>
                    </ul>
                </div>
            </div>

            <div class="cards-grid">
                <div class="feature-card">
                    <div class="feature-icon">🥩</div>
                    <h3>Ingredientes 100% Frescos</h3>
                    <p>Carnes de primera calidad y vegetales seleccionados diariamente.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">👨‍🍳</div>
                    <h3>Recetas Originales</h3>
                    <p>Salsas artesanales y combinaciones únicas de la casa.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🍔</div>
                    <h3>Servicio Ágil</h3>
                    <p>Atención directa y entregas a tiempo para tu conveniencia.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">⭐</div>
                    <h3>Calificación Excelente</h3>
                    <p>Respaldo total con <%= ratingReal%> estrellas en Google Maps.</p>
                </div>
            </div>
        </section>

        <!-- Menú Dinámico -->
        <section id="menu" class="menu-section">
            <p class="sub-tag-dark">— NUESTRO MENÚ</p>
            <h2>Favoritos de Latin Burger</h2>

            <!-- Categorías dinámicas -->
            <div class="menu-categories">
                <button class="cat-btn active" data-categoria="todas">TODOS</button>
                <%
                    if (listaCategorias != null && !listaCategorias.isEmpty()) {
                        for (Categoria cat : listaCategorias) {
                %>
                <button class="cat-btn" data-categoria="<%= cat.getIdCategoria()%>"><%= cat.getNombre().toUpperCase()%></button>
                <%
                        }
                    }
                %>
            </div>

            <!-- Tarjetas dinámicas de productos -->
            <div class="platos-grid">
                <%
                    if (listaProductos != null && !listaProductos.isEmpty()) {
                        for (Producto prod : listaProductos) {
                %>
                <div class="plato-card" data-categoria="<%= prod.getIdCategoria()%>">
                    <div class="plato-img-box">
                        <% if (prod.getImagen() != null && !prod.getImagen().trim().isEmpty()) {%>
                        <img src="${pageContext.request.contextPath}/<%= prod.getImagen()%>" alt="<%= prod.getNombre()%>" style="width: 100%; height: 100%; object-fit: cover; border-radius: 8px;">
                        <% } else { %>
                        🍔
                        <% }%>
                    </div>
                    <h3><%= prod.getNombre()%></h3>
                    <p><%= prod.getDescripcion() != null ? prod.getDescripcion() : "Delicioso producto de la casa."%></p>
                    <div class="plato-footer">
                        <span class="precio">$<%= String.format("%,.0f", prod.getPrecio())%></span>
                        <a href="${pageContext.request.contextPath}/Reservar" class="btn-add">+</a>
                    </div>
                </div>
                <%
                    }
                } else {
                %>
                <div class="no-datos">
                    <p>No hay productos disponibles en el menú por el momento.</p>
                </div>
                <%
                    }
                %>
            </div>

            <!-- Ubicación -->
            <section id="ubicacion" class="ubicacion-section">
                <p class="sub-tag">ENCUÉNTRANOS</p>
                <h2 class="titulo-ubicacion">Visítanos en Latin Burger</h2>

                <div class="ubicacion-grid">
                    <div>
                        <div class="info-box">
                            <h3>📍 Dirección</h3>
                            <p>Latin Burger — Soacha, Cundinamarca</p>
                        </div>

                        <div class="info-box">
                            <h3>📞 Teléfono y WhatsApp</h3>
                            <p>+57 300 268 4841</p>
                        </div>

                        <div class="info-box">
                            <h3>🗺️ Ubicación GPS</h3>
                            <p>Accede directamente a la ruta navegable oficial en Google Maps.</p>
                        </div>

                        <div>
                            <h3 class="subtitulo-modalidades">Modalidades de Atención</h3>
                            <div class="zonas-cobertura">
                                <span class="zona-tag">Consumo en Local</span>
                            </div>
                        </div>
                    </div>

                    <div class="mapa-simulado">
                        <div class="mapa-icon">📍</div>
                        <h3 class="titulo-mapa">Latin Burger Bogotá</h3>
                        <p class="desc-mapa">Abre el mapa e inicia tu ruta de llegada</p>
                        <a href="https://maps.app.goo.gl/P9gW9PcMWRAU5SfP8" target="_blank" rel="noopener noreferrer" class="btn-gold btn-mapa">ABRIR EN GOOGLE MAPS ➔</a>
                    </div>
                </div>
            </section>

            <!-- Reseñas -->
            <section id="reseñas" class="reseñas-section">
                <p class="sub-tag-dark">— OPINIONES REALES</p>
                <h2>Reseñas en Google Maps</h2>

                <div class="score-box">
                    <div class="score-number"><%= ratingReal%></div>
                    <div class="stars">★★★★★</div>
                    <div class="google-badge">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/c/c1/Google_%22G%22_logo.svg" alt="Google" width="18" height="18">
                        <span>Basado en <%= totalResenas%> opiniones en Google Maps</span>
                    </div>
                </div>

                <div class="reseñas-grid">
                    <%
                        boolean hayResenas = (listaResenas != null && !listaResenas.isEmpty());
                        if (hayResenas) {
                            int limite = Math.min(listaResenas.size(), 3);
                            for (int i = 0; i < limite; i++) {
                                Map<String, String> rev = listaResenas.get(i);
                                String autor = rev.get("author");
                                String texto = rev.get("text");
                                String tiempo = rev.get("time");
                                String inicial = (autor != null && autor.length() > 0) ? autor.substring(0, 1).toUpperCase() : "G";
                    %>
                    <div class="reseña-card">
                        <div class="reseña-header">
                            <div class="stars estrellas-pequenas">★★★★★</div>
                            <span class="tiempo-resena"><%= tiempo%></span>
                        </div>
                        <p class="reseña-texto">"<%= texto%>"</p>
                        <div class="cliente-info">
                            <div class="cliente-avatar"><%= inicial%></div>
                            <div class="cliente-detalles">
                                <h4><%= autor%></h4>
                                <span>Reseña oficial de Google</span>
                            </div>
                        </div>
                    </div>
                    <%
                        }
                    } else {
                    %>
                    <div class="reseña-card">
                        <div class="reseña-header">
                            <div class="stars estrellas-pequenas">★★★★★</div>
                            <span class="tiempo-resena">Hace una semana</span>
                        </div>
                        <p class="reseña-texto">"Excelente atención y las hamburguesas son increíbles. Muy recomendado Latin Burger."</p>
                        <div class="cliente-info">
                            <div class="cliente-avatar">L</div>
                            <div class="cliente-detalles">
                                <h4>Cliente de Latin Burger</h4>
                                <span>Opinión Verificada</span>
                            </div>
                        </div>
                    </div>
                    <%
                        }
                    %>
                </div>

                <a href="https://maps.app.goo.gl/P9gW9PcMWRAU5SfP8" target="_blank" rel="noopener noreferrer" class="btn-google-reviews">
                    VER TODAS LAS RESEÑAS EN GOOGLE MAPS ➔
                </a>
            </section>

            <!-- Métodos de Pago -->
            <section id="pagos" class="pagos-section">
                <p class="sub-tag-dark">— PAGOS SEGUROS</p>
                <h2>Paga como prefieras</h2>

                <div class="metodos-grid">
                    <div class="metodo-card">
                        <div class="metodo-icon">📱</div>
                        <h3>Nequi</h3>
                        <p>Transferencia directa o QR.</p>
                    </div>
                    <div class="metodo-card">
                        <div class="metodo-icon">📲</div>
                        <h3>Daviplata</h3>
                        <p>Pagos rápidos desde la app.</p>
                    </div>
                    <div class="metodo-card">
                        <div class="metodo-icon">💳</div>
                        <h3>Tarjeta Débito/Crédito</h3>
                        <p>Visa, Mastercard y Amex.</p>
                    </div>
                    <div class="metodo-card">
                        <div class="metodo-icon">💵</div>
                        <h3>Efectivo</h3>
                        <p>Pago en punto físico.</p>
                    </div>
                </div>
            </section>

            <!-- Footer -->
            <footer class="footer">
                <div>
                    <a href="#" class="logo logo-footer">Reservation <span>L.B.</span></a>
                    <p class="footer-desc">Latin Burger — Sistema de reservas de eventos en línea.</p>
                </div>
                <div>
                    <h4>Menú</h4>
                    <p>Hamburguesas</p>
                    <p>Entradas y Especiales</p>
                    <p>Bebidas</p>
                </div>
                <div>
                    <h4>Contacto Directo</h4>
                    <p>Soacha, Cundinamarca</p>
                    <p>Tel / WhatsApp: +57 300 268 4841</p>
                </div>
            </footer>

            <!-- Script de filtrado interactivo -->
            <script>
                document.addEventListener("DOMContentLoaded", function () {
                    const botones = document.querySelectorAll(".cat-btn");
                    const productos = document.querySelectorAll(".plato-card");

                    botones.forEach(boton => {
                        boton.addEventListener("click", function () {
                            botones.forEach(b => b.classList.remove("active"));
                            this.classList.add("active");

                            const idCategoria = this.getAttribute("data-categoria");

                            productos.forEach(producto => {
                                const categoriaProducto = producto.getAttribute("data-categoria");

                                if (idCategoria === "todas" || categoriaProducto === idCategoria) {
                                    producto.style.display = "flex";
                                } else {
                                    producto.style.display = "none";
                                }
                            });
                        });
                    });
                });
            </script>

    </body>
</html>
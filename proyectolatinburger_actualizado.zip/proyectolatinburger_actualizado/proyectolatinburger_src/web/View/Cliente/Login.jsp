<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Latin Burger</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/Login.css?v=1.1">
</head>
<body>

    <div class="login-container">
        <h2>Iniciar Sesión</h2>
        <p class="login-subtitle">Ingresa tus datos para gestionar tus pedidos y reservas fácilmente.</p>

        <%-- Mensajes de feedback --%>
        <% if (request.getParameter("registro") != null && request.getParameter("registro").equals("exito")) { %>
            <div class="alert-success">¡Registro exitoso! Por favor inicia sesión.</div>
        <% } %>

        <% if (request.getAttribute("error") != null) { %>
            <div class="alert-error"><%= request.getAttribute("error") %></div>
        <% } %>

        <form action="${pageContext.request.contextPath}/LoginServlet" method="POST">
            <div class="form-group">
                <label for="numDocumento">Número de Documento</label>
                <input type="text" id="numDocumento" name="numDocumento" placeholder="Ej: 1012345678" required autocomplete="username">
            </div>

            <div class="form-group">
                <label for="contrasena">Contraseña</label>
                <input type="password" id="contrasena" name="contrasena" placeholder="••••••••" required autocomplete="current-password">
            </div>

            <button type="submit">Ingresar</button>
        </form>

        <p>¿No tienes una cuenta? <a href="${pageContext.request.contextPath}/View/Cliente/Registro.jsp">Regístrate aquí</a></p>
    </div>

</body>
</html>
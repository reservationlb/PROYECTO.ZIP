<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.Color" %>
<%
    String nombreUsuario = (String) session.getAttribute("nombreCliente");
    String error = (String) request.getAttribute("error");
    List<Color> listaColores = (List<Color>) request.getAttribute("listaColores");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Color del Evento</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/Wizard.css">
</head>
<body>

    <header class="nav-cliente">
        <a href="${pageContext.request.contextPath}/View/Cliente/Inicio.jsp" class="logo">Reservation <span>L.B</span></a>
        <div class="nav-actions">
            <span class="btn-nav-user">Cliente (<%= nombreUsuario != null ? nombreUsuario : "Usuario" %>)</span>
            <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-primary btn-nav-salir">Salir</a>
        </div>
    </header>

    <div class="wizard-progreso">
        <span>1. Disponibilidad</span>
        <span>2. Tipo de Evento</span>
        <span>3. Decoración</span>
        <span class="activo">4. Color</span>
        <span>5. Menú</span>
        <span>6. Resumen</span>
    </div>

    <main class="wizard-container">
        <h2 class="wizard-title">Color del evento</h2>
        <p class="wizard-subtitle">Elige la paleta principal y cuéntanos cualquier detalle adicional.</p>

        <% if (error != null) { %>
            <div class="wizard-error"><%= error %></div>
        <% } %>

        <form action="${pageContext.request.contextPath}/ColorServlet" method="POST">
            <input type="hidden" name="color" id="colorInput" value="">

            <div class="color-grid">
                <% if (listaColores != null) {
                    for (Color c : listaColores) { %>
                <div class="color-swatch" data-color="<%= c.getNombre() %>" onclick="seleccionar(this)">
                    <% if (c.getImagen() != null && !c.getImagen().trim().isEmpty()) { %>
                    <img src="${pageContext.request.contextPath}/<%= c.getImagen() %>" alt="<%= c.getNombre() %>" style="width:38px;height:38px;border-radius:50%;margin:0 auto 0.5rem;display:block;object-fit:cover;">
                    <% } else { %>
                    <div class="color-circulo" style="background:<%= c.getCodigoHex() %>;"></div>
                    <% } %>
                    <span><%= c.getNombre() %></span>
                </div>
                <% }
                } %>
            </div>

            <div class="form-group">
                <label for="comentarios">Descripción adicional (opcional)</label>
                <textarea class="input-control" id="comentarios" name="comentarios" placeholder="Ej: preferimos globos metálicos, alergias, detalles especiales..."></textarea>
            </div>

            <div class="wizard-actions">
                <a href="${pageContext.request.contextPath}/DecoracionServlet" class="btn-secundario">← Volver</a>
                <button type="submit" class="btn-gold">Siguiente →</button>
            </div>
        </form>
    </main>

    <script>
        function seleccionar(card) {
            document.querySelectorAll('.color-swatch').forEach(function (c) {
                c.classList.remove('seleccionada');
            });
            card.classList.add('seleccionada');
            document.getElementById('colorInput').value = card.getAttribute('data-color');
        }
    </script>

</body>
</html>

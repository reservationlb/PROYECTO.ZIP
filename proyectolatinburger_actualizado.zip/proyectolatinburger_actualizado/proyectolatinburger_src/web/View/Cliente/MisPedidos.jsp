<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>

<%
    String nombreUsuario = (String) session.getAttribute("nombreUsuario");
    if (nombreUsuario == null) {
        nombreUsuario = (String) session.getAttribute("nombreCliente");
    }
    if (nombreUsuario == null) {
        nombreUsuario = (String) session.getAttribute("usuario");
    }

    List<Map<String, String>> listaPedidos = (List<Map<String, String>>) request.getAttribute("listaPedidos");
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Mis Pedidos</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    
    <!-- Aquí puedes colocar o ajustar el enlace a tu CSS -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/MisPedidos.css">
</head>
<body>

<header class="nav-cliente">
    <a href="${pageContext.request.contextPath}/View/Cliente/Inicio.jsp" class="logo">
        Reservation <span>L.B.</span>
    </a>
    <div class="nav-actions">
        <span class="btn-nav-user">
            Cliente (<%= nombreUsuario != null ? nombreUsuario : "Usuario" %>)
        </span>
        <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-primary btn-nav-salir">
            Salir
        </a>
    </div>
</header>

<div class="main-layout">
    <aside class="sidebar">
        <a href="${pageContext.request.contextPath}/MenuServlet" class="sidebar-btn">
            Ver Menú
        </a>
        <a href="${pageContext.request.contextPath}/MisPedidosServlet" class="sidebar-btn active">
            Mis Pedidos
        </a>
    </aside>

    <main class="content-container">
        <h2 class="section-title">Mis Pedidos Realizados</h2>

        <div style="background: white; padding: 20px; border-radius: 12px; border: 1px solid var(--borde);">
            <% if (listaPedidos != null && !listaPedidos.isEmpty()) { %>
                <table style="width: 100%; border-collapse: collapse; text-align: left;">
                    <thead>
                        <tr style="border-bottom: 2px solid var(--borde); color: var(--vino-primario);">
                            <th style="padding: 10px;">ID Pedido</th>
                            <th style="padding: 10px;">Fecha</th>
                            <th style="padding: 10px;">Evento</th>
                            <th style="padding: 10px;">Decoración</th>
                            <th style="padding: 10px;">Total</th>
                            <th style="padding: 10px;">Estado</th>
                            <th style="padding: 10px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for (Map<String, String> p : listaPedidos) { %>
                            <tr style="border-bottom: 1px solid var(--borde);">
                                <td style="padding: 10px;">#<%= p.get("id_pedido") %></td>
                                <td style="padding: 10px;"><%= p.get("fecha") %></td>
                                <td style="padding: 10px;"><%= p.get("evento") %></td>
                                <td style="padding: 10px;"><%= p.get("decoracion") %></td>
                                <td style="padding: 10px;">$<%= p.get("total") %></td>
                                <td style="padding: 10px;"><%= p.get("estado") %></td>
                                <td style="padding: 10px;">
                                    <a href="${pageContext.request.contextPath}/FacturaServlet?id=<%= p.get("id_pedido") %>" style="color: var(--vino-primario); font-weight:600;">Ver factura</a>
                                </td>
                            </tr>
                        <% } %>
                    </tbody>
                </table>
            <% } else { %>
                <p style="color: var(--texto-gris); text-align: center; margin: 20px 0;">No tienes pedidos registrados todavía.</p>
            <% } %>
        </div>
    </main>
</div>

</body>
</html>
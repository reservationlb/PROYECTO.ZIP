<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ page import="java.math.BigDecimal" %>
<%@ page import="Modelo.Reserva" %>
<%@ page import="Modelo.TipoEvento" %>
<%@ page import="Modelo.TipoDecoracion" %>
<%@ page import="Modelo.TipoMenu" %>
<%@ page import="Modelo.Color" %>
<%@ page import="Modelo.ReservaProducto" %>
<%@ page import="Modelo.Abono" %>
<%@ page import="Modelo.Usuario" %>
<%!
    private String claseEstado(String estado) {
        if (estado == null) { return "badge-Pendiente"; }
        return "badge-" + estado.trim().replace(" ", "_").replace("ó", "o").replace("í", "i");
    }

    private String formatoMoneda(BigDecimal valor) {
        if (valor == null) { return "0"; }
        return String.format("%,.0f", valor);
    }
%>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
    String nombreCompleto = (usuario != null) ? (usuario.getNombre() + " " + usuario.getApellido()) : "Cliente";
    List<Map<String, Object>> tarjetas = (List<Map<String, Object>>) request.getAttribute("tarjetas");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Mi Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/PanelCliente.css">
</head>
<body>

    <header class="nav-cliente">
        <a href="${pageContext.request.contextPath}/View/Cliente/Inicio.jsp" class="logo">Reservation <span>L.B.</span></a>
        <div class="nav-actions">
            <span class="btn-nav-user">Hola, <%= usuario != null ? usuario.getNombre() : "Cliente" %></span>
            <a href="${pageContext.request.contextPath}/MisPedidosServlet" class="btn-primary" style="background:#EAEAEA; color:#2B2B2B;">Ver tabla simple</a>
            <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-primary">Salir</a>
        </div>
    </header>

    <section class="panel-bienvenida">
        <div>
            <h1>Bienvenido, <%= nombreCompleto %></h1>
            <p>Este es tu panel — aquí puedes ver el estado de todas tus reservas en Latin Burger.</p>
        </div>
        <a href="${pageContext.request.contextPath}/Reservar" class="btn-nueva-reserva">+ Hacer una nueva reserva</a>
    </section>

    <h2 style="max-width:1100px;margin:0 auto;padding:0 1.5rem;color:var(--vino-primario);font-family:'Playfair Display',serif;">Mis reservas</h2>

    <% if (tarjetas == null || tarjetas.isEmpty()) { %>
    <div class="panel-vacio">
        <p>Todavía no tienes reservas registradas.</p>
        <p><a href="${pageContext.request.contextPath}/Reservar" class="btn-nueva-reserva" style="display:inline-block;margin-top:0.8rem;">Haz tu primera reserva</a></p>
    </div>
    <% } else { %>
    <div class="panel-container">
        <% for (Map<String, Object> t : tarjetas) {
            Reserva r = (Reserva) t.get("reserva");
            TipoEvento evento = (TipoEvento) t.get("evento");
            TipoDecoracion decoracion = (TipoDecoracion) t.get("decoracion");
            TipoMenu tipoMenu = (TipoMenu) t.get("tipoMenu");
            Color color = (Color) t.get("color");
            List<ReservaProducto> productos = (List<ReservaProducto>) t.get("productos");
            List<Abono> abonos = (List<Abono>) t.get("abonos");
            BigDecimal totalAbonado = (BigDecimal) t.get("totalAbonado");
            BigDecimal saldoPendiente = (BigDecimal) t.get("saldoPendiente");
            boolean saldado = saldoPendiente == null || saldoPendiente.compareTo(BigDecimal.ZERO) <= 0;
        %>
        <article class="reserva-card">
            <div class="reserva-card-header">
                <span class="numero">Reserva #<%= String.format("%03d", r.getIdReserva()) %></span>
                <span class="badge-estado <%= claseEstado(r.getEstado()) %>"><%= r.getEstado() %></span>
            </div>
            <div class="reserva-card-body">

                <div class="reserva-datos-rapidos">
                    <span>•  <%= r.getFecha() %></span>
                    <span>•  <%= r.getHora() %></span>
                    <span>•  <%= r.getNumeroPersona() %> personas</span>
                </div>

                <div class="reserva-seccion">
                    <span class="titulo-seccion">• Evento</span>
                    <span class="valor-principal"><%= evento != null ? evento.getNombreEvento() : "-" %></span>
                    <span class="detalle-secundario">Valor del evento: $<%= evento != null ? formatoMoneda(evento.getValorEvento()) : "0" %></span>
                </div>

                <div class="reserva-seccion">
                    <span class="titulo-seccion">• Color</span>
                    <span class="color-chip">
                        <% if (color != null) { %>
                        <span class="color-circulo-chip" style="background:<%= color.getCodigoHex() %>;"></span>
                        <%= color.getNombre() %>
                        <% } else { %>
                        <%= r.getColorEvento() != null ? r.getColorEvento() : "Sin definir" %>
                        <% } %>
                    </span>
                </div>

                <div class="reserva-seccion">
                    <span class="titulo-seccion">• Menú</span>
                    <span class="valor-principal"><%= tipoMenu != null ? tipoMenu.getNombreMenu() : "-" %></span>
                    <span class="detalle-secundario">$<%= tipoMenu != null ? formatoMoneda(tipoMenu.getValorMenu()) : "0" %></span>
                </div>

                <div class="reserva-seccion">
                    <span class="titulo-seccion">• Decoración</span>
                    <span class="valor-principal"><%= decoracion != null ? decoracion.getNombreDecoracion() : "-" %></span>
                    <span class="detalle-secundario">$<%= decoracion != null ? formatoMoneda(decoracion.getValorDecoracion()) : "0" %></span>
                </div>

                <% if (productos != null && !productos.isEmpty()) { %>
                <div class="reserva-seccion">
                    <span class="titulo-seccion">• Productos adicionales</span>
                    <ul class="lista-productos">
                        <% for (ReservaProducto p : productos) { %>
                        <li>
                            <span><%= p.getCantidad() %> × <%= p.getNombreProducto() %></span>
                            <span>$<%= formatoMoneda(p.getSubtotal()) %></span>
                        </li>
                        <% } %>
                    </ul>
                </div>
                <% } %>

                <% if (r.getComentarios() != null && !r.getComentarios().trim().isEmpty()) { %>
                <div class="reserva-seccion">
                    <span class="titulo-seccion">• Comentarios</span>
                    <span class="detalle-secundario"><%= r.getComentarios() %></span>
                </div>
                <% } %>

                <div class="reserva-resumen">
                    <div class="fila total"><span>$ Total</span><span>$<%= formatoMoneda(r.getValorReserva()) %></span></div>
                    <% if (abonos != null && !abonos.isEmpty()) { %>
                    <div class="fila"><span>Abonado</span><span>$<%= formatoMoneda(totalAbonado) %></span></div>
                    <% for (Abono a : abonos) { %>
                    <div class="fila detalle-secundario"><span><%= a.getMedioPago() %> — <%= a.getFechaAbono() %></span><span>$<%= formatoMoneda(a.getValorAbono()) %></span></div>
                    <% } %>
                    <% } %>
                    <div class="fila saldo <%= saldado ? "pagado" : "" %>">
                        <span><%= saldado ? "Saldo" : "Saldo pendiente" %></span>
                        <span><%= saldado ? "Pagado ✓" : "$" + formatoMoneda(saldoPendiente) %></span>
                    </div>
                </div>
            </div>
            <div class="reserva-card-footer">
                <a href="${pageContext.request.contextPath}/FacturaServlet?id=<%= r.getIdReserva() %>" class="btn-ver-factura">Ver factura</a>
            </div>
        </article>
        <% } %>
    </div>
    <% } %>

</body>
</html>

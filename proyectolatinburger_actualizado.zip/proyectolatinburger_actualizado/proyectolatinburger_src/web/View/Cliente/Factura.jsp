<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.Reserva" %>
<%@ page import="Modelo.TipoEvento" %>
<%@ page import="Modelo.TipoDecoracion" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.ReservaProducto" %>
<%@ page import="Modelo.Abono" %>
<%
    String nombreUsuario = (String) session.getAttribute("nombreCliente");
    String errorFactura = (String) request.getAttribute("errorFactura");
    Reserva reserva = (Reserva) request.getAttribute("reserva");
    TipoEvento evento = (TipoEvento) request.getAttribute("evento");
    TipoDecoracion decoracion = (TipoDecoracion) request.getAttribute("decoracion");
    Usuario cliente = (Usuario) request.getAttribute("cliente");
    List<ReservaProducto> items = (List<ReservaProducto>) request.getAttribute("items");
    List<Abono> abonos = (List<Abono>) request.getAttribute("abonos");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Factura</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/Wizard.css">
</head>
<body>

    <header class="nav-cliente">
        <a href="${pageContext.request.contextPath}/View/Cliente/Inicio.jsp" class="logo">Reservation <span>L.B</span></a>
        <div class="nav-actions">
            <span class="btn-nav-user">Cliente (<%= nombreUsuario != null ? nombreUsuario : "Usuario" %>)</span>
            <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-primary btn-nav-salir">Salir</a>
        </div>
    </header>

    <main class="wizard-container">
        <% if (errorFactura != null) { %>
            <div class="wizard-error"><%= errorFactura %></div>
            <a href="${pageContext.request.contextPath}/PanelClienteServlet" class="btn-gold">Ir a Mi Panel</a>
        <% } else { %>

        <div class="factura-box">
            <div class="factura-header">
                <p style="color:var(--dorado-acento);font-weight:700;">RESERVATION L.B. — LATIN BURGER</p>
                <h2>Comprobante de Reserva #<%= reserva.getIdReserva() %></h2>
                <p style="color:var(--texto-gris);font-size:0.85rem;">Fecha del evento: <%= reserva.getFecha() %> — <%= reserva.getHora() %></p>
            </div>

            <div class="factura-linea"><span>Cliente</span><span><%= cliente != null ? cliente.getNombre() + " " + cliente.getApellido() : "-" %></span></div>
            <div class="factura-linea"><span>Documento</span><span><%= cliente != null ? cliente.getNumeroDocumento() : "-" %></span></div>
            <div class="factura-linea"><span>Teléfono</span><span><%= cliente != null ? cliente.getTelefono() : "-" %></span></div>
            <div class="factura-linea"><span>Tipo de evento</span><span><%= evento != null ? evento.getNombreEvento() : "-" %></span></div>
            <div class="factura-linea"><span>Número de personas</span><span><%= reserva.getNumeroPersona() %></span></div>
            <div class="factura-linea"><span>Decoración</span><span><%= decoracion != null ? decoracion.getNombreDecoracion() : "-" %></span></div>
            <div class="factura-linea"><span>Color del evento</span><span><%= reserva.getColorEvento() != null ? reserva.getColorEvento() : "-" %></span></div>
            <div class="factura-linea"><span>Estado de la reserva</span><span><%= reserva.getEstado() %></span></div>

            <p class="resumen-seccion-titulo">Platos del pedido</p>
            <% if (items != null) {
                for (ReservaProducto it : items) { %>
            <div class="factura-linea">
                <span><%= it.getNombreProducto() %> (x<%= it.getCantidad() %>)</span>
                <span>$<%= String.format("%,.0f", it.getSubtotal()) %></span>
            </div>
            <% }
            } %>

            <% if (reserva.getComentarios() != null && !reserva.getComentarios().trim().isEmpty()) { %>
            <p class="resumen-seccion-titulo">Comentarios</p>
            <p style="font-size:0.85rem;color:var(--texto-oscuro);"><%= reserva.getComentarios() %></p>
            <% } %>

            <p class="resumen-seccion-titulo">Total y pagos</p>
            <div class="factura-linea"><strong>Total del evento</strong><strong>$<%= String.format("%,.0f", reserva.getValorReserva()) %></strong></div>
            <% if (abonos != null) {
                for (Abono a : abonos) { %>
            <div class="factura-linea">
                <span>Abono registrado — <%= a.getMedioPago() %></span>
                <span>$<%= String.format("%,.0f", a.getValorAbono()) %></span>
            </div>
            <% }
            } %>
        </div>

        <div class="wizard-actions no-print">
            <a href="${pageContext.request.contextPath}/PanelClienteServlet" class="btn-secundario">Ir a Mi Panel</a>
            <button type="button" class="btn-gold" onclick="window.print()">Descargar / Imprimir</button>
        </div>
        <% } %>
    </main>

</body>
</html>

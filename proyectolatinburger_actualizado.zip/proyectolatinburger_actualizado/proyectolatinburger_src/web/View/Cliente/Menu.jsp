<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>

<%
    String nombreUsuario = (String) session.getAttribute("nombreUsuario");
    if (nombreUsuario == null) {
        nombreUsuario = (String) session.getAttribute("nombreCliente");
    }
    if (nombreUsuario == null) {
        nombreUsuario = (String) session.getAttribute("usuario");
    }

    List<Map<String, String>> listaMenu
            = (List<Map<String, String>>) request.getAttribute("listaMenu");

    List<Map<String, String>> listaCategorias
            = (List<Map<String, String>>) request.getAttribute("listaCategorias");

    String errorMenu = (String) request.getAttribute("errorMenu");
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Menú</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/Wizard.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/Menu.css">
</head>
<body>

    <header class="nav-cliente">
        <a href="${pageContext.request.contextPath}/View/Cliente/Inicio.jsp" class="logo">Reservation <span>L.B</span></a>
        <div class="nav-actions">
            <span class="btn-nav-user">Cliente (<%= nombreUsuario != null ? nombreUsuario : "Usuario"%>)</span>
            <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-primary btn-nav-salir">Salir</a>
        </div>
    </header>

    <div class="wizard-progreso">
        <span>1. Disponibilidad</span>
        <span>2. Tipo de Evento</span>
        <span>3. Decoración</span>
        <span>4. Color</span>
        <span class="activo">5. Menú</span>
        <span>6. Resumen</span>
    </div>

    <main class="wizard-container container-ancho">
        <h2 class="wizard-title">Nuestro Menú</h2>
        <p class="wizard-subtitle">Elige los platos para tu evento. Puedes agregar varios antes de continuar.</p>

        <% if (errorMenu != null) { %>
        <div class="wizard-error"><%= errorMenu%></div>
        <% } %>

        <div class="filter-buttons">
            <button type="button" class="filter-btn active" data-filter="todos">Todos</button>
            <%
                if (listaCategorias != null) {
                    for (Map<String, String> categoria : listaCategorias) {
            %>
            <button type="button" class="filter-btn" data-filter="<%= categoria.get("id")%>"><%= categoria.get("nombre")%></button>
            <%
                    }
                }
            %>
        </div>

        <% if (listaMenu != null && !listaMenu.isEmpty()) { %>
        <div class="menu-grid">
            <%
                for (Map<String, String> plato : listaMenu) {
                    String img = plato.get("imagen");
            %>
            <div class="menu-card" data-categoria="<%= plato.get("idCategoria")%>">
                <div class="card-image-wrapper">
                    <% if (img != null && !img.trim().isEmpty()) { %>
                    <img src="${pageContext.request.contextPath}/<%= img %>" alt="<%= plato.get("nombre")%>" style="width:100%;height:100%;object-fit:cover;">
                    <% } else { %>
                    <div class="card-image-placeholder" aria-label="Imagen no disponible">🍽</div>
                    <% } %>
                </div>
                <div class="card-body">
                    <h3><%= plato.get("nombre")%></h3>
                    <p><%= plato.get("descripcion")%></p>
                    <div class="card-footer">
                        <span class="price">$<%= plato.get("precio")%></span>
                        <button type="button"
                                class="btn-add"
                                title="Agregar al pedido"
                                onclick="agregarAlPedido('<%= plato.get("id")%>', '<%= plato.get("nombre")%>', '<%= plato.get("precio").replace(",", ".")%>')">
                            +
                        </button>
                    </div>
                </div>
            </div>
            <%
                }
            %>
        </div>
        <% } else { %>
        <p class="no-items">No hay platos disponibles en este momento.</p>
        <% } %>

        <div class="wizard-actions">
            <a href="${pageContext.request.contextPath}/ColorServlet" class="btn-secundario">← Volver</a>
        </div>
    </main>

    <div class="mi-pedido-flotante" id="miPedidoContainer">
        <div class="pedido-header">
            <span>Mi Pedido</span>
            <span class="pedido-id" id="pedidoContador">0 productos</span>
        </div>
        <div class="pedido-body" id="listaResumenPedido">
            <p class="pedido-vacio">No hay productos agregados</p>
        </div>
        <div class="pedido-footer">
            <div class="subtotal-row">
                <span>Subtotal</span>
                <span id="subtotalMonto">$0.00</span>
            </div>
            <div class="acciones-pedido">
                <button type="button" class="btn-cancelar" id="btnCancelarPedido" onclick="limpiarPedido()" disabled>Vaciar</button>
                <button type="button" class="btn-confirmar" id="btnConfirmarPedido" onclick="confirmarPedido()" disabled>Confirmar y continuar →</button>
            </div>
        </div>
    </div>

    <form id="formConfirmarPedido" action="${pageContext.request.contextPath}/MenuServlet" method="POST" style="display:none;">
        <input type="hidden" name="carritoData" id="carritoDataInput">
    </form>

    <script>
        document.querySelectorAll(".filter-btn").forEach(function (boton) {
            boton.addEventListener("click", function () {
                document.querySelectorAll(".filter-btn").forEach(function (b) {
                    b.classList.remove("active");
                });
                boton.classList.add("active");
                var filtro = boton.getAttribute("data-filter");
                document.querySelectorAll(".menu-card").forEach(function (tarjeta) {
                    if (filtro === "todos" || tarjeta.getAttribute("data-categoria") === filtro) {
                        tarjeta.style.display = "flex";
                    } else {
                        tarjeta.style.display = "none";
                    }
                });
            });
        });

        let carrito = [];

        function agregarAlPedido(idProducto, nombreProducto, precioProducto) {
            let precioNum = parseFloat(precioProducto);
            let encontrado = carrito.find(item => item.id === idProducto);
            if (encontrado) {
                encontrado.cantidad += 1;
            } else {
                carrito.push({id: idProducto, nombre: nombreProducto, precio: precioNum, cantidad: 1});
            }
            actualizarVistaPedido();
        }

        function cambiarCantidad(index, delta) {
            carrito[index].cantidad += delta;
            if (carrito[index].cantidad <= 0) {
                carrito.splice(index, 1);
            }
            actualizarVistaPedido();
        }

        function actualizarVistaPedido() {
            let contenedor = document.getElementById("listaResumenPedido");
            let subtotalMonto = document.getElementById("subtotalMonto");
            let contador = document.getElementById("pedidoContador");
            let btnCancelar = document.getElementById("btnCancelarPedido");
            let btnConfirmar = document.getElementById("btnConfirmarPedido");

            let totalItems = carrito.reduce(function (acc, item) {
                return acc + item.cantidad;
            }, 0);
            contador.innerText = totalItems + (totalItems === 1 ? " producto" : " productos");

            if (carrito.length === 0) {
                contenedor.innerHTML = '<p class="pedido-vacio">No hay productos agregados</p>';
                subtotalMonto.innerText = "$0.00";
                btnCancelar.disabled = true;
                btnConfirmar.disabled = true;
                return;
            }

            btnCancelar.disabled = false;
            btnConfirmar.disabled = false;

            let html = "";
            let subtotal = 0;

            carrito.forEach(function (item, index) {
                let totalItem = item.precio * item.cantidad;
                subtotal += totalItem;
                html += '<div class="pedido-item">'
                        + '<div class="pedido-item-info">'
                        + '<span class="pedido-item-nombre">' + item.nombre + '</span>'
                        + '<span class="pedido-item-precio">$' + totalItem.toLocaleString('es-CO', {minimumFractionDigits: 2}) + '</span>'
                        + '</div>'
                        + '<div class="pedido-item-cantidad">'
                        + '<button type="button" onclick="cambiarCantidad(' + index + ', -1)">-</button>'
                        + '<span>' + item.cantidad + '</span>'
                        + '<button type="button" onclick="cambiarCantidad(' + index + ', 1)">+</button>'
                        + '</div>'
                        + '</div>';
            });

            contenedor.innerHTML = html;
            subtotalMonto.innerText = "$" + subtotal.toLocaleString('es-CO', {minimumFractionDigits: 2});
        }

        function limpiarPedido() {
            if (carrito.length === 0) {
                return;
            }
            if (confirm("¿Seguro que quieres vaciar tu pedido? Se eliminarán todos los platos que agregaste.")) {
                carrito = [];
                actualizarVistaPedido();
            }
        }

        function confirmarPedido() {
            if (carrito.length === 0) {
                alert("Agrega al menos un plato antes de continuar.");
                return;
            }
            let serializado = carrito.map(function (item) {
                return item.id + ":" + item.cantidad;
            }).join(",");

            document.getElementById("carritoDataInput").value = serializado;
            document.getElementById("formConfirmarPedido").submit();
        }
    </script>

</body>
</html>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%-- Declaración Taglib para Jakarta EE --%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registro de Usuario | Reservation L.B.</title>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

        <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/RegistroStyles.css">
    </head>
    <body>

        <div class="registro-container">
            <div class="registro-card">
                <h2>Crear Cuenta</h2>
                <p class="subtitulo">Únete a Reservation L.B. y gestiona tus pedidos y reservas fácilmente.</p>

                <%-- Mensaje de error retornado por el Servlet --%>
                <c:if test="${not empty requestScope.error}">
                    <p style="color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; border-radius: 8px; text-align: center; font-size: 14px;">
                        ${requestScope.error}
                    </p>
                </c:if>

                <form action="${pageContext.request.contextPath}/RegistroServlet" method="POST" class="form-grid">

                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text" id="nombre" name="nombre" placeholder="Tu nombre" 
                               pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+" 
                               title="El nombre solo debe contener letras y espacios"
                               oninput="this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '')" required>
                    </div>

                    <div class="form-group">
                        <label for="apellido">Apellido</label>
                        <input type="text" id="apellido" name="apellido" placeholder="Tu apellido" 
                               pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+" 
                               title="El apellido solo debe contener letras y espacios"
                               oninput="this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '')" required>
                    </div>

                    <!-- Selección de Tipo de Documento -->
                    <div class="form-group">
                        <label for="tipoDocumento">Tipo de Documento:</label>
                        <select name="tipo_documento_idtipo_documento" id="tipoDocumento" class="form-control" required>
                            <option value="" disabled selected>Seleccione un tipo</option>
                            <c:forEach var="tipo" items="${listaTiposDocumento}">
                                <option value="${tipo.idTipoDocumento}">${tipo.descripcion}</option>
                            </c:forEach>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="numero_documento">Número de Documento</label>
                        <input type="text" id="numero_documento" name="numero_documento" placeholder="Ej: 1012345678" 
                               inputmode="numeric"
                               pattern="[0-9]+" 
                               title="El documento solo debe contener dígitos numéricos"
                               oninput="this.value = this.value.replace(/[^0-9]/g, '')" required>
                    </div>

                    <div class="form-group">
                        <label for="direccion">Dirección</label>
                        <input type="text" id="direccion" name="direccion" placeholder="Ej: Calle 123 # 45 - 67" required>
                    </div>

                    <div class="form-group">
                        <label for="telefono">Teléfono</label>
                        <input type="tel" id="telefono" name="telefono" placeholder="Ej: 3001234567" 
                               inputmode="numeric"
                               pattern="[0-9]+" 
                               title="El teléfono solo debe contener dígitos numéricos"
                               oninput="this.value = this.value.replace(/[^0-9]/g, '')" required>
                    </div>

                    <div class="form-group">
                        <label for="fecha_nacimiento">Fecha de Nacimiento</label>
                        <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>
                    </div>

                    <div class="form-group">
                        <label for="contrasena">Contraseña</label>
                        <input type="password" id="contrasena" name="contrasena" placeholder="••••••••" required>
                    </div>

                    <div class="form-group full-width checkbox-group">
                        <input type="checkbox" id="tratamiento_datos" name="tratamiento_datos" required>
                        <label for="tratamiento_datos">Acepto el tratamiento de datos personales.</label>
                    </div>

                    <button type="submit" class="btn-primary-registro">Registrarse</button>

                    <p class="login-link">
                        ¿Ya tienes cuenta? <a href="${pageContext.request.contextPath}/LoginServlet">Inicia Sesión</a>
                    </p>

                </form>
            </div>
        </div>

    </body>
</html>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.TipoDecoracion" %>
<%
    String nombreUsuario = (String) session.getAttribute("nombreCliente");
    List<TipoDecoracion> listaDecoraciones = (List<TipoDecoracion>) request.getAttribute("listaDecoraciones");
    String error = (String) request.getAttribute("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Decoración</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/Wizard.css">
</head>
<body>

    <header class="nav-cliente">
        <a href="${pageContext.request.contextPath}/View/Cliente/Inicio.jsp" class="logo">Reservation <span>L.B</span></a>
        <div class="nav-actions">
            <span class="btn-nav-user">Cliente (<%= nombreUsuario != null ? nombreUsuario : "Usuario" %>)</span>
            <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-primary btn-nav-salir">Salir</a>
        </div>
    </header>

    <div class="wizard-progreso">
        <span>1. Disponibilidad</span>
        <span>2. Tipo de Evento</span>
        <span class="activo">3. Decoración</span>
        <span>4. Color</span>
        <span>5. Menú</span>
        <span>6. Resumen</span>
    </div>

    <main class="wizard-container">
        <h2 class="wizard-title">Decoración del evento</h2>
        <p class="wizard-subtitle">Elige la ambientación para tu celebración.</p>

        <% if (error != null) { %>
            <div class="wizard-error"><%= error %></div>
        <% } %>

        <form action="${pageContext.request.contextPath}/DecoracionServlet" method="POST">
            <input type="hidden" name="idTipoDecoracion" id="idTipoDecoracionInput" value="">

            <div class="option-grid">
                <% if (listaDecoraciones != null) {
                    for (TipoDecoracion td : listaDecoraciones) { %>
                <div class="option-card" data-id="<%= td.getIdTipoDecoracion() %>" onclick="seleccionar(this)">
                    <% if (td.getImagen() != null && !td.getImagen().trim().isEmpty()) { %>
                    <img src="${pageContext.request.contextPath}/<%= td.getImagen() %>" alt="<%= td.getNombreDecoracion() %>" style="width:100%;height:110px;object-fit:cover;border-radius:8px;margin-bottom:0.6rem;">
                    <% } %>
                    <h3><%= td.getNombreDecoracion() %></h3>
                    <p><%= td.getDescripcion() != null ? td.getDescripcion() : "" %></p>
                    <span class="valor">$<%= String.format("%,.0f", td.getValorDecoracion()) %></span>
                </div>
                <% }
                } %>
            </div>

            <div class="wizard-actions">
                <a href="${pageContext.request.contextPath}/EventoServlet" class="btn-secundario">← Volver</a>
                <button type="submit" class="btn-gold">Siguiente →</button>
            </div>
        </form>
    </main>

    <script>
        function seleccionar(card) {
            document.querySelectorAll('.option-card').forEach(function (c) {
                c.classList.remove('seleccionada');
            });
            card.classList.add('seleccionada');
            document.getElementById('idTipoDecoracionInput').value = card.getAttribute('data-id');
        }
    </script>

</body>
</html>

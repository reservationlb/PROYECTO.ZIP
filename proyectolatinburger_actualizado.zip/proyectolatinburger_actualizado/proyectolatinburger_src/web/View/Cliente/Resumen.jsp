<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ page import="Modelo.TipoEvento" %>
<%@ page import="Modelo.TipoDecoracion" %>
<%
    String nombreUsuario = (String) session.getAttribute("nombreCliente");
    List<Map<String, Object>> carrito = (List<Map<String, Object>>) request.getAttribute("carrito");
    TipoEvento evento = (TipoEvento) request.getAttribute("evento");
    TipoDecoracion decoracion = (TipoDecoracion) request.getAttribute("decoracion");
    java.math.BigDecimal totalPlatos = (java.math.BigDecimal) request.getAttribute("totalPlatos");
    java.math.BigDecimal totalGeneral = (java.math.BigDecimal) request.getAttribute("totalGeneral");
    String error = (String) request.getAttribute("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Valor Total</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/Wizard.css">
</head>
<body>

    <header class="nav-cliente">
        <a href="${pageContext.request.contextPath}/View/Cliente/Inicio.jsp" class="logo">Reservation <span>L.B</span></a>
        <div class="nav-actions">
            <span class="btn-nav-user">Cliente (<%= nombreUsuario != null ? nombreUsuario : "Usuario" %>)</span>
            <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-primary btn-nav-salir">Salir</a>
        </div>
    </header>

    <div class="wizard-progreso">
        <span>1. Disponibilidad</span>
        <span>2. Tipo de Evento</span>
        <span>3. Decoración</span>
        <span>4. Color</span>
        <span>5. Menú</span>
        <span class="activo">6. Resumen</span>
    </div>

    <main class="wizard-container">
        <h2 class="wizard-title">Valor total de tu evento</h2>
        <p class="wizard-subtitle">Revisa el detalle antes de confirmar tu reserva.</p>

        <% if (error != null) { %>
            <div class="wizard-error"><%= error %></div>
        <% } %>

        <table class="resumen-tabla">
            <% if (evento != null) { %>
            <tr>
                <td>Tipo de evento — <%= evento.getNombreEvento() %></td>
                <td class="monto">$<%= String.format("%,.0f", evento.getValorEvento()) %></td>
            </tr>
            <% } %>
            <% if (decoracion != null) { %>
            <tr>
                <td>Decoración — <%= decoracion.getNombreDecoracion() %></td>
                <td class="monto">$<%= String.format("%,.0f", decoracion.getValorDecoracion()) %></td>
            </tr>
            <% } %>
            <tr>
                <td>Platos del menú (<%= carrito != null ? carrito.size() : 0 %> ítems)</td>
                <td class="monto">$<%= totalPlatos != null ? String.format("%,.0f", totalPlatos) : "0" %></td>
            </tr>
            <tr class="total">
                <td>Total del evento</td>
                <td class="monto">$<%= totalGeneral != null ? String.format("%,.0f", totalGeneral) : "0" %></td>
            </tr>
        </table>

        <p class="resumen-seccion-titulo">Detalle del pedido</p>
        <table class="resumen-tabla">
            <% if (carrito != null) {
                for (Map<String, Object> item : carrito) { %>
            <tr>
                <td><%= item.get("nombre") %> (x<%= item.get("cantidad") %>)</td>
                <td class="monto">$<%= String.format("%,.0f", ((java.math.BigDecimal) item.get("precioUnitario")).doubleValue() * (Integer) item.get("cantidad")) %></td>
            </tr>
            <% }
            } %>
        </table>

        <form action="${pageContext.request.contextPath}/ResumenServlet" method="POST">
            <p class="resumen-seccion-titulo">Método de pago del abono</p>

            <div class="form-group">
                <select class="input-control" name="metodoPago" required>
                    <option value="">Selecciona un medio de pago</option>
                    <option value="Nequi">Nequi</option>
                    <option value="Daviplata">Daviplata</option>
                    <option value="Transferencia bancaria">Cuenta bancaria del restaurante</option>
                    <option value="Tarjeta débito">Tarjeta débito</option>
                    <option value="Tarjeta crédito">Tarjeta crédito</option>
                    <option value="Efectivo al terminar el evento">Al terminar el evento (efectivo)</option>
                </select>
            </div>

            <div class="form-group">
                <label for="montoAbono">Valor a abonar ahora (opcional — si lo dejas vacío se registra el total)</label>
                <input type="number" min="0" step="1000" class="input-control" id="montoAbono" name="montoAbono" placeholder="Ej: 50000">
            </div>

            <p style="font-size:0.8rem;color:var(--texto-gris);">
                No se procesa ningún cobro real desde este sistema: esto únicamente registra el abono
                acordado con el restaurante para tu reserva.
            </p>

            <div class="wizard-actions">
                <a href="${pageContext.request.contextPath}/MenuServlet" class="btn-secundario">← Volver</a>
                <button type="submit" class="btn-gold">Confirmar reserva</button>
            </div>
        </form>
    </main>

</body>
</html>

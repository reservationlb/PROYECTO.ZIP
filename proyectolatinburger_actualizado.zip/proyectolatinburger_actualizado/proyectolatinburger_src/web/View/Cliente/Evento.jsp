<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.TipoEvento" %>
<%
    String nombreUsuario = (String) session.getAttribute("nombreCliente");
    List<TipoEvento> listaEventos = (List<TipoEvento>) request.getAttribute("listaEventos");
    String error = (String) request.getAttribute("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Tipo de Evento</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Css/Wizard.css">
</head>
<body>

    <header class="nav-cliente">
        <a href="${pageContext.request.contextPath}/View/Cliente/Inicio.jsp" class="logo">Reservation <span>L.B</span></a>
        <div class="nav-actions">
            <span class="btn-nav-user">Cliente (<%= nombreUsuario != null ? nombreUsuario : "Usuario" %>)</span>
            <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-primary btn-nav-salir">Salir</a>
        </div>
    </header>

    <div class="wizard-progreso">
        <span>1. Disponibilidad</span>
        <span class="activo">2. Tipo de Evento</span>
        <span>3. Decoración</span>
        <span>4. Color</span>
        <span>5. Menú</span>
        <span>6. Resumen</span>
    </div>

    <main class="wizard-container">
        <h2 class="wizard-title">¿Qué vamos a celebrar?</h2>
        <p class="wizard-subtitle">Selecciona el tipo de evento e indícanos cuántas personas asistirán.</p>

        <% if (error != null) { %>
            <div class="wizard-error"><%= error %></div>
        <% } %>

        <form action="${pageContext.request.contextPath}/EventoServlet" method="POST">
            <input type="hidden" name="idTipoEvento" id="idTipoEventoInput" value="">

            <div class="option-grid">
                <% if (listaEventos != null) {
                    for (TipoEvento te : listaEventos) { %>
                <div class="option-card" data-id="<%= te.getIdTipoEvento() %>" onclick="seleccionar(this)">
                    <% if (te.getImagen() != null && !te.getImagen().trim().isEmpty()) { %>
                    <img src="${pageContext.request.contextPath}/<%= te.getImagen() %>" alt="<%= te.getNombreEvento() %>" style="width:100%;height:110px;object-fit:cover;border-radius:8px;margin-bottom:0.6rem;">
                    <% } %>
                    <h3><%= te.getNombreEvento() %></h3>
                    <p><%= te.getDescripcion() != null ? te.getDescripcion() : "" %></p>
                    <span class="valor">Desde $<%= String.format("%,.0f", te.getValorEvento()) %></span>
                </div>
                <% }
                } %>
            </div>

            <div class="form-group">
                <label for="numeroPersonas">Cantidad de personas</label>
                <input type="number" min="1" class="input-control" id="numeroPersonas" name="numeroPersonas" placeholder="Ej: 20" required>
            </div>

            <div class="wizard-actions">
                <a href="${pageContext.request.contextPath}/DisponibilidadServlet" class="btn-secundario">← Volver</a>
                <button type="submit" class="btn-gold">Siguiente →</button>
            </div>
        </form>
    </main>

    <script>
        function seleccionar(card) {
            document.querySelectorAll('.option-card').forEach(function (c) {
                c.classList.remove('seleccionada');
            });
            card.classList.add('seleccionada');
            document.getElementById('idTipoEventoInput').value = card.getAttribute('data-id');
        }
    </script>

</body>
</html>

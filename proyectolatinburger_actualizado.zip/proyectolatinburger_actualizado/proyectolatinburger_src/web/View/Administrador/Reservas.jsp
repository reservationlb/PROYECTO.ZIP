<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%!
    private String claseBadge(String estado) {
        if (estado == null) { return "badge-pendiente"; }
        switch (estado) {
            case "Confirmada": return "badge-confirmada";
            case "En preparación": return "badge-preparacion";
            case "Entregada": return "badge-entregada";
            case "Cancelada": return "badge-cancelada";
            default: return "badge-pendiente";
        }
    }
%>
<%
    List<Map<String, String>> reservas = (List<Map<String, String>>) request.getAttribute("reservas");
    String[] estados = {"Pendiente", "Confirmada", "En preparación", "Entregada", "Cancelada"};
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Reservas (Admin)</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1>Reservas</h1>
        <p class="admin-subtitle">Gestiona el estado de cada reserva del restaurante.</p>

        <div class="admin-panel">
            <div class="admin-panel-header">
                <h2>Todas las reservas</h2>
                <a href="${pageContext.request.contextPath}/AdminReservaFormServlet" class="btn-mini">+ Nuevo pedido</a>
            </div>
            <table class="admin-tabla">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Evento</th>
                        <th>Decoración</th>
                        <th>Personas</th>
                        <th>Total</th>
                        <th>Estado</th>
                        <th>Cambiar</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <% if (reservas != null) {
                        for (Map<String, String> r : reservas) { %>
                    <tr>
                        <td>#<%= r.get("id_reserva") %></td>
                        <td><%= r.get("cliente") %></td>
                        <td><%= r.get("fecha") %></td>
                        <td><%= r.get("hora") %></td>
                        <td><%= r.get("evento") %></td>
                        <td><%= r.get("decoracion") %></td>
                        <td><%= r.get("numero_persona") %></td>
                        <td>$<%= r.get("total") %></td>
                        <td><span class="badge <%= claseBadge(r.get("estado")) %>"><%= r.get("estado") %></span></td>
                        <td>
                            <form action="${pageContext.request.contextPath}/AdminReservasServlet" method="POST" style="display:flex; gap:0.3rem;">
                                <input type="hidden" name="accion" value="cambiarEstado">
                                <input type="hidden" name="idReserva" value="<%= r.get("id_reserva") %>">
                                <select name="nuevoEstado" class="mini-select" onchange="this.form.submit()">
                                    <% for (String e : estados) { %>
                                    <option value="<%= e %>" <%= e.equals(r.get("estado")) ? "selected" : "" %>><%= e %></option>
                                    <% } %>
                                </select>
                            </form>
                        </td>
                        <td>
                            <form action="${pageContext.request.contextPath}/AdminReservasServlet" method="POST" onsubmit="return confirm('¿Cancelar esta reserva y liberar el horario?');">
                                <input type="hidden" name="accion" value="cancelar">
                                <input type="hidden" name="idReserva" value="<%= r.get("id_reserva") %>">
                                <button type="submit" class="btn-mini peligro">Cancelar</button>
                            </form>
                        </td>
                    </tr>
                    <% }
                    } else { %>
                    <tr><td colspan="11">No hay reservas registradas todavía.</td></tr>
                    <% } %>
                </tbody>
            </table>
        </div>

<%@ include file="_AdminLayoutCierre.jsp" %>
</body>
</html>

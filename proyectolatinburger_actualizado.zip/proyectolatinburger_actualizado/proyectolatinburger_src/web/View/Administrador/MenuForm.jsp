<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.Producto" %>
<%@ page import="Modelo.Categoria" %>
<%
    Producto producto = (Producto) request.getAttribute("producto");
    List<Categoria> categorias = (List<Categoria>) request.getAttribute("categorias");
    String error = (String) request.getAttribute("error");
    boolean esNuevo = (producto == null);
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - <%= esNuevo ? "Nuevo Plato" : "Editar Plato" %></title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1><%= esNuevo ? "Nuevo plato" : "Editar: " + producto.getNombre() %></h1>
        <p class="admin-subtitle">Los cambios se reflejan de inmediato en el menú del sitio.</p>

        <% if (error != null) { %>
            <div class="alerta-error"><%= error %></div>
        <% } %>

        <div class="admin-panel">
            <form action="${pageContext.request.contextPath}/AdminMenuFormServlet" method="POST" class="form-grid">
                <input type="hidden" name="idProducto" value="<%= esNuevo ? 0 : producto.getIdProducto() %>">

                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" name="nombre" required value="<%= esNuevo ? "" : producto.getNombre() %>">
                </div>

                <div class="form-group">
                    <label>Categoría</label>
                    <select name="idCategoria" required>
                        <% if (categorias != null) {
                            for (Categoria c : categorias) { %>
                        <option value="<%= c.getIdCategoria() %>" <%= (!esNuevo && producto.getIdCategoria() == c.getIdCategoria()) ? "selected" : "" %>><%= c.getNombre() %></option>
                        <% }
                        } %>
                    </select>
                </div>

                <div class="form-group">
                    <label>Precio</label>
                    <input type="number" step="1" min="0" name="precio" required value="<%= esNuevo ? "" : (long) producto.getPrecio() %>">
                </div>

                <div class="form-group">
                    <label>Imagen (ruta relativa, opcional)</label>
                    <input type="text" name="imagen" placeholder="Imagenes/plato.jpg" value="<%= (!esNuevo && producto.getImagen() != null) ? producto.getImagen() : "" %>">
                </div>

                <div class="form-group full-width">
                    <label>Descripción</label>
                    <textarea name="descripcion" rows="3"><%= (!esNuevo && producto.getDescripcion() != null) ? producto.getDescripcion() : "" %></textarea>
                </div>

                <div class="full-width">
                    <button type="submit" class="btn-guardar">Guardar</button>
                    <a href="${pageContext.request.contextPath}/AdminMenuServlet" class="btn-mini secundario" style="margin-left:0.6rem;">Cancelar</a>
                </div>
            </form>
        </div>

<%@ include file="_AdminLayoutCierre.jsp" %>
</body>
</html>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.Usuario" %>
<%
    List<Usuario> usuarios = (List<Usuario>) request.getAttribute("usuarios");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Usuarios (Admin)</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1>Usuarios</h1>
        <p class="admin-subtitle">Consulta, edita, agrega y activa/inactiva usuarios del sistema.</p>

        <div class="admin-panel">
            <div class="admin-panel-header">
                <h2>Todos los usuarios</h2>
                <a href="${pageContext.request.contextPath}/AdminUsuarioFormServlet" class="btn-mini">+ Agregar usuario</a>
            </div>
            <table class="admin-tabla">
                <thead>
                    <tr><th>#</th><th>Nombre</th><th>Documento</th><th>Rol</th><th>Teléfono</th><th>Estado</th><th>Acciones</th></tr>
                </thead>
                <tbody>
                    <% if (usuarios != null) {
                        for (Usuario u : usuarios) { %>
                    <tr>
                        <td><%= u.getIdUsuario() %></td>
                        <td><%= u.getNombre() %> <%= u.getApellido() %></td>
                        <td><%= u.getNumeroDocumento() %></td>
                        <td><%= u.getRolDescripcion() %></td>
                        <td><%= u.getTelefono() %></td>
                        <td>
                            <span class="badge <%= "Activo".equalsIgnoreCase(u.getEstado()) ? "badge-activo" : "badge-inactivo" %>">
                                <%= u.getEstado() %>
                            </span>
                        </td>
                        <td style="display:flex; gap:0.4rem;">
                            <a href="${pageContext.request.contextPath}/AdminUsuarioFormServlet?id=<%= u.getIdUsuario() %>" class="btn-mini secundario">Editar</a>
                            <form action="${pageContext.request.contextPath}/AdminUsuariosServlet" method="POST">
                                <input type="hidden" name="idUsuario" value="<%= u.getIdUsuario() %>">
                                <% if ("Activo".equalsIgnoreCase(u.getEstado())) { %>
                                <input type="hidden" name="accion" value="inactivar">
                                <button type="submit" class="btn-mini peligro">Inactivar</button>
                                <% } else { %>
                                <input type="hidden" name="accion" value="activar">
                                <button type="submit" class="btn-mini">Activar</button>
                                <% } %>
                            </form>
                        </td>
                    </tr>
                    <% }
                    } else { %>
                    <tr><td colspan="7">No hay usuarios registrados.</td></tr>
                    <% } %>
                </tbody>
            </table>
        </div>

<%@ include file="_AdminLayoutCierre.jsp" %>
</body>
</html>

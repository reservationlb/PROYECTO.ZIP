<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.Producto" %>
<%@ page import="Modelo.Categoria" %>
<%
    List<Producto> productos = (List<Producto>) request.getAttribute("productos");
    List<Categoria> categorias = (List<Categoria>) request.getAttribute("categorias");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Menú (Admin)</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1>Menú del restaurante</h1>
        <p class="admin-subtitle">Agrega, edita u oculta platos. Los platos ocultos no se eliminan, solo dejan de mostrarse a los clientes.</p>

        <div class="admin-panel">
            <div class="admin-panel-header">
                <h2>Platos</h2>
                <a href="${pageContext.request.contextPath}/AdminMenuFormServlet" class="btn-mini">+ Agregar plato</a>
            </div>
            <table class="admin-tabla">
                <thead>
                    <tr><th>Nombre</th><th>Categoría</th><th>Precio</th><th>Estado</th><th>Acciones</th></tr>
                </thead>
                <tbody>
                    <% if (productos != null) {
                        for (Producto p : productos) {
                            String catNombre = "";
                            if (categorias != null) {
                                for (Categoria c : categorias) {
                                    if (c.getIdCategoria() == p.getIdCategoria()) { catNombre = c.getNombre(); }
                                }
                            }
                    %>
                    <tr>
                        <td><%= p.getNombre() %></td>
                        <td><%= catNombre %></td>
                        <td>$<%= String.format("%,.0f", p.getPrecio()) %></td>
                        <td>
                            <span class="badge <%= p.isActivo() ? "badge-activo" : "badge-inactivo" %>">
                                <%= p.isActivo() ? "Activo" : "Oculto" %>
                            </span>
                        </td>
                        <td style="display:flex; gap:0.4rem;">
                            <a href="${pageContext.request.contextPath}/AdminMenuFormServlet?id=<%= p.getIdProducto() %>" class="btn-mini secundario">Editar</a>
                            <form action="${pageContext.request.contextPath}/AdminMenuServlet" method="POST">
                                <input type="hidden" name="idProducto" value="<%= p.getIdProducto() %>">
                                <% if (p.isActivo()) { %>
                                <input type="hidden" name="accion" value="ocultar">
                                <button type="submit" class="btn-mini peligro">Ocultar</button>
                                <% } else { %>
                                <input type="hidden" name="accion" value="mostrar">
                                <button type="submit" class="btn-mini">Mostrar</button>
                                <% } %>
                            </form>
                        </td>
                    </tr>
                    <% }
                    } else { %>
                    <tr><td colspan="5">No hay platos registrados.</td></tr>
                    <% } %>
                </tbody>
            </table>
        </div>

<%@ include file="_AdminLayoutCierre.jsp" %>
</body>
</html>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%!
    private String claseBadge(String estado) {
        if (estado == null) { return "badge-pendiente"; }
        switch (estado) {
            case "Confirmada": return "badge-confirmada";
            case "En preparación": return "badge-preparacion";
            case "Entregada": return "badge-entregada";
            case "Cancelada": return "badge-cancelada";
            default: return "badge-pendiente";
        }
    }
%>
<%
    Integer pedidosHoy = (Integer) request.getAttribute("pedidosHoy");
    Double ventasHoy = (Double) request.getAttribute("ventasHoy");
    Integer pendientes = (Integer) request.getAttribute("pendientes");
    List<Map<String, String>> ultimosPedidos = (List<Map<String, String>>) request.getAttribute("ultimosPedidos");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Dashboard Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1>Dashboard General</h1>
        <p class="admin-subtitle">Resumen del estado actual del restaurante.</p>

        <div class="metricas-grid">
            <div class="metrica-card">
                <div class="valor"><%= pedidosHoy != null ? pedidosHoy : 0 %></div>
                <div class="etiqueta">Pedidos hoy</div>
            </div>
            <div class="metrica-card">
                <div class="valor">$<%= ventasHoy != null ? String.format("%,.0f", ventasHoy) : "0" %></div>
                <div class="etiqueta">Ventas hoy</div>
            </div>
            <div class="metrica-card">
                <div class="valor"><%= pendientes != null ? pendientes : 0 %></div>
                <div class="etiqueta">Reservas pendientes</div>
            </div>
        </div>

        <div class="admin-panel">
            <div class="admin-panel-header">
                <h2>Últimos pedidos</h2>
                <a href="${pageContext.request.contextPath}/AdminReservasServlet" class="btn-mini secundario">Ver todos</a>
            </div>
            <table class="admin-tabla">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Fecha</th>
                        <th>Evento</th>
                        <th>Total</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (ultimosPedidos != null) {
                        for (Map<String, String> p : ultimosPedidos) { %>
                    <tr>
                        <td>#<%= p.get("id_reserva") %></td>
                        <td><%= p.get("cliente") %></td>
                        <td><%= p.get("fecha") %></td>
                        <td><%= p.get("evento") %></td>
                        <td>$<%= p.get("total") %></td>
                        <td><span class="badge <%= claseBadge(p.get("estado")) %>"><%= p.get("estado") %></span></td>
                    </tr>
                    <% }
                    } else { %>
                    <tr><td colspan="6">Aún no hay reservas registradas.</td></tr>
                    <% } %>
                </tbody>
            </table>
        </div>

<%@ include file="_AdminLayoutCierre.jsp" %>
</body>
</html>

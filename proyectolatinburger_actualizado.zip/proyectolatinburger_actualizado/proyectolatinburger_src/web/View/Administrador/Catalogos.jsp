<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.TipoEvento" %>
<%@ page import="Modelo.TipoDecoracion" %>
<%@ page import="Modelo.Color" %>
<%
    String tipoActivo = (String) request.getAttribute("tipoActivo");
    if (tipoActivo == null) { tipoActivo = "evento"; }
    List<TipoEvento> eventos = (List<TipoEvento>) request.getAttribute("eventos");
    List<TipoDecoracion> decoraciones = (List<TipoDecoracion>) request.getAttribute("decoraciones");
    List<Color> colores = (List<Color>) request.getAttribute("colores");
    TipoEvento eventoEditar = (TipoEvento) request.getAttribute("eventoEditar");
    TipoDecoracion decoracionEditar = (TipoDecoracion) request.getAttribute("decoracionEditar");
    Color colorEditar = (Color) request.getAttribute("colorEditar");
    String error = (String) request.getAttribute("error");
    String ctx = request.getContextPath();
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Catálogos (Admin)</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1>Catálogos</h1>
        <p class="admin-subtitle">Tipos de evento, decoraciones y colores que el cliente ve al armar su reserva.</p>

        <% if (error != null) { %>
            <div class="alerta-error"><%= error %></div>
        <% } %>

        <div style="display:flex; gap:0.5rem; margin-bottom:1.2rem;">
            <a href="<%= ctx %>/AdminCatalogosServlet?tipo=evento" class="btn-mini <%= "evento".equals(tipoActivo) ? "" : "secundario" %>">Tipos de Evento</a>
            <a href="<%= ctx %>/AdminCatalogosServlet?tipo=decoracion" class="btn-mini <%= "decoracion".equals(tipoActivo) ? "" : "secundario" %>">Decoraciones</a>
            <a href="<%= ctx %>/AdminCatalogosServlet?tipo=color" class="btn-mini <%= "color".equals(tipoActivo) ? "" : "secundario" %>">Colores</a>
        </div>

        <% if ("evento".equals(tipoActivo)) { %>
        <div class="admin-panel">
            <h2 style="margin-bottom:1rem;"><%= eventoEditar != null ? "Editar tipo de evento" : "Agregar tipo de evento" %></h2>
            <form action="<%= ctx %>/AdminCatalogosServlet" method="POST" class="form-grid">
                <input type="hidden" name="tipo" value="evento">
                <input type="hidden" name="accion" value="guardar">
                <input type="hidden" name="id" value="<%= eventoEditar != null ? eventoEditar.getIdTipoEvento() : 0 %>">
                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" name="nombre" required value="<%= eventoEditar != null ? eventoEditar.getNombreEvento() : "" %>">
                </div>
                <div class="form-group">
                    <label>Valor</label>
                    <input type="number" step="1" min="0" name="valor" required value="<%= eventoEditar != null ? eventoEditar.getValorEvento() : "" %>">
                </div>
                <div class="form-group">
                    <label>Imagen (ruta relativa, opcional)</label>
                    <input type="text" name="imagen" placeholder="Imagenes/cumpleanos.jpg" value="<%= (eventoEditar != null && eventoEditar.getImagen() != null) ? eventoEditar.getImagen() : "" %>">
                </div>
                <div class="form-group full-width">
                    <label>Descripción</label>
                    <textarea name="descripcion" rows="2"><%= eventoEditar != null && eventoEditar.getDescripcion() != null ? eventoEditar.getDescripcion() : "" %></textarea>
                </div>
                <div class="full-width">
                    <button type="submit" class="btn-guardar">Guardar</button>
                    <% if (eventoEditar != null) { %>
                    <a href="<%= ctx %>/AdminCatalogosServlet?tipo=evento" class="btn-mini secundario" style="margin-left:0.6rem;">Cancelar edición</a>
                    <% } %>
                </div>
            </form>
        </div>

        <div class="admin-panel">
            <table class="admin-tabla">
                <thead><tr><th>Nombre</th><th>Valor</th><th>Estado</th><th>Acciones</th></tr></thead>
                <tbody>
                    <% if (eventos != null) {
                        for (TipoEvento te : eventos) { %>
                    <tr>
                        <td><%= te.getNombreEvento() %></td>
                        <td>$<%= String.format("%,.0f", te.getValorEvento()) %></td>
                        <td><span class="badge <%= te.isActivo() ? "badge-activo" : "badge-inactivo" %>"><%= te.isActivo() ? "Activo" : "Oculto" %></span></td>
                        <td style="display:flex; gap:0.4rem;">
                            <a href="<%= ctx %>/AdminCatalogosServlet?tipo=evento&editar=<%= te.getIdTipoEvento() %>" class="btn-mini secundario">Editar</a>
                            <form action="<%= ctx %>/AdminCatalogosServlet" method="POST">
                                <input type="hidden" name="tipo" value="evento">
                                <input type="hidden" name="accion" value="cambiarActivo">
                                <input type="hidden" name="id" value="<%= te.getIdTipoEvento() %>">
                                <input type="hidden" name="activo" value="<%= te.isActivo() ? "0" : "1" %>">
                                <button type="submit" class="btn-mini <%= te.isActivo() ? "peligro" : "" %>"><%= te.isActivo() ? "Ocultar" : "Mostrar" %></button>
                            </form>
                        </td>
                    </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>
        <% } %>

        <% if ("decoracion".equals(tipoActivo)) { %>
        <div class="admin-panel">
            <h2 style="margin-bottom:1rem;"><%= decoracionEditar != null ? "Editar decoración" : "Agregar decoración" %></h2>
            <form action="<%= ctx %>/AdminCatalogosServlet" method="POST" class="form-grid">
                <input type="hidden" name="tipo" value="decoracion">
                <input type="hidden" name="accion" value="guardar">
                <input type="hidden" name="id" value="<%= decoracionEditar != null ? decoracionEditar.getIdTipoDecoracion() : 0 %>">
                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" name="nombre" required value="<%= decoracionEditar != null ? decoracionEditar.getNombreDecoracion() : "" %>">
                </div>
                <div class="form-group">
                    <label>Valor</label>
                    <input type="number" step="1" min="0" name="valor" required value="<%= decoracionEditar != null ? decoracionEditar.getValorDecoracion() : "" %>">
                </div>
                <div class="form-group">
                    <label>Imagen (ruta relativa, opcional)</label>
                    <input type="text" name="imagen" placeholder="Imagenes/decoracion.jpg" value="<%= (decoracionEditar != null && decoracionEditar.getImagen() != null) ? decoracionEditar.getImagen() : "" %>">
                </div>
                <div class="form-group full-width">
                    <label>Descripción</label>
                    <textarea name="descripcion" rows="2"><%= decoracionEditar != null && decoracionEditar.getDescripcion() != null ? decoracionEditar.getDescripcion() : "" %></textarea>
                </div>
                <div class="full-width">
                    <button type="submit" class="btn-guardar">Guardar</button>
                    <% if (decoracionEditar != null) { %>
                    <a href="<%= ctx %>/AdminCatalogosServlet?tipo=decoracion" class="btn-mini secundario" style="margin-left:0.6rem;">Cancelar edición</a>
                    <% } %>
                </div>
            </form>
        </div>

        <div class="admin-panel">
            <table class="admin-tabla">
                <thead><tr><th>Nombre</th><th>Valor</th><th>Estado</th><th>Acciones</th></tr></thead>
                <tbody>
                    <% if (decoraciones != null) {
                        for (TipoDecoracion td : decoraciones) { %>
                    <tr>
                        <td><%= td.getNombreDecoracion() %></td>
                        <td>$<%= String.format("%,.0f", td.getValorDecoracion()) %></td>
                        <td><span class="badge <%= td.isActivo() ? "badge-activo" : "badge-inactivo" %>"><%= td.isActivo() ? "Activo" : "Oculto" %></span></td>
                        <td style="display:flex; gap:0.4rem;">
                            <a href="<%= ctx %>/AdminCatalogosServlet?tipo=decoracion&editar=<%= td.getIdTipoDecoracion() %>" class="btn-mini secundario">Editar</a>
                            <form action="<%= ctx %>/AdminCatalogosServlet" method="POST">
                                <input type="hidden" name="tipo" value="decoracion">
                                <input type="hidden" name="accion" value="cambiarActivo">
                                <input type="hidden" name="id" value="<%= td.getIdTipoDecoracion() %>">
                                <input type="hidden" name="activo" value="<%= td.isActivo() ? "0" : "1" %>">
                                <button type="submit" class="btn-mini <%= td.isActivo() ? "peligro" : "" %>"><%= td.isActivo() ? "Ocultar" : "Mostrar" %></button>
                            </form>
                        </td>
                    </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>
        <% } %>

        <% if ("color".equals(tipoActivo)) { %>
        <div class="admin-panel">
            <h2 style="margin-bottom:1rem;"><%= colorEditar != null ? "Editar color" : "Agregar color" %></h2>
            <form action="<%= ctx %>/AdminCatalogosServlet" method="POST" class="form-grid">
                <input type="hidden" name="tipo" value="color">
                <input type="hidden" name="accion" value="guardar">
                <input type="hidden" name="id" value="<%= colorEditar != null ? colorEditar.getIdColor() : 0 %>">
                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" name="nombre" required value="<%= colorEditar != null ? colorEditar.getNombre() : "" %>">
                </div>
                <div class="form-group">
                    <label>Código de color</label>
                    <input type="color" name="codigoHex" required value="<%= colorEditar != null ? colorEditar.getCodigoHex() : "#C0392B" %>">
                </div>
                <div class="form-group full-width">
                    <label>Imagen (ruta relativa, opcional)</label>
                    <input type="text" name="imagen" placeholder="Imagenes/color.jpg" value="<%= (colorEditar != null && colorEditar.getImagen() != null) ? colorEditar.getImagen() : "" %>">
                </div>
                <div class="full-width">
                    <button type="submit" class="btn-guardar">Guardar</button>
                    <% if (colorEditar != null) { %>
                    <a href="<%= ctx %>/AdminCatalogosServlet?tipo=color" class="btn-mini secundario" style="margin-left:0.6rem;">Cancelar edición</a>
                    <% } %>
                </div>
            </form>
        </div>

        <div class="admin-panel">
            <table class="admin-tabla">
                <thead><tr><th>Color</th><th>Nombre</th><th>Estado</th><th>Acciones</th></tr></thead>
                <tbody>
                    <% if (colores != null) {
                        for (Color c : colores) { %>
                    <tr>
                        <td><span style="display:inline-block;width:24px;height:24px;border-radius:50%;background:<%= c.getCodigoHex() %>;border:1px solid #ccc;"></span></td>
                        <td><%= c.getNombre() %></td>
                        <td><span class="badge <%= c.isActivo() ? "badge-activo" : "badge-inactivo" %>"><%= c.isActivo() ? "Activo" : "Oculto" %></span></td>
                        <td style="display:flex; gap:0.4rem;">
                            <a href="<%= ctx %>/AdminCatalogosServlet?tipo=color&editar=<%= c.getIdColor() %>" class="btn-mini secundario">Editar</a>
                            <form action="<%= ctx %>/AdminCatalogosServlet" method="POST">
                                <input type="hidden" name="tipo" value="color">
                                <input type="hidden" name="accion" value="cambiarActivo">
                                <input type="hidden" name="id" value="<%= c.getIdColor() %>">
                                <input type="hidden" name="activo" value="<%= c.isActivo() ? "0" : "1" %>">
                                <button type="submit" class="btn-mini <%= c.isActivo() ? "peligro" : "" %>"><%= c.isActivo() ? "Ocultar" : "Mostrar" %></button>
                            </form>
                        </td>
                    </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>
        <% } %>

<%@ include file="_AdminLayoutCierre.jsp" %>
</body>
</html>

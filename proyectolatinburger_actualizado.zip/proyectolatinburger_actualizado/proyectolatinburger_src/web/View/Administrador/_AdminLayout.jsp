<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%-- Fragmento incluido por todas las páginas de /View/Administrador/.
     Espera un atributo de request "seccionActiva" con uno de:
     dashboard | reservas | menu | usuarios | reportes --%>
<%
    String nombreAdmin = (String) session.getAttribute("nombreCliente");
    String seccionActiva = (String) request.getAttribute("seccionActiva");
    if (seccionActiva == null) {
        seccionActiva = "";
    }
%>
<header class="admin-nav">
    <a href="${pageContext.request.contextPath}/AdminDashboardServlet" class="logo">Reservation <span>L.B.</span></a>
    <div class="admin-nav-actions">
        <span class="rol-badge">ADMIN</span>
        <span class="nombre"><%= nombreAdmin != null ? nombreAdmin : "Administrador" %></span>
        <a href="${pageContext.request.contextPath}/LogoutServlet" class="salir">Salir</a>
    </div>
</header>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <a href="${pageContext.request.contextPath}/AdminDashboardServlet" class="<%= "dashboard".equals(seccionActiva) ? "activo" : "" %>">Dashboard</a>
        <a href="${pageContext.request.contextPath}/AdminReservasServlet" class="<%= "reservas".equals(seccionActiva) ? "activo" : "" %>">Reservas</a>
        <a href="${pageContext.request.contextPath}/AdminDisponibilidadServlet" class="<%= "disponibilidad".equals(seccionActiva) ? "activo" : "" %>">Disponibilidad</a>
        <a href="${pageContext.request.contextPath}/AdminMenuServlet" class="<%= "menu".equals(seccionActiva) ? "activo" : "" %>">Menú</a>
        <a href="${pageContext.request.contextPath}/AdminCatalogosServlet" class="<%= "catalogos".equals(seccionActiva) ? "activo" : "" %>">Catálogos</a>
        <a href="${pageContext.request.contextPath}/AdminUsuariosServlet" class="<%= "usuarios".equals(seccionActiva) ? "activo" : "" %>">Usuarios</a>
        <a href="${pageContext.request.contextPath}/AdminAbonosServlet" class="<%= "abonos".equals(seccionActiva) ? "activo" : "" %>">Abonos</a>
        <a href="${pageContext.request.contextPath}/AdminReportesServlet" class="<%= "reportes".equals(seccionActiva) ? "activo" : "" %>">Reportes</a>
    </aside>
    <main class="admin-content">

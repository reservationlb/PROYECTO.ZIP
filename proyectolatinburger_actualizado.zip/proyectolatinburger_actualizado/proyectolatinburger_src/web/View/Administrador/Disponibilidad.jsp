<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.Disponibilidad" %>
<%
    List<Disponibilidad> disponibilidades = (List<Disponibilidad>) request.getAttribute("disponibilidades");
    String error = (String) request.getAttribute("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Disponibilidad (Admin)</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1>Disponibilidad</h1>
        <p class="admin-subtitle">Agrega los horarios en los que el restaurante puede recibir un evento.</p>

        <% if (error != null) { %>
            <div class="alerta-error"><%= error %></div>
        <% } %>

        <div class="admin-panel">
            <h2 style="margin-bottom:1rem;">Agregar horario</h2>
            <form action="${pageContext.request.contextPath}/AdminDisponibilidadServlet" method="POST" class="form-grid">
                <input type="hidden" name="accion" value="agregar">
                <div class="form-group">
                    <label>Fecha</label>
                    <input type="date" name="fecha" required>
                </div>
                <div class="form-group">
                    <label>Hora</label>
                    <input type="time" name="hora" required>
                </div>
                <div class="full-width">
                    <button type="submit" class="btn-guardar">+ Agregar horario</button>
                </div>
            </form>
        </div>

        <div class="admin-panel">
            <div class="admin-panel-header"><h2>Horarios registrados</h2></div>
            <table class="admin-tabla">
                <thead><tr><th>Fecha</th><th>Hora</th><th>Estado</th><th>Acciones</th></tr></thead>
                <tbody>
                    <% if (disponibilidades != null) {
                        for (Disponibilidad d : disponibilidades) { %>
                    <tr>
                        <td><%= d.getFecha() %></td>
                        <td><%= d.getHora() %></td>
                        <td>
                            <span class="badge <%= "Disponible".equals(d.getEstado()) ? "badge-activo" : "badge-inactivo" %>">
                                <%= d.getEstado() %>
                            </span>
                        </td>
                        <td>
                            <% if ("Disponible".equals(d.getEstado())) { %>
                            <form action="${pageContext.request.contextPath}/AdminDisponibilidadServlet" method="POST" onsubmit="return confirm('¿Eliminar este horario?');">
                                <input type="hidden" name="accion" value="eliminar">
                                <input type="hidden" name="idDisponibilidad" value="<%= d.getIdDisponibilidad() %>">
                                <button type="submit" class="btn-mini peligro">Eliminar</button>
                            </form>
                            <% } else { %>
                            <span style="color:var(--texto-gris); font-size:0.8rem;">Ya tiene una reserva</span>
                            <% } %>
                        </td>
                    </tr>
                    <% }
                    } else { %>
                    <tr><td colspan="4">No hay horarios registrados todavía.</td></tr>
                    <% } %>
                </tbody>
            </table>
        </div>

<%@ include file="_AdminLayoutCierre.jsp" %>
</body>
</html>

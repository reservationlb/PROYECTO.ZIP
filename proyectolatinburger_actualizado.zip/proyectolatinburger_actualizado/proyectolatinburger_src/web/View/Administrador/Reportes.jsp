<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%
    Integer pedidosEsteMes = (Integer) request.getAttribute("pedidosEsteMes");
    Double ventasEsteMes = (Double) request.getAttribute("ventasEsteMes");
    List<Map<String, String>> ventasPorMes = (List<Map<String, String>>) request.getAttribute("ventasPorMes");
    List<Map<String, String>> popularidad = (List<Map<String, String>>) request.getAttribute("popularidad");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Reportes (Admin)</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1>Reportes y estadísticas</h1>
        <p class="admin-subtitle">Toda la información proviene directamente de la base de datos.</p>

        <div class="metricas-grid">
            <div class="metrica-card">
                <div class="valor">$<%= ventasEsteMes != null ? String.format("%,.0f", ventasEsteMes) : "0" %></div>
                <div class="etiqueta">Ventas este mes</div>
            </div>
            <div class="metrica-card">
                <div class="valor"><%= pedidosEsteMes != null ? pedidosEsteMes : 0 %></div>
                <div class="etiqueta">Pedidos este mes</div>
            </div>
        </div>

        <div class="admin-panel">
            <div class="admin-panel-header"><h2>Ventas por mes</h2></div>
            <table class="admin-tabla">
                <thead><tr><th>Mes</th><th>Ventas</th></tr></thead>
                <tbody>
                    <% if (ventasPorMes != null) {
                        for (Map<String, String> m : ventasPorMes) { %>
                    <tr>
                        <td style="text-transform:capitalize;"><%= m.get("mes") %></td>
                        <td>$<%= m.get("valor") %></td>
                    </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>

        <div class="admin-panel">
            <div class="admin-panel-header"><h2>Popularidad de platos</h2></div>
            <table class="admin-tabla">
                <thead><tr><th>Plato</th><th>Unidades vendidas</th><th>Ingresos</th></tr></thead>
                <tbody>
                    <% if (popularidad != null && !popularidad.isEmpty()) {
                        for (Map<String, String> p : popularidad) { %>
                    <tr>
                        <td><%= p.get("nombre") %></td>
                        <td><%= p.get("unidades") %></td>
                        <td>$<%= p.get("ingresos") %></td>
                    </tr>
                    <% }
                    } else { %>
                    <tr><td colspan="3">Aún no hay pedidos con platos registrados.</td></tr>
                    <% } %>
                </tbody>
            </table>
        </div>

<%@ include file="_AdminLayoutCierre.jsp" %>
</body>
</html>

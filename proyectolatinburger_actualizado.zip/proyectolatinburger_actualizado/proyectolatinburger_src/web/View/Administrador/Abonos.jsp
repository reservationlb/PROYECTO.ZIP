<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%
    List<Map<String, String>> abonos = (List<Map<String, String>>) request.getAttribute("abonos");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Abonos (Admin)</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1>Abonos</h1>
        <p class="admin-subtitle">Todos los abonos registrados por los clientes al confirmar sus reservas.</p>

        <div class="admin-panel">
            <table class="admin-tabla">
                <thead>
                    <tr><th>#</th><th>Cliente</th><th>Reserva</th><th>Fecha del evento</th><th>Medio de pago</th><th>Valor abonado</th><th>Fecha del abono</th><th>Estado</th></tr>
                </thead>
                <tbody>
                    <% if (abonos != null && !abonos.isEmpty()) {
                        for (Map<String, String> a : abonos) { %>
                    <tr>
                        <td>#<%= a.get("id_abono") %></td>
                        <td><%= a.get("cliente") %></td>
                        <td>
                            <a href="${pageContext.request.contextPath}/FacturaServlet?id=<%= a.get("id_reserva") %>">#<%= a.get("id_reserva") %></a>
                        </td>
                        <td><%= a.get("fecha_evento") %></td>
                        <td><%= a.get("medio_pago") %></td>
                        <td>$<%= a.get("valor_abono") %></td>
                        <td><%= a.get("fecha_abono") %></td>
                        <td><span class="badge badge-activo"><%= a.get("estado") %></span></td>
                    </tr>
                    <% }
                    } else { %>
                    <tr><td colspan="8">Todavía no se ha registrado ningún abono.</td></tr>
                    <% } %>
                </tbody>
            </table>
        </div>

<%@ include file="_AdminLayoutCierre.jsp" %>
</body>
</html>

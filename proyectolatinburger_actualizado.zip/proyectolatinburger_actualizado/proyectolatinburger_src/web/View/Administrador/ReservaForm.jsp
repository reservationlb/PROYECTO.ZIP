<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.Disponibilidad" %>
<%@ page import="Modelo.TipoEvento" %>
<%@ page import="Modelo.TipoDecoracion" %>
<%@ page import="Modelo.TipoDocumento" %>
<%@ page import="Modelo.Categoria" %>
<%@ page import="Modelo.Producto" %>
<%@ page import="Modelo.Color" %>
<%
    List<Disponibilidad> disponibles = (List<Disponibilidad>) request.getAttribute("disponibles");
    List<TipoEvento> eventos = (List<TipoEvento>) request.getAttribute("eventos");
    List<TipoDecoracion> decoraciones = (List<TipoDecoracion>) request.getAttribute("decoraciones");
    List<TipoDocumento> tiposDocumento = (List<TipoDocumento>) request.getAttribute("tiposDocumento");
    List<Categoria> categorias = (List<Categoria>) request.getAttribute("categorias");
    List<Producto> productos = (List<Producto>) request.getAttribute("productos");
    List<Color> colores = (List<Color>) request.getAttribute("colores");
    String error = (String) request.getAttribute("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - Nuevo Pedido (Admin)</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1>+ Nuevo Pedido</h1>
        <p class="admin-subtitle">Registra una reserva a nombre de un cliente (existente o nuevo).</p>

        <% if (error != null) { %>
            <div class="alerta-error"><%= error %></div>
        <% } %>

        <form action="${pageContext.request.contextPath}/AdminReservaFormServlet" method="POST">
            <div class="admin-panel">
                <h2 style="margin-bottom:1rem;">Datos del cliente</h2>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Nombre</label>
                        <input type="text" name="nombre" placeholder="Solo si es cliente nuevo">
                    </div>
                    <div class="form-group">
                        <label>Apellido</label>
                        <input type="text" name="apellido">
                    </div>
                    <div class="form-group">
                        <label>Tipo de documento</label>
                        <select name="tipoDocumentoId">
                            <% if (tiposDocumento != null) {
                                for (TipoDocumento td : tiposDocumento) { %>
                            <option value="<%= td.getIdTipoDocumento() %>"><%= td.getDescripcion() %></option>
                            <% }
                            } %>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Número de documento *</label>
                        <input type="text" name="numeroDocumento" required placeholder="Si ya existe, se reutiliza el cliente">
                    </div>
                    <div class="form-group">
                        <label>Dirección</label>
                        <input type="text" name="direccion">
                    </div>
                    <div class="form-group">
                        <label>Teléfono</label>
                        <input type="text" name="telefono">
                    </div>
                </div>
            </div>

            <div class="admin-panel">
                <h2 style="margin-bottom:1rem;">Datos del evento</h2>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Disponibilidad (fecha / hora) *</label>
                        <select name="idDisponibilidad" required>
                            <option value="">Selecciona...</option>
                            <% if (disponibles != null) {
                                for (Disponibilidad d : disponibles) { %>
                            <option value="<%= d.getIdDisponibilidad() %>"><%= d.getFecha() %> — <%= d.getHora() %></option>
                            <% }
                            } %>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Número de personas *</label>
                        <input type="number" min="1" name="numeroPersonas" required>
                    </div>
                    <div class="form-group">
                        <label>Tipo de evento *</label>
                        <select name="idTipoEvento" required>
                            <option value="">Selecciona...</option>
                            <% if (eventos != null) {
                                for (TipoEvento te : eventos) { %>
                            <option value="<%= te.getIdTipoEvento() %>"><%= te.getNombreEvento() %> ($<%= String.format("%,.0f", te.getValorEvento()) %>)</option>
                            <% }
                            } %>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Decoración *</label>
                        <select name="idTipoDecoracion" required>
                            <option value="">Selecciona...</option>
                            <% if (decoraciones != null) {
                                for (TipoDecoracion td : decoraciones) { %>
                            <option value="<%= td.getIdTipoDecoracion() %>"><%= td.getNombreDecoracion() %> ($<%= String.format("%,.0f", td.getValorDecoracion()) %>)</option>
                            <% }
                            } %>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Color del evento</label>
                        <select name="color">
                            <% if (colores != null) {
                                for (Color c : colores) { %>
                            <option value="<%= c.getNombre() %>"><%= c.getNombre() %></option>
                            <% }
                            } %>
                        </select>
                    </div>
                    <div class="form-group full-width">
                        <label>Comentarios adicionales</label>
                        <textarea name="comentarios" rows="2"></textarea>
                    </div>
                </div>
            </div>

            <div class="admin-panel">
                <h2 style="margin-bottom:1rem;">Menú del pedido</h2>
                <input type="hidden" name="carritoData" id="carritoDataInput">
                <table class="admin-tabla">
                    <thead><tr><th>Plato</th><th>Categoría</th><th>Precio</th><th>Cantidad</th></tr></thead>
                    <tbody>
                        <% if (productos != null) {
                            for (Producto p : productos) { %>
                        <tr>
                            <td><%= p.getNombre() %></td>
                            <td>
                                <%
                                    String catNombre = "";
                                    if (categorias != null) {
                                        for (Categoria c : categorias) {
                                            if (c.getIdCategoria() == p.getIdCategoria()) { catNombre = c.getNombre(); }
                                        }
                                    }
                                %>
                                <%= catNombre %>
                            </td>
                            <td>$<%= String.format("%,.0f", p.getPrecio()) %></td>
                            <td><input type="number" min="0" value="0" class="cantidad-plato" data-id="<%= p.getIdProducto() %>" style="width:70px;"></td>
                        </tr>
                        <% }
                        } %>
                    </tbody>
                </table>
            </div>

            <div class="wizard-actions" style="max-width:100%;">
                <a href="${pageContext.request.contextPath}/AdminReservasServlet" class="btn-mini secundario">Cancelar</a>
                <button type="submit" class="btn-guardar" onclick="return armarCarrito();">Registrar pedido</button>
            </div>
        </form>

<%@ include file="_AdminLayoutCierre.jsp" %>

<script>
    function armarCarrito() {
        var pares = [];
        document.querySelectorAll('.cantidad-plato').forEach(function (input) {
            var cantidad = parseInt(input.value, 10);
            if (cantidad > 0) {
                pares.push(input.getAttribute('data-id') + ':' + cantidad);
            }
        });
        document.getElementById('carritoDataInput').value = pares.join(',');
        return true;
    }
</script>
</body>
</html>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Rol" %>
<%@ page import="Modelo.TipoDocumento" %>
<%
    Usuario usuario = (Usuario) request.getAttribute("usuario");
    List<Rol> roles = (List<Rol>) request.getAttribute("roles");
    List<TipoDocumento> tiposDocumento = (List<TipoDocumento>) request.getAttribute("tiposDocumento");
    String error = (String) request.getAttribute("error");
    boolean esNuevo = (usuario == null);
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation L.B. - <%= esNuevo ? "Nuevo Usuario" : "Editar Usuario" %></title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CssAdministrador/Admin.css">
</head>
<body>

<%@ include file="_AdminLayout.jsp" %>

        <h1><%= esNuevo ? "Nuevo usuario" : "Editar: " + usuario.getNombre() + " " + usuario.getApellido() %></h1>

        <% if (error != null) { %>
            <div class="alerta-error"><%= error %></div>
        <% } %>

        <div class="admin-panel">
            <form action="${pageContext.request.contextPath}/AdminUsuarioFormServlet" method="POST" class="form-grid">
                <input type="hidden" name="idUsuario" value="<%= esNuevo ? 0 : usuario.getIdUsuario() %>">

                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" name="nombre" required value="<%= esNuevo ? "" : usuario.getNombre() %>">
                </div>
                <div class="form-group">
                    <label>Apellido</label>
                    <input type="text" name="apellido" required value="<%= esNuevo ? "" : usuario.getApellido() %>">
                </div>
                <div class="form-group">
                    <label>Dirección</label>
                    <input type="text" name="direccion" value="<%= (!esNuevo && usuario.getDireccion() != null) ? usuario.getDireccion() : "" %>">
                </div>
                <div class="form-group">
                    <label>Teléfono</label>
                    <input type="text" name="telefono" value="<%= (!esNuevo && usuario.getTelefono() != null) ? usuario.getTelefono() : "" %>">
                </div>

                <% if (esNuevo) { %>
                <div class="form-group">
                    <label>Tipo de documento</label>
                    <select name="tipoDocumentoId">
                        <% if (tiposDocumento != null) {
                            for (TipoDocumento td : tiposDocumento) { %>
                        <option value="<%= td.getIdTipoDocumento() %>"><%= td.getDescripcion() %></option>
                        <% }
                        } %>
                    </select>
                </div>
                <div class="form-group">
                    <label>Número de documento</label>
                    <input type="text" name="numeroDocumento" required>
                </div>
                <div class="form-group">
                    <label>Fecha de nacimiento</label>
                    <input type="date" name="fechaNacimiento">
                </div>
                <div class="form-group">
                    <label>Rol</label>
                    <select name="rolId">
                        <% if (roles != null) {
                            for (Rol r : roles) { %>
                        <option value="<%= r.getIdRol() %>"><%= r.getDescripcion() %></option>
                        <% }
                        } %>
                    </select>
                </div>
                <div class="form-group">
                    <label>Contraseña inicial</label>
                    <input type="password" name="contrasena" required>
                </div>
                <% } %>

                <div class="full-width">
                    <button type="submit" class="btn-guardar">Guardar</button>
                    <a href="${pageContext.request.contextPath}/AdminUsuariosServlet" class="btn-mini secundario" style="margin-left:0.6rem;">Cancelar</a>
                </div>
            </form>
        </div>

<%@ include file="_AdminLayoutCierre.jsp" %>
</body>
</html>

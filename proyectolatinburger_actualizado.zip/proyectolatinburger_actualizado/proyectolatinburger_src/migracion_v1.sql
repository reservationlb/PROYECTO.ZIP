-- =====================================================================
-- MIGRACIÓN v1 - Reservation L.B. (Latin Burger)
-- Ejecutar UNA sola vez sobre la base de datos "reservation_lb" ya creada
-- con Scrip.sql. Es ADITIVO: no borra tablas ni datos existentes.
--
-- QUÉ AGREGA Y POR QUÉ:
-- 1. Producto.imagen   -> el Modelo/DAO de Producto ya lo usan (Inicio.jsp
--                         muestra prod.getImagen()) pero la tabla Producto
--                         de Scrip.sql NO tiene esa columna: esto rompía
--                         ProductoDAO.listar() con SQLException en cada
--                         carga de Inicio.jsp. Se agrega nullable.
-- 2. Producto.activo   -> requerido para "ocultar/mostrar" platos desde el
--                         panel de administrador sin borrarlos físicamente.
-- 3. reserva.estado    -> requerido para "Mis Pedidos" (cliente) y gestión
--                         de reservas (admin): Pendiente/Confirmada/
--                         En preparación/Entregada/Cancelada.
-- 4. reserva.color_evento y reserva.comentarios -> boceto de "Color del
--                         Evento" + "Descripción Adicional".
-- 5. reserva_producto  -> tabla nueva (detalle). La reserva original solo
--                         tenía un único tipo_menu_id_tipo_menu, pero el
--                         boceto "Nuestro Menú / Mi Pedido" permite elegir
--                         VARIOS platos reales (Producto) con cantidad.
--                         Se agrega como tabla de detalle (como una
--                         factura), sin tocar ni duplicar tipo_menu.
-- 6. abono             -> tabla nueva para registrar abonos/pagos de una
--                         reserva (Nequi, Daviplata, tarjeta, etc.), que
--                         no existía en el modelo original.
-- =====================================================================

USE `reservation_lb`;

ALTER TABLE `Producto`
    ADD COLUMN `imagen` VARCHAR(255) NULL AFTER `id_categoria`,
    ADD COLUMN `activo` TINYINT(1) NOT NULL DEFAULT 1 AFTER `imagen`;

ALTER TABLE `reserva`
    ADD COLUMN `estado` VARCHAR(45) NOT NULL DEFAULT 'Pendiente' AFTER `usuario_id_usuario`,
    ADD COLUMN `color_evento` VARCHAR(45) NULL AFTER `estado`,
    ADD COLUMN `comentarios` VARCHAR(255) NULL AFTER `color_evento`;

CREATE TABLE IF NOT EXISTS `reservation_lb`.`reserva_producto` (
  `id_reserva_producto` INT NOT NULL AUTO_INCREMENT,
  `reserva_id_reserva` INT(11) NOT NULL,
  `producto_id_producto` INT NOT NULL,
  `cantidad` INT NOT NULL DEFAULT 1,
  `precio_unitario` DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (`id_reserva_producto`),
  INDEX `fk_resprod_reserva_idx` (`reserva_id_reserva` ASC),
  INDEX `fk_resprod_producto_idx` (`producto_id_producto` ASC),
  CONSTRAINT `fk_resprod_reserva`
    FOREIGN KEY (`reserva_id_reserva`)
    REFERENCES `reservation_lb`.`reserva` (`id_reserva`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_resprod_producto`
    FOREIGN KEY (`producto_id_producto`)
    REFERENCES `reservation_lb`.`Producto` (`id_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `reservation_lb`.`abono` (
  `id_abono` INT NOT NULL AUTO_INCREMENT,
  `reserva_id_reserva` INT(11) NOT NULL,
  `medio_pago` VARCHAR(45) NOT NULL,
  `valor_abono` DECIMAL(10,2) NOT NULL,
  `fecha_abono` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` VARCHAR(45) NOT NULL DEFAULT 'Registrado',
  PRIMARY KEY (`id_abono`),
  INDEX `fk_abono_reserva_idx` (`reserva_id_reserva` ASC),
  CONSTRAINT `fk_abono_reserva`
    FOREIGN KEY (`reserva_id_reserva`)
    REFERENCES `reservation_lb`.`reserva` (`id_reserva`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

-- La tabla `disponibilidad` ya soporta el ciclo Disponible -> Ocupado ->
-- Disponible (columna `estado` ya existente); no se modifica su estructura.
